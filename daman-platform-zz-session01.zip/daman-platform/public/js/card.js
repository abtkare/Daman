// صفحة الشحنة التي يفتحها الرمز: المشتري يتحقق ويشتكي، والمفتش يفحص، والسيطرة تسجّل المرور، وشركة التوصيل تنفّذ.
'use strict';
const code = decodeURIComponent(location.pathname.split('/')[2] || '');
const main = $('#main');

function codeEntry(msg) {
  main.innerHTML = `${msg || ''}<div class="card"><h3>اكتب رمز الشحنة المطبوع على الطرد</h3><form id="f" class="row"><input class="inp mono" id="c" placeholder="DM…" style="flex:1;min-width:0" autocomplete="off"><button class="btn primary">تحقّق</button></form></div>`;
  $('#f').onsubmit = e => { e.preventDefault(); const v = $('#c').value.trim().replace(/\s/g, ''); if (v) location.href = '/c/' + encodeURIComponent(v); };
}

async function load() {
  if (!code) return codeEntry();
  let r;
  try { r = await api('/api/c/' + encodeURIComponent(code)); } catch (e) { main.innerHTML = `<div class="note bad">${esc(e.message)}</div>`; return; }
  if (r.role) $('#who').innerHTML = `<a class="btn sm ghost" style="color:#fff;border-color:rgba(255,255,255,.25)" href="/${r.role}">بوابتي</a>`;
  if (!r.ok) {
    return codeEntry(`<div class="verify bad" style="margin-bottom:16px"><span class="ic">⛔</span><div><h2>الرمز غير صالح</h2><div>${r.reason === 'signature' ? 'التوقيع لا يطابق — هذا الرمز قد يكون مزوّراً. لا تستلم الطرد وأبلغ عنه.' : r.reason === 'unknown' ? 'لا توجد شحنة بهذا الرمز.' : 'صيغة الرمز غير صحيحة.'}</div></div></div>`);
  }
  render(r);
}

function render(r) {
  const s = r.s, m = s.merchant, role = r.role || 'public';
  const licOk = m.status === 'active' || ['delivered', 'returned'].includes(s.status);
  const feeOk = s.fee.ok;
  const good = licOk && feeOk && s.status !== 'held' && s.status !== 'refused';
  const head = `<div class="verify ${good ? 'ok' : 'bad'}"><span class="ic">${good ? '✅' : '⚠️'}</span><div><h2>${good ? 'شحنة موثّقة' : s.status === 'held' ? 'شحنة موقوفة بأمر سحب' : s.status === 'refused' ? 'رُفض استلام هذه الشحنة' : 'انتبه قبل الاستلام'}</h2><div>${esc(m.name)} · ${m.license ? `إجازة <span class="mono">${esc(m.license)}</span>` : 'بلا إجازة'} · ${esc(s.fee.text)}</div></div></div>`;

  const items = s.items.map(it => `<tr><td>${esc(it.name)}${it.regulated ? ' <span class="badge info">خاضع للفحص</span>' : ''}</td><td class="muted small">${esc(it.catName)}</td><td class="n">${it.qty}</td><td class="n">${iqd(it.price * it.qty)}</td></tr>`);
  const details = `<div class="card"><h3>📦 الشحنة <span class="mono muted small">${esc(s.code)}</span><span class="sp"></span>${statusBadge(s.status, s.statusText)}</h3>
    <dl class="dl"><dt>التاجر</dt><dd>${esc(m.name)} <span class="muted small">(${esc(m.tier)} · ${esc(m.channel)} · ${esc(m.gov)})</span></dd>
    <dt>حالة الإجازة</dt><dd>${statusBadge(m.status, MSTATUS[m.status])}</dd>
    <dt>شركة التوصيل</dt><dd>${esc(s.courier.name)} <span class="muted small mono">${esc(s.courier.license)}</span></dd>
    <dt>المشتري</dt><dd>${esc(s.buyer.name)} · ${esc(s.buyer.gov)} · <span class="num">${esc(s.buyer.phone)}</span>${s.buyer.address ? '<br><span class="muted small">' + esc(s.buyer.address) + '</span>' : ''}</dd>
    <dt>القيمة المصرّح بها</dt><dd>${iqd(s.value)}</dd>
    <dt>الرسم</dt><dd>${s.feeDue > 0 ? iqd(s.feeDue) : '0'} <span class="muted small">— ${esc(s.fee.text)}${s.feeComputed && !s.feeDue ? ` (المحتسب ${fmt(s.feeComputed)} د.ع)` : ''}</span></dd>
    <dt>الدفع</dt><dd>${s.pay === 'epay' ? 'إلكتروني مسبق' : 'عند الاستلام'}${s.origin === 'import' ? ' · <span class="badge gold">طلب من خارج العراق</span>' : ''}</dd></dl>
    <div style="margin-top:12px">${table(['القطعة', 'الفئة', 'العدد', 'القيمة'], items)}</div></div>`;

  const tl = `<div class="card"><h3>🕒 مسار الشحنة</h3><ul class="timeline">${s.events.slice().reverse().map(e => `<li><time>${dt(e.at)} · ${ago(e.at)}</time>${esc(e.text)}</li>`).join('')}</ul></div>`;

  let actions = '';
  if (role === 'public' || (role !== 'inspector' && role !== 'checkpoint' && !r.own)) {
    if (s.complaint) actions = `<div class="card"><h3>🛡️ الشكوى ${esc(s.complaint.id)}</h3><p style="margin:0">${esc(s.complaint.kindText)} — ${statusBadge(s.complaint.status, s.complaint.status === 'open' ? 'قيد النظر' : 'أُغلقت')}</p>${s.complaint.decisionText ? `<p class="muted" style="margin:6px 0 0">القرار: ${esc(s.complaint.decisionText)}</p>` : ''}${s.complaint.reply ? `<p class="muted small" style="margin:6px 0 0">رد التاجر: ${esc(s.complaint.reply)}</p>` : ''}</div>`;
    else if (s.status === 'delivered' || s.status === 'transit') actions = `<div class="card"><h3>هل في الطرد مشكلة؟</h3><p class="muted" style="margin:0 0 12px">تصل شكواك إلى التاجر ومجلس حماية المستهلك مربوطة بهذه الشحنة.</p><button class="btn primary lg block" id="complain">عندي مشكلة</button></div>`;
  }
  if (role === 'checkpoint') actions = `<div class="card"><h3>🚧 ${esc(r.place || 'السيطرة')}</h3>${feeOk ? `<div class="note ok" style="margin-bottom:12px"><span>✅</span><span><b>الرسم مثبت — لا جباية ثانية</b>${esc(s.fee.text)}</span></div>` : `<div class="note bad" style="margin-bottom:12px"><span>⚠️</span><span><b>الرسم غير مثبت</b>سجّل المرور ليُبلَّغ عنها.</span></div>`}<button class="btn primary lg block" id="pass">تسجيل المرور</button></div>`;
  if (role === 'inspector') actions = `<div class="card"><h3>🔎 نتيجة الفحص</h3><p class="muted" style="margin:0 0 12px">افتح الطرد وقارن المحتوى بالقطع والقيمة أعلاه.</p><div class="stack" style="gap:8px"><button class="btn primary lg block" data-k="match">المحتوى مطابق</button><button class="btn block" data-k="undervalue">القيمة الحقيقية أعلى من المصرّح بها</button><button class="btn block" data-k="undeclared">بضاعة غير مصرّح بها</button></div></div>`;
  if (role === 'courier' && r.own) {
    const b = { created: ['shipment.pickup', 'استلام الطرد'], picked: ['shipment.dispatch', 'خروج للتسليم'], transit: ['shipment.deliver', `تسليم وقبض ${fmt(s.pay === 'cod' ? s.value + s.feeDue : 0)} د.ع`] }[s.status];
    if (b) actions = `<div class="card"><h3>🚚 ${esc(s.courier.name)}</h3><button class="btn primary lg block" id="cact" data-a="${b[0]}">${esc(b[1])}</button></div>`;
  }
  if (role === 'merchant' && r.own) actions = `<div class="card print-area"><h3>ورقة الشحن</h3>${waybill(s)}<div class="row" style="margin-top:12px"><button class="btn primary" onclick="window.print()">طباعة</button></div></div>`;

  const scans = s.scans.length ? `<div class="card"><h3>🔁 مرات المسح الرسمي</h3>${table(['الوقت', 'الجهة', 'النتيجة'], s.scans.slice().reverse().map(x => `<tr><td class="n">${dt(x.at)}</td><td>${esc(x.place || x.by)}</td><td>${statusBadge(x.result, x.text)}</td></tr>`))}</div>` : '';
  main.innerHTML = `<div class="stack">${head}${actions}${details}${scans}${tl}</div>`;
  labelTables(main);

  const c = $('#complain');
  if (c) c.onclick = async () => {
    const v = await ask('شكوى على الشحنة ' + s.code, [
      { name: 'phone', label: 'آخر 4 أرقام من هاتفك (للتأكد أنك المشتري)', type: 'tel', placeholder: '••••' },
      { name: 'kind', label: 'ما المشكلة؟', type: 'select', options: [['different', 'البضاعة مختلفة عن الوصف'], ['fake', 'بضاعة مقلّدة أو تالفة'], ['notarrived', 'لم تصل أو ناقصة'], ['price', 'سعر أعلى من المتفق عليه'], ['other', 'أخرى']] },
      { name: 'text', label: 'اكتب ما حدث باختصار', type: 'textarea' },
    ], { okText: 'أرسل الشكوى' });
    if (!v) return;
    try { const k = await api('/api/public/complaint', { code: s.code, ...v }); toast('وصلت شكواك برقم ' + k.id); load(); } catch (x) { toast(x.message, true); }
  };
  const p = $('#pass');
  if (p) p.onclick = () => doAct('scan', { code: s.code, kind: 'pass' }, 'سُجّل المرور');
  $$('[data-k]').forEach(b => b.onclick = async () => {
    const k = b.dataset.k;
    if (k === 'match') return doAct('scan', { code: s.code, kind: 'match' }, 'سُجّل: مطابق');
    if (k === 'undervalue') { const v = await ask('القيمة الحقيقية للطرد', [{ name: 'actual', label: 'القيمة الحقيقية بالدينار', type: 'number' }], { okText: 'سجّل المخالفة', danger: true }); if (v) doAct('scan', { code: s.code, kind: 'undervalue', actual: v.actual }, 'سُجّلت المخالفة وأُبلغت الضرائب'); }
    if (k === 'undeclared') { const v = await ask('بضاعة غير مصرّح بها', [{ name: 'note', label: 'ما الذي وجدته؟', type: 'textarea' }], { okText: 'سجّل المخالفة', danger: true }); if (v) doAct('scan', { code: s.code, kind: 'undeclared', note: v.note }, 'سُجّلت المخالفة وأُبلغ الجهاز المركزي'); }
  });
  const ca = $('#cact');
  if (ca) ca.onclick = () => doAct(ca.dataset.a, { id: s.id }, 'تم');
}

async function doAct(a, p, ok) {
  try { const r = await api('/api/act', { a, p }); toast(r.result && r.result.refused ? 'رُفض الاستلام: إجازة التاجر غير فعّالة أو أمر سحب' : ok, r.result && r.result.refused); load(); }
  catch (x) { toast(x.message, true); }
}

function waybill(s) {
  return `<div class="waybill"><img src="/qr/${encodeURIComponent(s.code)}.svg" alt="رمز الشحنة"><div><div class="muted small">ضمان · ورقة شحن</div><div class="code mono">${esc(s.code)}</div><div><b>${esc(s.merchant.name)}</b> — <span class="mono">${esc(s.merchant.license || '')}</span></div><div>${esc(s.buyer.name)} · ${esc(s.buyer.gov)}</div><div>${esc(s.courier.name)}</div><div>${s.items.reduce((a, i) => a + i.qty, 0)} قطعة · ${iqd(s.value)} · الرسم ${iqd(s.feeDue)}</div><div class="muted small">${s.pay === 'cod' ? `يقبض المندوب ${fmt(s.value + s.feeDue)} د.ع` : 'مدفوعة إلكترونياً'}</div></div></div>`;
}

load();
