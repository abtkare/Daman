// مولّد رمز QR بلا حزم خارجية — وضع البايت، مستوى التصحيح M، الإصدارات 1 إلى 10.
// يُعيد مصفوفة مربعات، ودالة svg() ترسمها صورةً متجهة.
'use strict';

// [عدد كلمات التصحيح لكل كتلة، كتل المجموعة 1، بيانات كل كتلة فيها، كتل المجموعة 2، بيانات كل كتلة فيها]
const ECC_M = [null,
  [10, 1, 16, 0, 0], [16, 1, 28, 0, 0], [26, 1, 44, 0, 0], [18, 2, 32, 0, 0], [24, 2, 43, 0, 0],
  [16, 4, 27, 0, 0], [18, 4, 31, 0, 0], [22, 2, 38, 2, 39], [22, 3, 36, 2, 37], [26, 4, 43, 1, 44]];
const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];

// ── حساب الحقل GF(256) لتصحيح الأخطاء ريد-سولومون ──
const EXP = new Array(512), LOG = new Array(256);
(() => { let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; })();
const gmul = (a, b) => (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]];
function rsGenerator(deg) {
  let g = [1];
  for (let i = 0; i < deg; i++) {
    const n = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) { n[j] ^= g[j]; n[j + 1] ^= gmul(g[j], EXP[i]); }
    g = n;
  }
  return g;
}
function rsRemainder(data, deg) {
  const gen = rsGenerator(deg), res = new Array(deg).fill(0);
  for (const b of data) {
    const f = b ^ res.shift(); res.push(0);
    for (let i = 0; i < deg; i++) res[i] ^= gmul(gen[i + 1], f);
  }
  return res;
}

function dataCapacity(v) { const e = ECC_M[v]; return e[1] * e[2] + e[3] * e[4]; }

function encodeData(bytes, v) {
  const bits = [];
  const put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
  put(0b0100, 4); put(bytes.length, v < 10 ? 8 : 16);
  for (const b of bytes) put(b, 8);
  const cap = dataCapacity(v) * 8;
  put(0, Math.min(4, cap - bits.length));
  while (bits.length % 8) bits.push(0);
  const cw = [];
  for (let i = 0; i < bits.length; i += 8) { let b = 0; for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j]; cw.push(b); }
  for (let pad = 0xEC; cw.length < dataCapacity(v); pad ^= 0xEC ^ 0x11) cw.push(pad);
  // تقسيم الكتل وإضافة التصحيح ثم التشابك
  const [ec, b1, d1, b2, d2] = ECC_M[v], blocks = [];
  let k = 0;
  for (let i = 0; i < b1; i++) { blocks.push(cw.slice(k, k + d1)); k += d1; }
  for (let i = 0; i < b2; i++) { blocks.push(cw.slice(k, k + d2)); k += d2; }
  const ecBlocks = blocks.map(b => rsRemainder(b, ec));
  const out = [], maxD = Math.max(d1, d2);
  for (let i = 0; i < maxD; i++) for (const b of blocks) if (i < b.length) out.push(b[i]);
  for (let i = 0; i < ec; i++) for (const b of ecBlocks) out.push(b[i]);
  return out;
}

function bch(value, poly, polyBits) {
  let v = value << (polyBits - 1);
  for (let i = 31; i >= polyBits - 1; i--) if ((v >>> i) & 1) v ^= poly << (i - (polyBits - 1));
  return (value << (polyBits - 1)) | v;
}

function build(bytes, v, mask) {
  const n = 17 + 4 * v;
  const m = Array.from({ length: n }, () => new Array(n).fill(0));
  const fn = Array.from({ length: n }, () => new Array(n).fill(false));
  const set = (x, y, d) => { m[y][x] = d ? 1 : 0; fn[y][x] = true; };
  // أنماط الزوايا
  const finder = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx, y = cy + dy; if (x < 0 || y < 0 || x >= n || y >= n) continue;
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      set(x, y, d !== 2 && d !== 4);
    }
  };
  finder(3, 3); finder(n - 4, 3); finder(3, n - 4);
  for (let i = 0; i < n; i++) { if (!fn[6][i]) set(i, 6, i % 2 === 0); if (!fn[i][6]) set(6, i, i % 2 === 0); }
  const al = ALIGN[v];
  for (const ay of al) for (const ax of al) {
    if ((ax === 6 && ay === 6) || (ax === 6 && ay === al[al.length - 1]) || (ay === 6 && ax === al[al.length - 1])) continue;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
  }
  // معلومات التنسيق: المستوى M = 00
  const fmt = bch((0b00 << 3) | mask, 0x537, 11) ^ 0x5412;
  const fb = i => ((fmt >>> i) & 1) === 1;
  for (let i = 0; i <= 5; i++) set(8, i, fb(i));
  set(8, 7, fb(6)); set(8, 8, fb(7)); set(7, 8, fb(8));
  for (let i = 9; i < 15; i++) set(14 - i, 8, fb(i));
  for (let i = 0; i < 8; i++) set(n - 1 - i, 8, fb(i));
  for (let i = 8; i < 15; i++) set(8, n - 15 + i, fb(i));
  set(8, n - 8, true);
  // معلومات الإصدار للإصدار 7 فما فوق
  if (v >= 7) {
    const ver = bch(v, 0x1F25, 13);
    for (let i = 0; i < 18; i++) {
      const b = ((ver >>> i) & 1) === 1, a = n - 11 + (i % 3), c = Math.floor(i / 3);
      set(a, c, b); set(c, a, b);
    }
  }
  // وضع البيانات بالمسار المتعرج
  const data = encodeData(bytes, v);
  let bit = 0;
  for (let right = n - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < n; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j, upward = ((right + 1) & 2) === 0, y = upward ? n - 1 - vert : vert;
        if (!fn[y][x] && bit < data.length * 8) { m[y][x] = (data[bit >>> 3] >>> (7 - (bit & 7))) & 1; bit++; }
      }
    }
  }
  // القناع
  const MASKS = [
    (x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => (x * y) % 2 + (x * y) % 3 === 0,
    (x, y) => ((x * y) % 2 + (x * y) % 3) % 2 === 0, (x, y) => ((x + y) % 2 + (x * y) % 3) % 2 === 0];
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (!fn[y][x] && MASKS[mask](x, y)) m[y][x] ^= 1;
  return m;
}

// تقييم القناع حسب قواعد المعيار، ويُختار الأقل عقوبة
function penalty(m) {
  const n = m.length; let p = 0;
  const runs = line => { let s = 0, c = 1; for (let i = 1; i <= line.length; i++) { if (i < line.length && line[i] === line[i - 1]) c++; else { if (c >= 5) s += 3 + (c - 5); c = 1; } } return s; };
  for (let i = 0; i < n; i++) { p += runs(m[i]); p += runs(m.map(r => r[i])); }
  for (let y = 0; y < n - 1; y++) for (let x = 0; x < n - 1; x++) { const c = m[y][x]; if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) p += 3; }
  const pat = [1, 0, 1, 1, 1, 0, 1], quiet = [0, 0, 0, 0];
  const has = (line, i) => {
    const seg = line.slice(i, i + 7); if (seg.length < 7 || seg.some((b, k) => b !== pat[k])) return false;
    const before = line.slice(Math.max(0, i - 4), i), after = line.slice(i + 7, i + 11);
    const ok = arr => arr.length === 4 ? arr.every(b => b === 0) : true;
    return (i - 4 < 0 ? before.every(b => b === 0) : ok(before)) || (i + 11 > line.length ? after.every(b => b === 0) : ok(after));
  };
  void quiet;
  for (let i = 0; i < n; i++) { const row = m[i], col = m.map(r => r[i]); for (let j = 0; j < n; j++) { if (has(row, j)) p += 40; if (has(col, j)) p += 40; } }
  let dark = 0; for (const r of m) for (const c of r) dark += c;
  p += Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
  return p;
}

function make(text) {
  const bytes = [...Buffer.from(String(text), 'utf8')];
  let v = 1;
  while (v <= 10 && dataCapacity(v) < bytes.length + (v < 10 ? 2 : 3)) v++;
  if (v > 10) throw new Error('النص أطول من سعة الرمز');
  let best = null, bestP = Infinity;
  for (let mask = 0; mask < 8; mask++) { const mm = build(bytes, v, mask), p = penalty(mm); if (p < bestP) { bestP = p; best = mm; } }
  return best;
}

function svg(text, size = 220) {
  const m = make(text), n = m.length, q = 4, t = n + q * 2;
  let d = '';
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (m[y][x]) d += `M${x + q} ${y + q}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${t} ${t}" width="${size}" height="${size}" shape-rendering="crispEdges" role="img" aria-label="رمز الشحنة"><rect width="${t}" height="${t}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}

module.exports = { make, svg };
