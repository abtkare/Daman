// مخزن بيانات «ضمان» — نسخة العرض: البيانات في الذاكرة وتُحفظ في ملف JSON.
// السجل المالي وسجل الأفعال سلسلتان مترابطتان بالبصمة (SHA-256): أي تعديل لاحق على قيد قديم يكسر السلسلة ويظهر عند التحقق.
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'db.json');
const DATA_VERSION = 1;
// مفتاح توقيع الرموز: من متغير البيئة، وإلا يُنشأ مرة واحدة ويُحفظ بجانب البيانات (لا يوضع في المستودع العام)
function loadSecret() {
  if (process.env.DAMAN_SECRET) return process.env.DAMAN_SECRET;
  const f = path.join(path.dirname(DATA_FILE), 'secret.key');
  try { const s = fs.readFileSync(f, 'utf8').trim(); if (s.length >= 32) return s; } catch { /* أول تشغيل */ }
  const s = crypto.randomBytes(32).toString('hex');
  try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, s, { mode: 0o600 }); } catch (e) { console.error('[store] تعذّر حفظ مفتاح التوقيع:', e.message); }
  return s;
}
const SECRET = loadSecret();

let db = null;

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const hmac = s => crypto.createHmac('sha256', SECRET).update(s).digest();

// رمز الشحنة: 8 محارف معرّف + 4 محارف توقيع من المفتاح السري — لا يمكن صنع رمز صالح دون المفتاح
const B32 = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function b32(buf, len) { let s = ''; for (let i = 0; i < len; i++) s += B32[buf[i] % 32]; return s; }
function signCode(id) { return b32(hmac('ship:' + id), 4); }
function newShipmentCode() {
  let id;
  do { id = b32(crypto.randomBytes(8), 8); } while (db && db.shipments.some(s => s.id === id));
  return { id, code: 'DM' + id + signCode(id) };
}
function parseCode(code) {
  const c = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!/^DM[A-Z0-9]{12}$/.test(c)) return { ok: false, reason: 'format' };
  const id = c.slice(2, 10), sig = c.slice(10);
  if (signCode(id) !== sig) return { ok: false, reason: 'signature' };
  return { ok: true, id, code: c };
}

function hashPassword(pw, salt = crypto.randomBytes(12).toString('hex')) {
  return salt + ':' + crypto.scryptSync(String(pw), salt, 32, { N: 4096 }).toString('hex');
}
function checkPassword(pw, stored) {
  const [salt, h] = String(stored || '').split(':');
  if (!salt || !h) return false;
  const got = crypto.scryptSync(String(pw), salt, 32, { N: 4096 }).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(got), Buffer.from(h));
}

// إضافة قيد إلى سلسلة (لا تعديل ولا حذف)
function chainAppend(listName, entry) {
  const list = db[listName];
  const prev = list.length ? list[list.length - 1].hash : 'GENESIS';
  const rec = { seq: list.length + 1, at: entry.at || new Date().toISOString(), ...entry, prev };
  const { hash: _h, ...body } = rec;
  rec.hash = sha(JSON.stringify(body));
  list.push(rec);
  scheduleSave();
  return rec;
}
function chainVerify(listName) {
  const list = db[listName];
  let prev = 'GENESIS';
  for (const r of list) {
    const { hash, ...body } = r;
    if (r.prev !== prev || sha(JSON.stringify(body)) !== hash) return { ok: false, brokenAt: r.seq, total: list.length };
    prev = hash;
  }
  return { ok: true, total: list.length, last: prev.slice(0, 16) };
}

let saveTimer = null;
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try { fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true }); fs.writeFileSync(DATA_FILE + '.tmp', JSON.stringify(db)); fs.renameSync(DATA_FILE + '.tmp', DATA_FILE); }
    catch (e) { console.error('[store] تعذّر الحفظ:', e.message); }
  }, 400);
}

function load(seedFn) {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (raw && raw.version === DATA_VERSION) { db = raw; console.log('[store] حُمّلت البيانات المحفوظة'); return db; }
  } catch { /* لا ملف بعد */ }
  db = seedFn();
  db.version = DATA_VERSION;
  scheduleSave();
  console.log('[store] بيانات العرض أُنشئت من جديد');
  return db;
}
function reset(seedFn) { db = seedFn(); db.version = DATA_VERSION; scheduleSave(); return db; }

module.exports = {
  get db() { return db; }, _set(d) { db = d; }, load, reset, scheduleSave, chainAppend, chainVerify,
  newShipmentCode, parseCode, signCode, hashPassword, checkPassword, sha,
};
