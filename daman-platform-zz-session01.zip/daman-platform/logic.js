// منطق «ضمان»: الرسم، الشحنات، الجباية والمطابقة، والصلاحيات لكل جهة.
// القاعدة: لا شحنة بلا رمز، ولا رمز بلا تاجر مُجاز. كل فعل يُسجَّل في سجل لا يُعدَّل.
'use strict';
const S = require('./store');

const GOVS = ['بغداد', 'البصرة', 'نينوى', 'النجف', 'كربلاء', 'بابل', 'ذي قار', 'الأنبار', 'ديالى', 'كركوك', 'صلاح الدين', 'واسط', 'ميسان', 'القادسية', 'المثنى'];

const ROLES = {
  digital: { name: 'وزارة الاقتصاد الرقمي والحوكمة', short: 'الاقتصاد الرقمي', icon: '🏛️' },
  trade: { name: 'وزارة التجارة', short: 'التجارة', icon: '📜' },
  tax: { name: 'الهيئة العامة للضرائب', short: 'الضرائب', icon: '🧾' },
  customs: { name: 'الهيئة العامة للكمارك', short: 'الكمارك', icon: '🛃' },
  quality: { name: 'الجهاز المركزي للتقييس والسيطرة النوعية', short: 'التقييس والجودة', icon: '🔬' },
  consumer: { name: 'مجلس حماية المستهلك', short: 'حماية المستهلك', icon: '🛡️' },
  cmc: { name: 'هيئة الإعلام والاتصالات', short: 'الإعلام والاتصالات', icon: '📡' },
  cbi: { name: 'البنك المركزي العراقي', short: 'البنك المركزي', icon: '🏦' },
  audit: { name: 'الجهات الرقابية — النزاهة والرقابة المالية', short: 'الرقابة', icon: '⚖️' },
  courier: { name: 'شركة توصيل مرخّصة', short: 'شركة التوصيل', icon: '🚚' },
  merchant: { name: 'التاجر الإلكتروني', short: 'التاجر', icon: '🛍️' },
  inspector: { name: 'المفتش الميداني', short: 'المفتش', icon: '🔎' },
  checkpoint: { name: 'السيطرات الأمنية', short: 'السيطرة', icon: '🚧' },
};

const TIERS = { home: 'بائع منزلي', trader: 'تاجر', platform: 'منصة / وسيط استيراد' };
const CHANNELS = { facebook: 'فيسبوك', instagram: 'إنستغرام', tiktok: 'تيك توك', live: 'بث مباشر', website: 'موقع إلكتروني' };
const STATUS = { created: 'بانتظار الاستلام', picked: 'في مخزن شركة التوصيل', transit: 'في الطريق', delivered: 'سُلّمت', returned: 'أُرجعت', refused: 'رُفض استلامها', held: 'موقوفة بأمر سحب' };

const db = () => S.db;
let CLOCK = null;
const now = () => CLOCK || new Date().toISOString();
function setClock(iso) { CLOCK = iso; }
const roundFee = x => Math.round(x / 250) * 250;
const err = (msg, code = 400) => { const e = new Error(msg); e.status = code; throw e; };
const byId = (list, id) => db()[list].find(x => x.id === id);
const sum = (arr, f) => arr.reduce((a, x) => a + (f(x) || 0), 0);
const monthKey = iso => iso.slice(0, 7);
const dayKey = iso => iso.slice(0, 10);

function maskPhone(p) { p = String(p || ''); return p.length > 6 ? p.slice(0, 4) + '•••' + p.slice(-4) : p; }

// ── السجلات ──
function log(user, action, ref, detail, at) {
  return S.chainAppend('audit', { at: at || now(), who: user ? user.username : 'public', role: user ? user.role : 'public', action, ref: ref || '', detail: detail || '' });
}
function ledger(entry) { return S.chainAppend('ledger', entry); }
function notify(to, text, at) { db().notes.push({ id: db().notes.length + 1, at: at || now(), to, text }); S.scheduleSave(); }

// ── الرسم ──
function merchantMonthSales(merchantId, at, excludeId) {
  const mk = monthKey(at);
  return sum(db().shipments.filter(s => s.merchantId === merchantId && s.id !== excludeId && monthKey(s.at) === mk && s.status !== 'refused'), s => s.value);
}
function computeFee(merchant, items, at, excludeId) {
  const cats = db().categories, st = db().settings;
  let raw = 0;
  for (const it of items) { const c = cats[it.category]; if (!c) err('فئة غير معروفة'); raw += it.qty * it.price * c.rate / 100; }
  const value = sum(items, it => it.qty * it.price);
  const computed = raw > 0 ? Math.max(st.minFee, roundFee(raw)) : 0;
  let due = computed, exempt = '';
  if (computed === 0) exempt = 'سلع أساسية معفاة';
  else if (merchant.tier === 'home' && merchantMonthSales(merchant.id, at, excludeId) + value <= st.homeCap) { due = 0; exempt = 'بائع منزلي تحت السقف الشهري'; }
  else if (st.phase === 'zero') { due = 0; exempt = 'المرحلة صفر — تسجيل بلا رسم'; }
  return { value, computed, due, exempt };
}

function activeRecall(merchantId, category) { return db().recalls.find(r => r.active && r.merchantId === merchantId && r.category === category); }

// ── إنشاء الشحنة ──
function createShipment(user, p, at) {
  at = at || now();
  const m = byId('merchants', p.merchantId);
  if (!m) err('التاجر غير موجود');
  if (m.status !== 'active') err('لا يمكن إنشاء شحنة قبل صدور الإجازة أو أثناء تعليقها');
  const c = byId('couriers', p.courierId);
  if (!c) err('اختر شركة توصيل مرخّصة');
  const items = (p.items || []).map(it => ({ name: String(it.name || '').trim().slice(0, 80), category: it.category, qty: Math.max(1, Math.floor(+it.qty || 1)), price: Math.max(0, Math.round(+it.price || 0)) })).filter(it => it.name && it.price > 0);
  if (!items.length) err('أضف قطعة واحدة على الأقل بسعرها');
  for (const it of items) if (activeRecall(m.id, it.category)) err(`يوجد أمر سحب على فئة «${db().categories[it.category].name}» لهذا التاجر`);
  const b = p.buyer || {};
  if (!b.name || !/^07\d{9}$/.test(String(b.phone || ''))) err('اكتب اسم المشتري ورقم هاتفه (07xxxxxxxxx)');
  if (!GOVS.includes(b.gov)) err('اختر محافظة المشتري');
  const fee = computeFee(m, items, at);
  const { id, code } = S.newShipmentCode();
  const pay = p.pay === 'epay' ? 'epay' : 'cod';
  const s = {
    id, code, at, merchantId: m.id, courierId: c.id, origin: p.origin || 'domestic', declarationId: p.declarationId || null,
    buyer: { name: String(b.name).slice(0, 60), phone: String(b.phone), gov: b.gov, address: String(b.address || '').slice(0, 120) },
    items, value: fee.value, feeComputed: fee.computed, feeDue: fee.due, exempt: fee.exempt, phase: db().settings.phase,
    pay, feePaid: false, collected: false, remitId: null, status: 'created', events: [{ at, type: 'created', by: user ? user.username : 'system', text: 'أنشأ التاجر الشحنة وصدر رمزها' }], scans: [],
  };
  if (pay === 'epay' && s.feeDue > 0) {
    s.feePaid = true; s.collected = true;
    ledger({ at, type: 'fee_epay', amount: s.feeDue, shipment: s.id, merchant: m.id, gov: b.gov, note: 'اقتُطع الرسم آلياً عند الدفع الإلكتروني' });
    s.events.push({ at, type: 'fee', by: 'payment', text: 'اقتُطع الرسم عبر مزوّد الدفع الإلكتروني' });
  }
  db().shipments.push(s);
  log(user, 'إنشاء شحنة', s.code, `${m.name} — ${items.length} قطعة بقيمة ${s.value} د.ع، الرسم ${s.feeDue}`, at);
  return s;
}

// ── شركة التوصيل ──
function courierShipment(user, id) {
  const s = byId('shipments', id);
  if (!s || s.courierId !== user.courierId) err('الشحنة ليست لشركتك', 403);
  return s;
}
function pickup(user, id, at) {
  at = at || now();
  const s = courierShipment(user, id);
  if (s.status !== 'created') err('الشحنة ليست بانتظار الاستلام');
  const m = byId('merchants', s.merchantId);
  const recalled = s.items.find(it => activeRecall(m.id, it.category));
  if (m.status !== 'active' || recalled) {
    s.status = 'refused';
    s.events.push({ at, type: 'refused', by: user.username, text: m.status !== 'active' ? 'رُفض الاستلام: إجازة التاجر غير فعّالة' : 'رُفض الاستلام: أمر سحب على الفئة' });
    log(user, 'رفض استلام', s.code, 'إجازة غير فعّالة أو أمر سحب', at);
    return { refused: true, s };
  }
  s.status = 'picked';
  s.events.push({ at, type: 'picked', by: user.username, text: 'استلمت شركة التوصيل الطرد بعد التحقق من الإجازة' });
  log(user, 'استلام شحنة', s.code, '', at);
  return { s };
}
function dispatch(user, id, at) {
  at = at || now();
  const s = courierShipment(user, id);
  if (s.status !== 'picked') err('الشحنة ليست في المخزن');
  s.status = 'transit';
  s.events.push({ at, type: 'transit', by: user.username, text: 'خرجت مع المندوب للتسليم' });
  log(user, 'خروج للتسليم', s.code, '', at);
  return { s };
}
function deliver(user, id, at) {
  at = at || now();
  const s = courierShipment(user, id);
  if (!['picked', 'transit'].includes(s.status)) err('لا يمكن تسليم هذه الشحنة الآن');
  s.status = 'delivered';
  const text = s.pay === 'cod'
    ? (s.feeDue > 0 ? `سُلّمت وقبض المندوب ${s.value.toLocaleString('en')} د.ع ثمن البضاعة مع رسم ${s.feeDue.toLocaleString('en')} د.ع` : `سُلّمت وقبض المندوب ثمن البضاعة (${s.exempt || 'بلا رسم'})`)
    : 'سُلّمت — مدفوعة إلكترونياً مسبقاً';
  s.events.push({ at, type: 'delivered', by: user.username, text });
  if (s.pay === 'cod' && s.feeDue > 0) {
    s.collected = true; s.feePaid = true;
    ledger({ at, type: 'fee_collected', amount: s.feeDue, shipment: s.id, merchant: s.merchantId, courier: s.courierId, gov: s.buyer.gov, note: 'قبضه المندوب عند التسليم' });
  }
  notify('buyer:' + s.id, `رسالة نصية إلى ${maskPhone(s.buyer.phone)}: استلمت شحنتك ${s.code}. ${s.feeDue > 0 ? 'الرسم المدفوع ' + s.feeDue + ' د.ع. ' : ''}للتحقق أو الشكوى امسح الرمز.`, at);
  log(user, 'تسليم وقبض', s.code, text, at);
  return { s };
}
function returnShipment(user, id, reason, at) {
  at = at || now();
  const s = courierShipment(user, id);
  if (!['picked', 'transit'].includes(s.status)) err('لا يمكن إرجاع هذه الشحنة الآن');
  s.status = 'returned';
  s.events.push({ at, type: 'returned', by: user.username, text: 'أُرجعت: ' + (reason || 'رفض المشتري الاستلام') });
  log(user, 'إرجاع شحنة', s.code, reason || '', at);
  return { s };
}
function courierBalance(courierId) {
  const pend = db().shipments.filter(s => s.courierId === courierId && s.pay === 'cod' && s.collected && s.feeDue > 0 && !s.remitId);
  const collected = sum(pend, s => s.feeDue), pct = db().settings.courierCommissionPct;
  const commission = Math.round(collected * pct / 100);
  return { shipments: pend, collected, commission, net: collected - commission };
}
function remit(user, at, amountOverride) {
  at = at || now();
  const c = byId('couriers', user.courierId);
  const b = courierBalance(c.id);
  if (!b.shipments.length) err('لا رسوم مقبوضة بانتظار التحويل');
  const r = {
    id: 'R' + String(db().remittances.length + 1).padStart(4, '0'), at, courierId: c.id, shipments: b.shipments.map(s => s.id),
    collected: b.collected, commission: b.commission, expected: b.net, amount: amountOverride != null ? amountOverride : b.net, status: 'sent', note: '',
  };
  db().remittances.push(r);
  for (const s of b.shipments) s.remitId = r.id;
  ledger({ at, type: 'remittance', amount: r.amount, courier: c.id, remit: r.id, note: `تحويل ${r.shipments.length} رسماً بعد استقطاع عمولة الجباية ${r.commission} د.ع` });
  log(user, 'تحويل يومي للضرائب', r.id, `${r.amount} د.ع عن ${r.shipments.length} شحنة`, at);
  notify('role:tax', `وصل تحويل ${r.id} من ${c.name} بمبلغ ${r.amount.toLocaleString('en')} د.ع — بانتظار المطابقة`, at);
  return r;
}

// ── الضرائب ──
function reconcile(user, remitId, at) {
  at = at || now();
  const r = byId('remittances', remitId);
  if (!r) err('التحويل غير موجود');
  if (r.status !== 'sent') err('طوبق هذا التحويل مسبقاً');
  const diff = r.amount - r.expected;
  r.status = diff === 0 ? 'reconciled' : 'mismatch';
  r.diff = diff; r.checkedAt = at; r.checkedBy = user.username;
  ledger({ at, type: 'reconcile', amount: r.amount, remit: r.id, courier: r.courierId, note: diff === 0 ? 'مطابق' : `فرق ${diff} د.ع` });
  log(user, 'مطابقة تحويل', r.id, diff === 0 ? 'مطابق' : `فرق ${diff} د.ع`, at);
  if (diff !== 0) notify('courier:' + r.courierId, `التحويل ${r.id} غير مطابق: فرق ${Math.abs(diff).toLocaleString('en')} د.ع. سدّد الفرق أو قدّم التبرير.`, at);
  return r;
}
function settleDiff(user, remitId) {
  const r = byId('remittances', remitId);
  if (!r || r.courierId !== user.courierId) err('التحويل ليس لشركتك', 403);
  if (r.status !== 'mismatch') err('لا فرق على هذا التحويل');
  const at = now(), d = -r.diff;
  ledger({ at, type: 'remittance', amount: d, courier: r.courierId, remit: r.id, note: 'تسديد فرق المطابقة' });
  r.amount += d; r.diff = 0; r.status = 'reconciled'; r.note = 'سُدّد الفرق ' + d + ' د.ع';
  log(user, 'تسديد فرق', r.id, d + ' د.ع', at);
  notify('role:tax', `سدّدت ${byId('couriers', r.courierId).name} فرق التحويل ${r.id}: ${d.toLocaleString('en')} د.ع`, at);
  return r;
}

// ── المسح: المفتش والسيطرة ──
function shipmentByCode(code) {
  const p = S.parseCode(code);
  if (!p.ok) return { ok: false, reason: p.reason };
  const s = db().shipments.find(x => x.id === p.id);
  if (!s) return { ok: false, reason: 'unknown' };
  return { ok: true, s };
}
function feeState(s) {
  if (s.feeDue === 0) return { key: 'exempt', text: s.exempt || 'لا رسم', ok: true };
  if (s.feePaid) return { key: 'paid', text: 'الرسم مدفوع', ok: true };
  if (s.pay === 'cod' && ['created', 'picked', 'transit'].includes(s.status)) return { key: 'cod', text: 'الرسم يُقبض عند التسليم مع الثمن', ok: true };
  return { key: 'none', text: 'الرسم غير مدفوع', ok: false };
}
function scan(user, code, kind, data, at) {
  at = at || now();
  const r = shipmentByCode(code);
  if (!r.ok) err('رمز غير صالح — قد يكون مزوّراً', 404);
  const s = r.s, fs = feeState(s);
  let result, text;
  if (user.role === 'checkpoint') {
    result = fs.ok ? 'pass' : 'flag';
    text = fs.ok ? 'مرّت من السيطرة — الرسم مثبت، فلا جباية ثانية' : 'أُبلغ عنها: الرسم غير مثبت';
  } else if (user.role === 'inspector') {
    if (kind === 'match') { result = 'match'; text = 'فحص المفتش: المحتوى مطابق للبيان'; }
    else if (kind === 'undervalue') {
      const actual = Math.round(+data.actual || 0);
      if (actual <= s.value) err('اكتب القيمة الحقيقية (أعلى من المصرّح بها)');
      const m = byId('merchants', s.merchantId);
      const fee = computeFee(m, s.items.map(it => ({ ...it, price: Math.round(it.price * actual / s.value) })), s.at, s.id);
      result = 'undervalue'; text = `مخالفة: القيمة الحقيقية ${actual.toLocaleString('en')} د.ع بدل ${s.value.toLocaleString('en')} — فرق الرسم ${(fee.due - s.feeDue).toLocaleString('en')} د.ع`;
      db().violations.push({ id: 'V' + (db().violations.length + 1), at, shipmentId: s.id, merchantId: s.merchantId, kind: 'undervalue', declared: s.value, actual, feeGap: fee.due - s.feeDue, by: user.username, status: 'open' });
      notify('merchant:' + s.merchantId, `مخالفة تصريح بقيمة أقل على الشحنة ${s.code}. فرق الرسم مستحق.`, at);
      notify('role:tax', `مخالفة قيمة على الشحنة ${s.code} — فرق الرسم ${(fee.due - s.feeDue).toLocaleString('en')} د.ع`, at);
    } else if (kind === 'undeclared') {
      result = 'undeclared'; text = 'مخالفة: بضاعة غير مصرّح بها — ' + String(data.note || '').slice(0, 120);
      db().violations.push({ id: 'V' + (db().violations.length + 1), at, shipmentId: s.id, merchantId: s.merchantId, kind: 'undeclared', note: String(data.note || ''), by: user.username, status: 'open' });
      notify('role:quality', `بضاعة غير مصرّح بها في الشحنة ${s.code}`, at);
    } else err('اختر نتيجة الفحص');
  } else err('المسح الرسمي للمفتش والسيطرة فقط', 403);
  const rec = { at, by: user.username, role: user.role, place: user.place || '', result, text };
  s.scans.push(rec); s.events.push({ at, type: 'scan', by: user.username, text: (user.place ? user.place + ': ' : '') + text });
  log(user, user.role === 'checkpoint' ? 'مسح في سيطرة' : 'فحص مفتش', s.code, text, at);
  return { s, rec };
}

// ── المواطن: الشكوى والإبلاغ ──
function publicComplaint(code, phone, kind, text, at) {
  at = at || now();
  const r = shipmentByCode(code);
  if (!r.ok) err('رمز غير صالح');
  const s = r.s;
  if (String(phone || '').replace(/\D/g, '').slice(-4) !== s.buyer.phone.slice(-4)) err('آخر 4 أرقام من هاتفك لا تطابق رقم المشتري في الشحنة');
  if (db().complaints.some(c => c.shipmentId === s.id && c.status === 'open')) err('توجد شكوى مفتوحة على هذه الشحنة');
  const KINDS = { notarrived: 'لم تصل', different: 'البضاعة مختلفة عن الوصف', fake: 'بضاعة مقلّدة أو تالفة', price: 'سعر أعلى من المتفق عليه', other: 'أخرى' };
  const c = { id: 'K' + String(db().complaints.length + 1).padStart(4, '0'), at, shipmentId: s.id, merchantId: s.merchantId, kind: KINDS[kind] ? kind : 'other', kindText: KINDS[kind] || KINDS.other, text: String(text || '').slice(0, 500), status: 'open', decision: '', reply: '' };
  db().complaints.push(c);
  s.events.push({ at, type: 'complaint', by: 'buyer', text: 'قدّم المشتري شكوى: ' + c.kindText });
  notify('merchant:' + s.merchantId, `شكوى جديدة ${c.id} على الشحنة ${s.code}: ${c.kindText}`, at);
  notify('role:consumer', `شكوى جديدة ${c.id}: ${c.kindText}`, at);
  log(null, 'شكوى مشترٍ', c.id, `${s.code} — ${c.kindText}`, at);
  return c;
}
function publicReport(p, at) {
  at = at || now();
  const url = String(p.url || '').trim().slice(0, 200);
  if (url.length < 4) err('اكتب رابط الصفحة أو اسمها');
  const lic = String(p.license || '').trim().toUpperCase();
  const m = lic ? db().merchants.find(x => x.license === lic) : null;
  const rep = { id: 'B' + String(db().reports.length + 1).padStart(4, '0'), at, url, channel: CHANNELS[p.channel] ? p.channel : 'facebook', license: lic, merchantId: m ? m.id : null, note: String(p.note || '').slice(0, 300), status: 'open', action: '' };
  db().reports.push(rep);
  notify('role:cmc', `بلاغ جديد ${rep.id}: ${url}`, at);
  log(null, 'بلاغ عن صفحة', rep.id, url, at);
  return rep;
}
function merchantReply(user, complaintId, reply) {
  const c = byId('complaints', complaintId);
  if (!c || c.merchantId !== user.merchantId) err('الشكوى ليست لمتجرك', 403);
  c.reply = String(reply || '').slice(0, 400);
  log(user, 'رد التاجر على شكوى', c.id, c.reply);
  return c;
}
function consumerDecide(user, id, decision, note) {
  const c = byId('complaints', id);
  if (!c) err('الشكوى غير موجودة');
  if (c.status !== 'open') err('أُغلقت الشكوى مسبقاً');
  const D = { refund: 'إلزام التاجر بالاسترجاع أو الاستبدال', rejected: 'رُدّت الشكوى', refer: 'أُحيلت إلى وزارة التجارة لتعليق الإجازة' };
  if (!D[decision]) err('اختر القرار');
  c.status = 'closed'; c.decision = decision; c.decisionText = D[decision]; c.note = String(note || '').slice(0, 300); c.closedAt = now();
  if (decision === 'refer') notify('role:trade', `إحالة من حماية المستهلك: الشكوى ${c.id} على ${byId('merchants', c.merchantId).name}`);
  notify('merchant:' + c.merchantId, `قرار الشكوى ${c.id}: ${D[decision]}`);
  log(user, 'قرار شكوى', c.id, D[decision]);
  return c;
}

// ── وزارة التجارة: الإجازات ──
function nextLicense() { db().seq.license++; return 'IQ-EC-2026-' + String(db().seq.license).padStart(6, '0'); }
function tradeAct(user, merchantId, act, reason, at) {
  at = at || now();
  const m = byId('merchants', merchantId);
  if (!m) err('التاجر غير موجود');
  const R = String(reason || '').trim();
  if (act === 'approve') {
    if (m.status !== 'pending') err('الطلب ليس بانتظار القرار');
    m.status = 'active'; m.license = nextLicense(); m.licensedAt = at;
    notify('merchant:' + m.id, `صدرت إجازتك ${m.license}. اكتبها في صفحتك وفي كل بث.`, at);
  } else if (act === 'reject') {
    if (m.status !== 'pending') err('الطلب ليس بانتظار القرار');
    if (R.length < 4) err('اكتب سبب الرفض');
    m.status = 'rejected';
  } else if (act === 'suspend') {
    if (m.status !== 'active') err('الإجازة ليست فعّالة');
    if (R.length < 4) err('اكتب سبب التعليق');
    m.status = 'suspended';
    notify('merchant:' + m.id, 'عُلّقت إجازتك: ' + R + '. شركات التوصيل لن تستلم طلباتك.', at);
  } else if (act === 'reinstate') {
    if (m.status !== 'suspended') err('الإجازة ليست معلّقة');
    m.status = 'active';
  } else err('إجراء غير معروف');
  m.decisions.push({ at, act, reason: R, by: user.username });
  log(user, { approve: 'إصدار إجازة', reject: 'رفض طلب إجازة', suspend: 'تعليق إجازة', reinstate: 'إعادة تفعيل إجازة' }[act], m.license || m.id, `${m.name}${R ? ' — ' + R : ''}`, at);
  return m;
}
function applyMerchant(p, at) {
  at = at || now();
  const name = String(p.name || '').trim(), owner = String(p.owner || '').trim();
  if (name.length < 3 || owner.length < 3) err('اكتب اسم المتجر واسمك الكامل');
  if (!/^\d{12}$/.test(String(p.nid || ''))) err('رقم البطاقة الموحدة 12 رقماً');
  if (!/^07\d{9}$/.test(String(p.phone || ''))) err('رقم الهاتف يبدأ بـ07 ويتكون من 11 رقماً');
  if (!TIERS[p.tier]) err('اختر الفئة');
  if (!CHANNELS[p.channel]) err('اختر مكان البيع');
  if (!GOVS.includes(p.gov)) err('اختر المحافظة');
  const username = String(p.username || '').trim().toLowerCase();
  if (!/^[a-z0-9._-]{4,24}$/.test(username)) err('اسم الدخول بالإنجليزية من 4 إلى 24 حرفاً');
  if (db().users.some(u => u.username === username)) err('اسم الدخول مستخدم، اختر غيره');
  if (String(p.password || '').length < 8) err('كلمة المرور 8 أحرف على الأقل');
  if (p.tier !== 'home' && !String(p.cr || '').trim()) err('التاجر والمنصة يحتاجان رقم السجل التجاري');
  const m = {
    id: 'M' + String(db().merchants.length + 1).padStart(3, '0'), name, owner, tier: p.tier, channel: p.channel, gov: p.gov,
    page: String(p.page || '').slice(0, 120), phone: String(p.phone), nidLast4: String(p.nid).slice(-4), cr: String(p.cr || ''), taxId: String(p.taxId || ''),
    category: db().categories[p.category] ? p.category : 'general', status: 'pending', license: null, at, decisions: [],
  };
  db().merchants.push(m);
  db().users.push({ username, pass: S.hashPassword(p.password), name: owner, role: 'merchant', merchantId: m.id });
  notify('role:trade', `طلب إجازة جديد: ${m.name} (${TIERS[m.tier]})`, at);
  log(null, 'طلب إجازة', m.id, `${m.name} — ${TIERS[m.tier]}`, at);
  return m;
}

// ── التقييس والجودة: العينات وأوامر السحب ──
function takeSample(user, shipmentId, at) {
  at = at || now();
  const s = byId('shipments', shipmentId);
  if (!s) err('الشحنة غير موجودة');
  if (!['picked', 'transit'].includes(s.status)) err('العينة تُسحب من الشحنات في مخازن شركات التوصيل فقط');
  const reg = s.items.find(it => db().categories[it.category].regulated);
  if (!reg) err('الشحنة لا تحوي فئة خاضعة للفحص');
  if (db().samples.some(x => x.shipmentId === s.id)) err('سُحبت عينة من هذه الشحنة مسبقاً');
  const smp = { id: 'S' + String(db().samples.length + 1).padStart(4, '0'), at, shipmentId: s.id, merchantId: s.merchantId, category: reg.category, item: reg.name, result: 'pending', note: '' };
  db().samples.push(smp);
  s.events.push({ at, type: 'sample', by: user.username, text: 'سُحبت عينة للفحص المختبري من مخزن شركة التوصيل' });
  log(user, 'سحب عينة', smp.id, `${s.code} — ${reg.name}`, at);
  return smp;
}
function sampleResult(user, sampleId, result, note, at) {
  at = at || now();
  const smp = byId('samples', sampleId);
  if (!smp) err('العينة غير موجودة');
  if (smp.result !== 'pending') err('سُجّلت النتيجة مسبقاً');
  if (!['pass', 'fail'].includes(result)) err('اختر النتيجة');
  if (result === 'fail' && String(note || '').trim().length < 4) err('اكتب سبب عدم المطابقة');
  smp.result = result; smp.note = String(note || '').slice(0, 300); smp.resultAt = at;
  log(user, 'نتيجة فحص', smp.id, result === 'pass' ? 'مطابقة' : 'غير مطابقة: ' + smp.note, at);
  if (result === 'fail') {
    const rc = { id: 'RC' + String(db().recalls.length + 1).padStart(3, '0'), at, merchantId: smp.merchantId, category: smp.category, reason: smp.note, sampleId: smp.id, active: true, held: 0 };
    for (const s of db().shipments) {
      if (s.merchantId === smp.merchantId && ['created', 'picked', 'transit'].includes(s.status) && s.items.some(it => it.category === smp.category)) {
        s.status = 'held'; rc.held++;
        s.events.push({ at, type: 'held', by: user.username, text: 'أُوقفت بأمر سحب: ' + smp.note });
      }
    }
    db().recalls.push(rc);
    const m = byId('merchants', smp.merchantId);
    notify('merchant:' + m.id, `أمر سحب على فئة «${db().categories[smp.category].name}»: ${smp.note}. أُوقفت ${rc.held} شحنة.`, at);
    notify('role:consumer', `أمر سحب ${rc.id} على ${m.name}`, at);
    log(user, 'أمر سحب', rc.id, `${m.name} — أُوقفت ${rc.held} شحنة`, at);
  }
  return smp;
}
function liftRecall(user, id, note) {
  const rc = byId('recalls', id);
  if (!rc || !rc.active) err('أمر السحب غير فعّال');
  if (String(note || '').trim().length < 4) err('اكتب سبب الرفع');
  rc.active = false; rc.liftedAt = now(); rc.liftNote = note;
  log(user, 'رفع أمر سحب', rc.id, note);
  return rc;
}

// ── الكمارك: البيان المسبق للطلبات من الخارج ──
function declare(user, p, at) {
  at = at || now();
  const m = byId('merchants', user.merchantId);
  if (!m || m.tier !== 'platform') err('البيان المسبق للمنصات ووسطاء الاستيراد فقط', 403);
  if (m.status !== 'active') err('الإجازة غير فعّالة');
  const items = (p.items || []).map(it => ({ name: String(it.name || '').slice(0, 80), category: it.category, qty: Math.max(1, +it.qty || 1), price: Math.round(+it.price || 0) })).filter(it => it.name && it.price > 0 && db().categories[it.category]);
  if (!items.length) err('أضف قطعة واحدة على الأقل');
  const b = p.buyer || {};
  if (!b.name || !/^07\d{9}$/.test(String(b.phone || '')) || !GOVS.includes(b.gov)) err('أكمل بيانات المشتري');
  if (!byId('couriers', p.courierId)) err('اختر شركة التوصيل');
  const d = {
    id: 'D' + String(db().declarations.length + 1).padStart(4, '0'), at, merchantId: m.id, source: String(p.source || 'تركيا').slice(0, 40), port: String(p.port || 'مطار بغداد الدولي').slice(0, 40),
    items, value: sum(items, it => it.qty * it.price), buyer: { name: String(b.name), phone: String(b.phone), gov: b.gov, address: String(b.address || '') }, courierId: p.courierId, status: 'submitted', duty: 0, dutyPct: 0, shipmentId: null,
  };
  db().declarations.push(d);
  notify('role:customs', `بيان مسبق جديد ${d.id} من ${m.name}`, at);
  log(user, 'بيان مسبق', d.id, `${d.value} د.ع من ${d.source}`, at);
  return d;
}
function customsAct(user, id, act, p, at) {
  at = at || now();
  const d = byId('declarations', id);
  if (!d) err('البيان غير موجود');
  if (d.status !== 'submitted') err('البيان ليس بانتظار القرار');
  if (act === 'clear') {
    const pct = Math.max(0, Math.min(30, +p.dutyPct || 0));
    d.dutyPct = pct; d.duty = roundFee(d.value * pct / 100); d.status = 'cleared'; d.clearedAt = at;
    ledger({ at, type: 'customs_duty', amount: d.duty, declaration: d.id, merchant: d.merchantId, note: `رسم كمركي ${pct}% على طرد منخفض القيمة` });
    const s = createShipment(user, { merchantId: d.merchantId, courierId: d.courierId, buyer: d.buyer, items: d.items, pay: 'epay', origin: 'import', declarationId: d.id }, at);
    d.shipmentId = s.id;
    s.events.push({ at, type: 'customs', by: user.username, text: `خُلّص كمركياً في ${d.port} برسم ${d.duty.toLocaleString('en')} د.ع` });
    notify('merchant:' + d.merchantId, `خُلّص البيان ${d.id} وصدر رمز الشحنة ${s.code}`, at);
    log(user, 'تخليص كمركي', d.id, `رسم ${d.duty} د.ع`, at);
  } else if (act === 'hold') {
    if (String(p.reason || '').trim().length < 4) err('اكتب سبب الحجز');
    d.status = 'held'; d.reason = p.reason;
    notify('merchant:' + d.merchantId, `حُجز البيان ${d.id}: ${p.reason}`, at);
    log(user, 'حجز بيان', d.id, p.reason, at);
  } else err('إجراء غير معروف');
  return d;
}

// ── هيئة الإعلام والاتصالات ──
function cmcAct(user, id, act, note) {
  const r = byId('reports', id);
  if (!r) err('البلاغ غير موجود');
  if (r.status !== 'open') err('أُغلق البلاغ مسبقاً');
  const A = { notify: 'إنذار صاحب الصفحة بإظهار رقم الإجازة', takedown: 'طلب حجب الصفحة من المنصة', resolved: 'حُلّ — الصفحة مُجازة وتعرض رقمها' };
  if (!A[act]) err('اختر الإجراء');
  r.status = 'closed'; r.action = act; r.actionText = A[act]; r.note = String(note || '').slice(0, 300); r.closedAt = now();
  log(user, 'إجراء على بلاغ', r.id, A[act]);
  return r;
}

// ── وزارة الاقتصاد الرقمي: الإعدادات والتعاميم ──
function setPhase(user, phase, reason) {
  if (!['zero', 'fee'].includes(phase)) err('مرحلة غير معروفة');
  if (String(reason || '').trim().length < 6) err('اكتب سند القرار (مثلاً رقم القانون أو الكتاب)');
  const st = db().settings;
  if (st.phase === phase) err('المرحلة مفعّلة أصلاً');
  st.phase = phase; st.phaseReason = reason; st.phaseAt = now();
  log(user, 'تغيير مرحلة النظام', phase, reason);
  const text = phase === 'fee' ? 'بدأت المرحلة الأولى: يُجبى الرسم على الشحنات الجديدة. السند: ' + reason : 'عادت المرحلة صفر: تسجيل بلا رسم. السند: ' + reason;
  for (const r of ['tax', 'trade', 'customs', 'cbi', 'audit']) notify('role:' + r, text);
  for (const c of db().couriers) notify('courier:' + c.id, text);
  return st;
}
function setRate(user, cat, rate) {
  const c = db().categories[cat];
  if (!c) err('فئة غير معروفة');
  const r = +rate;
  if (!(r >= 0 && r <= 20)) err('النسبة بين 0 و20%');
  const old = c.rate; c.rate = Math.round(r * 10) / 10;
  log(user, 'تعديل نسبة رسم', cat, `${c.name}: ${old}% ← ${c.rate}% (تُطبّق على الشحنات الجديدة فقط)`);
  return c;
}
function circular(user, title, body) {
  title = String(title || '').trim(); body = String(body || '').trim();
  if (title.length < 4 || body.length < 10) err('اكتب عنوان التعميم ونصّه');
  const c = { id: 'T' + String(db().circulars.length + 1).padStart(3, '0'), at: now(), title, body, by: user.username };
  db().circulars.push(c);
  for (const r of Object.keys(ROLES)) if (r !== 'digital' && r !== 'merchant' && r !== 'courier') notify('role:' + r, 'تعميم: ' + title);
  for (const m of db().merchants) if (m.status === 'active') notify('merchant:' + m.id, 'تعميم: ' + title);
  for (const cc of db().couriers) notify('courier:' + cc.id, 'تعميم: ' + title);
  log(user, 'إصدار تعميم', c.id, title);
  return c;
}

// ── الإحصاءات المجمّعة ──
function aggregate(list) {
  const out = { count: list.length, value: 0, computed: 0, due: 0, byGov: {}, byCat: {}, byChannel: {}, byDay: {}, byPay: { cod: 0, epay: 0 } };
  for (const s of list) {
    if (s.status === 'refused') continue;
    out.value += s.value; out.computed += s.feeComputed; out.due += s.feeDue;
    const g = out.byGov[s.buyer.gov] || (out.byGov[s.buyer.gov] = { n: 0, value: 0, due: 0 }); g.n++; g.value += s.value; g.due += s.feeDue;
    for (const it of s.items) { const c = out.byCat[it.category] || (out.byCat[it.category] = { n: 0, value: 0 }); c.n += it.qty; c.value += it.qty * it.price; }
    const m = byId('merchants', s.merchantId), ch = s.origin === 'import' ? 'import' : m.channel;
    const cc = out.byChannel[ch] || (out.byChannel[ch] = { n: 0, value: 0 }); cc.n++; cc.value += s.value;
    const d = out.byDay[dayKey(s.at)] || (out.byDay[dayKey(s.at)] = { n: 0, value: 0, due: 0 }); d.n++; d.value += s.value; d.due += s.feeDue;
    out.byPay[s.pay] += s.value;
  }
  return out;
}
function ledgerTotals() {
  const L = db().ledger;
  const t = { collected: 0, epay: 0, remitted: 0, customs: 0 };
  for (const e of L) {
    if (e.type === 'fee_collected') t.collected += e.amount;
    else if (e.type === 'fee_epay') t.epay += e.amount;
    else if (e.type === 'remittance') t.remitted += e.amount;
    else if (e.type === 'customs_duty') t.customs += e.amount;
  }
  return t;
}
function courierTable() {
  return db().couriers.map(c => {
    const ships = db().shipments.filter(s => s.courierId === c.id);
    const collected = sum(ships.filter(s => s.pay === 'cod' && s.collected), s => s.feeDue);
    const rem = db().remittances.filter(r => r.courierId === c.id);
    const bal = courierBalance(c.id);
    return {
      id: c.id, name: c.name, license: c.license, shipments: ships.length, delivered: ships.filter(s => s.status === 'delivered').length,
      collected, commission: sum(rem, r => r.commission) + bal.commission, remitted: sum(rem, r => r.amount), outstanding: bal.net,
      mismatch: sum(rem.filter(r => r.status === 'mismatch'), r => -r.diff), pending: rem.filter(r => r.status === 'sent').length,
    };
  });
}
function annualProjection() {
  const since = new Date(Date.now() - 30 * 864e5).toISOString();
  const recent = db().shipments.filter(s => s.at >= since && s.status !== 'refused');
  const v = sum(recent, s => s.value), c = sum(recent, s => s.feeComputed), d = sum(recent, s => s.feeDue);
  return { days: 30, value: v, computed: c, due: d, annualValue: Math.round(v * 365 / 30), annualComputed: Math.round(c * 365 / 30), annualDue: Math.round(d * 365 / 30) };
}

// ── تمثيل الشحنة لكل جهة ──
function shipmentPublic(s, role) {
  const m = byId('merchants', s.merchantId), c = byId('couriers', s.courierId), fs = feeState(s);
  const full = ['merchant', 'courier', 'audit', 'tax', 'consumer', 'quality', 'customs', 'inspector'].includes(role);
  return {
    id: s.id, code: s.code, at: s.at, status: s.status, statusText: STATUS[s.status], origin: s.origin,
    merchant: { id: m.id, name: m.name, license: m.license, status: m.status, tier: TIERS[m.tier], channel: CHANNELS[m.channel], page: m.page, gov: m.gov },
    courier: { id: c.id, name: c.name, license: c.license },
    buyer: { name: full ? s.buyer.name : s.buyer.name.split(' ')[0], phone: maskPhone(s.buyer.phone), gov: s.buyer.gov, address: role === 'courier' ? s.buyer.address : '' },
    items: s.items.map(it => ({ ...it, catName: db().categories[it.category].name, regulated: db().categories[it.category].regulated })),
    value: s.value, feeComputed: s.feeComputed, feeDue: s.feeDue, exempt: s.exempt, pay: s.pay, phase: s.phase, fee: fs,
    events: s.events, scans: s.scans, remitId: full ? s.remitId : undefined,
    complaint: db().complaints.find(k => k.shipmentId === s.id) || null,
  };
}
function shipmentRow(s) {
  const m = byId('merchants', s.merchantId), c = byId('couriers', s.courierId);
  return { id: s.id, code: s.code, at: s.at, status: s.status, statusText: STATUS[s.status], merchant: m.name, merchantId: m.id, courier: c.name, gov: s.buyer.gov, buyer: s.buyer.name, value: s.value, feeDue: s.feeDue, feeComputed: s.feeComputed, exempt: s.exempt, pay: s.pay, origin: s.origin, regulated: s.items.some(it => db().categories[it.category].regulated), cats: [...new Set(s.items.map(it => it.category))] };
}
function merchantRow(m) {
  const ships = db().shipments.filter(s => s.merchantId === m.id);
  return { ...m, tierText: TIERS[m.tier], channelText: CHANNELS[m.channel], shipments: ships.length, value: sum(ships, s => s.value), complaints: db().complaints.filter(c => c.merchantId === m.id).length, openComplaints: db().complaints.filter(c => c.merchantId === m.id && c.status === 'open').length, recalls: db().recalls.filter(r => r.merchantId === m.id && r.active).length };
}
function notesFor(user) {
  const keys = ['role:' + user.role];
  if (user.merchantId) keys.push('merchant:' + user.merchantId);
  if (user.courierId) keys.push('courier:' + user.courierId);
  return db().notes.filter(n => keys.includes(n.to)).slice(-30).reverse();
}

const recentFirst = (a, b) => (a.at < b.at ? 1 : -1);

// ── ما تراه كل جهة ──
function view(user) {
  const D = db(), base = { me: { username: user.username, name: user.name, role: user.role, roleName: ROLES[user.role].name, place: user.place || '' }, notes: notesFor(user), settings: D.settings, categories: D.categories, govs: GOVS, channels: CHANNELS, tiers: TIERS, couriers: D.couriers.map(c => ({ id: c.id, name: c.name, license: c.license })) };
  const ships = D.shipments;
  switch (user.role) {
    case 'merchant': {
      const m = byId('merchants', user.merchantId);
      const mine = ships.filter(s => s.merchantId === m.id).sort(recentFirst);
      const mk = monthKey(now());
      return { ...base, merchant: merchantRow(m), monthSales: merchantMonthSales(m.id, now()), shipments: mine.slice(0, 120).map(shipmentRow), agg: aggregate(mine.filter(s => monthKey(s.at) === mk)), complaints: D.complaints.filter(c => c.merchantId === m.id).sort(recentFirst).map(c => ({ ...c, code: byId('shipments', c.shipmentId).code })), recalls: D.recalls.filter(r => r.merchantId === m.id), declarations: D.declarations.filter(d => d.merchantId === m.id).sort(recentFirst).map(d => ({ ...d, code: d.shipmentId ? byId('shipments', d.shipmentId).code : null })), violations: D.violations.filter(v => v.merchantId === m.id) };
    }
    case 'courier': {
      const c = byId('couriers', user.courierId);
      const mine = ships.filter(s => s.courierId === c.id);
      const active = mine.filter(s => ['created', 'picked', 'transit'].includes(s.status)).sort(recentFirst);
      return { ...base, courier: c, balance: { ...courierBalance(c.id), shipments: undefined, count: courierBalance(c.id).shipments.length }, active: active.slice(0, 150).map(shipmentRow), done: mine.filter(s => !['created', 'picked', 'transit'].includes(s.status)).sort(recentFirst).slice(0, 40).map(shipmentRow), remittances: D.remittances.filter(r => r.courierId === c.id).sort(recentFirst).map(r => ({ ...r, shipments: r.shipments.length })), row: courierTable().find(r => r.id === c.id) };
    }
    case 'tax': {
      const viol = D.violations.filter(v => v.kind === 'undervalue');
      return { ...base, totals: ledgerTotals(), agg: aggregate(ships), couriers: courierTable(), remittances: D.remittances.slice().sort(recentFirst).slice(0, 60).map(r => ({ ...r, shipments: r.shipments.length, courier: byId('couriers', r.courierId).name })), ledger: D.ledger.slice(-40).reverse(), chain: S.chainVerify('ledger'), violations: viol.map(v => ({ ...v, code: byId('shipments', v.shipmentId).code, merchant: byId('merchants', v.merchantId).name })), projection: annualProjection() };
    }
    case 'digital': {
      const act = D.merchants.filter(m => m.status === 'active');
      return { ...base, agg: aggregate(ships), totals: ledgerTotals(), projection: annualProjection(), merchants: { total: D.merchants.length, active: act.length, pending: D.merchants.filter(m => m.status === 'pending').length, suspended: D.merchants.filter(m => m.status === 'suspended').length, byTier: Object.fromEntries(Object.keys(TIERS).map(t => [t, act.filter(m => m.tier === t).length])) }, couriers: courierTable(), complaints: { open: D.complaints.filter(c => c.status === 'open').length, total: D.complaints.length }, recalls: D.recalls.filter(r => r.active).length, reports: D.reports.filter(r => r.status === 'open').length, scans: { checkpoint: sum(ships, s => s.scans.filter(x => x.role === 'checkpoint').length), inspector: sum(ships, s => s.scans.filter(x => x.role === 'inspector').length) }, violations: D.violations.length, circulars: D.circulars.slice().reverse(), history: D.phaseHistory || [] };
    }
    case 'trade':
      return { ...base, merchants: D.merchants.map(merchantRow).sort((a, b) => (a.status === 'pending' ? -1 : 0) - (b.status === 'pending' ? -1 : 0) || (a.at < b.at ? 1 : -1)), referrals: D.complaints.filter(c => c.decision === 'refer').map(c => ({ ...c, merchant: byId('merchants', c.merchantId).name })) };
    case 'customs':
      return { ...base, declarations: D.declarations.slice().sort(recentFirst).map(d => ({ ...d, merchant: byId('merchants', d.merchantId).name, code: d.shipmentId ? byId('shipments', d.shipmentId).code : null })), totals: ledgerTotals(), imports: aggregate(ships.filter(s => s.origin === 'import')) };
    case 'quality': {
      const hub = ships.filter(s => ['picked', 'transit'].includes(s.status) && s.items.some(it => D.categories[it.category].regulated)).sort(recentFirst);
      return { ...base, hub: hub.slice(0, 80).map(s => ({ ...shipmentRow(s), sampled: D.samples.some(x => x.shipmentId === s.id), regItems: s.items.filter(it => D.categories[it.category].regulated).map(it => it.name).join('، ') })), samples: D.samples.slice().sort(recentFirst).map(x => ({ ...x, code: byId('shipments', x.shipmentId).code, merchant: byId('merchants', x.merchantId).name, catName: D.categories[x.category].name })), recalls: D.recalls.slice().reverse().map(r => ({ ...r, merchant: byId('merchants', r.merchantId).name, catName: D.categories[r.category].name })), undeclared: D.violations.filter(v => v.kind === 'undeclared').map(v => ({ ...v, code: byId('shipments', v.shipmentId).code, merchant: byId('merchants', v.merchantId).name })) };
    }
    case 'consumer':
      return { ...base, complaints: D.complaints.slice().sort(recentFirst).map(c => ({ ...c, code: byId('shipments', c.shipmentId).code, merchant: byId('merchants', c.merchantId).name, license: byId('merchants', c.merchantId).license })), recalls: D.recalls.filter(r => r.active).map(r => ({ ...r, merchant: byId('merchants', r.merchantId).name, catName: D.categories[r.category].name })), topMerchants: D.merchants.map(merchantRow).filter(m => m.complaints > 0).sort((a, b) => b.complaints - a.complaints).slice(0, 8) };
    case 'cmc':
      return { ...base, reports: D.reports.slice().sort(recentFirst).map(r => ({ ...r, merchant: r.merchantId ? byId('merchants', r.merchantId).name : null, channelText: CHANNELS[r.channel] })), platforms: D.foreignPlatforms, liveSellers: D.merchants.filter(m => m.channel === 'live' || m.channel === 'tiktok').map(merchantRow) };
    case 'cbi': {
      const agg = aggregate(ships);
      return { ...base, agg, totals: ledgerTotals(), couriers: courierTable().map(c => ({ name: c.name, collected: c.collected, remitted: c.remitted, outstanding: c.outstanding })), providers: D.payProviders };
    }
    case 'audit':
      return { ...base, agg: aggregate(ships), totals: ledgerTotals(), couriers: courierTable(), auditLog: D.audit.slice(-80).reverse(), ledger: D.ledger.slice(-30).reverse(), chains: { ledger: S.chainVerify('ledger'), audit: S.chainVerify('audit') }, counts: { merchants: D.merchants.length, shipments: ships.length, complaints: D.complaints.length, samples: D.samples.length, recalls: D.recalls.length, declarations: D.declarations.length, violations: D.violations.length } };
    case 'inspector':
    case 'checkpoint': {
      const mine = [];
      for (const s of ships) for (const x of s.scans) if (x.by === user.username) mine.push({ ...x, code: s.code, merchant: byId('merchants', s.merchantId).name, value: s.value });
      mine.sort(recentFirst);
      const sample = ships.filter(s => ['picked', 'transit'].includes(s.status)).sort(recentFirst).slice(0, 6).map(shipmentRow);
      return { ...base, scans: mine.slice(0, 40), nearby: sample, saved: user.role === 'checkpoint' ? mine.filter(x => x.result === 'pass').length : 0 };
    }
  }
  return base;
}

// ── توجيه الأفعال مع التحقق من الصلاحية ──
function act(user, a, p) {
  const need = roles => { if (!roles.includes(user.role)) err('هذا الإجراء ليس من صلاحية جهتك', 403); };
  switch (a) {
    case 'shipment.create': need(['merchant']); return shipmentPublic(createShipment(user, { ...p, merchantId: user.merchantId }), 'merchant');
    case 'shipment.pickup': need(['courier']); return pickup(user, p.id);
    case 'shipment.dispatch': need(['courier']); return dispatch(user, p.id);
    case 'shipment.deliver': need(['courier']); return deliver(user, p.id);
    case 'shipment.return': need(['courier']); return returnShipment(user, p.id, p.reason);
    case 'courier.remit': need(['courier']); return remit(user);
    case 'courier.settle': need(['courier']); return settleDiff(user, p.id);
    case 'tax.reconcile': need(['tax']); return reconcile(user, p.id);
    case 'scan': need(['inspector', 'checkpoint']); return scan(user, p.code, p.kind, p);
    case 'complaint.reply': need(['merchant']); return merchantReply(user, p.id, p.reply);
    case 'complaint.decide': need(['consumer']); return consumerDecide(user, p.id, p.decision, p.note);
    case 'trade.act': need(['trade']); return tradeAct(user, p.id, p.act, p.reason);
    case 'quality.sample': need(['quality']); return takeSample(user, p.id);
    case 'quality.result': need(['quality']); return sampleResult(user, p.id, p.result, p.note);
    case 'quality.lift': need(['quality']); return liftRecall(user, p.id, p.note);
    case 'customs.declare': need(['merchant']); return declare(user, p);
    case 'customs.act': need(['customs']); return customsAct(user, p.id, p.act, p);
    case 'cmc.act': need(['cmc']); return cmcAct(user, p.id, p.act, p.note);
    case 'digital.phase': need(['digital']); return setPhase(user, p.phase, p.reason);
    case 'digital.rate': need(['digital']); return setRate(user, p.cat, p.rate);
    case 'digital.circular': need(['digital']); return circular(user, p.title, p.body);
    case 'fee.preview': need(['merchant']); {
      const m = byId('merchants', user.merchantId);
      const items = (p.items || []).filter(it => it.price > 0 && db().categories[it.category]).map(it => ({ ...it, qty: Math.max(1, +it.qty || 1), price: +it.price }));
      return items.length ? computeFee(m, items, now()) : { value: 0, computed: 0, due: 0, exempt: '' };
    }
  }
  err('إجراء غير معروف');
}

// ── التصدير للجهات الرقابية والضرائب ──
function csv(rows, cols) {
  const esc = v => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return '﻿' + cols.map(c => esc(c[1])).join(',') + '\n' + rows.map(r => cols.map(c => esc(typeof c[0] === 'function' ? c[0](r) : r[c[0]])).join(',')).join('\n');
}
function exportCsv(user, what) {
  const allowed = { shipments: ['audit', 'tax', 'digital'], ledger: ['audit', 'tax'], audit: ['audit'], merchants: ['audit', 'trade', 'digital'] };
  if (!allowed[what] || !allowed[what].includes(user.role)) err('التصدير غير متاح لجهتك', 403);
  log(user, 'تصدير', what, '');
  const D = db();
  if (what === 'shipments') return csv(D.shipments.map(shipmentRow), [['code', 'رمز الشحنة'], ['at', 'التاريخ'], ['merchant', 'التاجر'], ['courier', 'شركة التوصيل'], ['gov', 'المحافظة'], ['value', 'القيمة د.ع'], ['feeComputed', 'الرسم المحتسب'], ['feeDue', 'الرسم المستحق'], ['exempt', 'سبب الإعفاء'], ['pay', 'طريقة الدفع'], ['statusText', 'الحالة'], ['origin', 'المصدر']]);
  if (what === 'ledger') return csv(D.ledger, [['seq', 'التسلسل'], ['at', 'التاريخ'], ['type', 'النوع'], ['amount', 'المبلغ د.ع'], ['shipment', 'الشحنة'], ['courier', 'شركة التوصيل'], ['remit', 'التحويل'], ['note', 'ملاحظة'], ['prev', 'بصمة السابق'], ['hash', 'البصمة']]);
  if (what === 'audit') return csv(D.audit, [['seq', 'التسلسل'], ['at', 'التاريخ'], ['who', 'المستخدم'], ['role', 'الجهة'], ['action', 'الفعل'], ['ref', 'المرجع'], ['detail', 'التفاصيل'], ['hash', 'البصمة']]);
  if (what === 'merchants') return csv(D.merchants.map(merchantRow), [['id', 'المعرّف'], ['name', 'المتجر'], ['owner', 'المالك'], ['tierText', 'الفئة'], ['channelText', 'مكان البيع'], ['gov', 'المحافظة'], ['license', 'رقم الإجازة'], ['status', 'الحالة'], ['shipments', 'الشحنات'], ['value', 'المبيعات د.ع'], ['complaints', 'الشكاوى']]);
}

function publicStats() {
  const D = db(), agg = aggregate(D.shipments);
  return { merchants: D.merchants.filter(m => m.status === 'active').length, couriers: D.couriers.length, shipments: agg.count, value: agg.value, complaintsClosed: D.complaints.filter(c => c.status === 'closed').length, phase: D.settings.phase };
}
function verifyLicense(q) {
  q = String(q || '').trim().toUpperCase();
  if (q.length < 6) err('اكتب رقم الإجازة كاملاً');
  const m = db().merchants.find(x => x.license === q);
  if (!m) return { found: false };
  return { found: true, name: m.name, tier: TIERS[m.tier], channel: CHANNELS[m.channel], gov: m.gov, status: m.status, page: m.page };
}

module.exports = { setClock, GOVS, ROLES, TIERS, CHANNELS, STATUS, createShipment, pickup, dispatch, deliver, returnShipment, remit, reconcile, scan, publicComplaint, publicReport, tradeAct, applyMerchant, takeSample, sampleResult, declare, customsAct, cmcAct, consumerDecide, merchantReply, circular, log, ledger, notify, computeFee, view, act, shipmentByCode, shipmentPublic, exportCsv, publicStats, verifyLicense, feeState };
