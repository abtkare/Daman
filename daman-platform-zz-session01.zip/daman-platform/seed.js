// بيانات العرض لـ«ضمان»: 30 يوماً من نشاط واقعي، تُبنى بالترتيب الزمني عبر منطق النظام نفسه.
// كل الأسماء تجريبية. البيانات تُعاد من جديد عند إعادة تشغيل الخادم بلا ملف محفوظ.
'use strict';
const S = require('./store');

const CATEGORIES = {
  food: { name: 'غذاء ومواد أساسية', rate: 0, regulated: false },
  medicine: { name: 'أدوية وحليب أطفال', rate: 0, regulated: true },
  general: { name: 'سلع عامة وملابس', rate: 2, regulated: false },
  cosmetics: { name: 'مستحضرات تجميل', rate: 2, regulated: true },
  supplements: { name: 'مكملات غذائية', rate: 2, regulated: true },
  toys: { name: 'ألعاب أطفال', rate: 2, regulated: true },
  electronics: { name: 'أجهزة كهربائية وإلكترونية', rate: 2, regulated: true },
  luxury: { name: 'كماليات (ذهب، عطور، ساعات)', rate: 5, regulated: false },
};

const CATALOG = {
  perfume: [['عطر عود 100 مل', 'luxury', 45000], ['دهن عود 12 مل', 'luxury', 75000], ['طقم عطور هدية', 'luxury', 120000], ['بخور معطّر', 'general', 8000]],
  clothing: [['فستان سهرة', 'general', 55000], ['عباءة', 'general', 40000], ['حقيبة يد', 'general', 30000], ['حذاء رياضي', 'general', 35000], ['قميص رجالي', 'general', 18000]],
  toys: [['سيارة تحكم عن بعد', 'toys', 32000], ['دمية', 'toys', 15000], ['مكعبات بناء', 'toys', 22000], ['دراجة أطفال', 'toys', 85000]],
  electronics: [['سماعة لاسلكية', 'electronics', 25000], ['شاحن سريع', 'electronics', 12000], ['ساعة ذكية', 'electronics', 60000], ['خلاط كهربائي', 'electronics', 45000], ['مكواة بخار', 'electronics', 38000]],
  supplements: [['بروتين 2 كغم', 'supplements', 85000], ['فيتامين د', 'supplements', 15000], ['كرياتين', 'supplements', 40000]],
  food: [['كليجة 1 كغم', 'food', 12000], ['تمر برحي 2 كغم', 'food', 10000], ['حلويات مشكّلة', 'food', 20000], ['دبس تمر', 'food', 6000]],
  cosmetics: [['كريم مرطّب', 'cosmetics', 18000], ['أحمر شفاه', 'cosmetics', 9000], ['سيروم للبشرة', 'cosmetics', 25000], ['واقي شمس', 'cosmetics', 16000]],
  medicine: [['حليب أطفال', 'medicine', 22000], ['جهاز قياس الضغط', 'medicine', 35000], ['مكمل حديد للحوامل', 'medicine', 12000]],
  books: [['رواية', 'general', 12000], ['قاموس', 'general', 25000], ['دفتر وأقلام', 'general', 7000]],
  furniture: [['طاولة قهوة', 'general', 120000], ['رف خشبي', 'general', 60000], ['كرسي مكتب', 'general', 95000]],
  gold: [['خاتم ذهب عيار 21', 'luxury', 450000], ['سلسلة ذهب', 'luxury', 380000]],
  watches: [['ساعة يد رجالية', 'luxury', 150000], ['ساعة يد نسائية', 'luxury', 120000]],
  tools: [['عدّة مفكات', 'general', 18000], ['مثقب كهربائي', 'electronics', 70000]],
  imports: [['حذاء رياضي مستورد', 'general', 65000], ['حقيبة سفر', 'general', 90000], ['سماعة رأس', 'electronics', 55000], ['عطر مستورد', 'luxury', 85000], ['ملابس أطفال', 'general', 30000]],
};

// [المعرّف، الاسم، المالك، الفئة، مكان البيع، المحافظة، أصناف البضاعة، الحالة، الصفحة، الوزن في الطلبات]
const MERCHANTS = [
  ['M001', 'بيت العطور النجفية', 'حيدر عبد الأمير', 'trader', 'instagram', 'النجف', ['perfume'], 'active', 'instagram.com/bait.alotour', 5],
  ['M002', 'أزياء رزان', 'رزان سعد', 'home', 'instagram', 'بغداد', ['clothing'], 'active', 'instagram.com/razan.style', 4],
  ['M003', 'ألعاب كوكي', 'علي جاسم', 'trader', 'facebook', 'البصرة', ['toys'], 'active', 'facebook.com/cookie.toys', 4],
  ['M004', 'الجوهرة للإلكترونيات', 'مصطفى كريم', 'trader', 'website', 'بغداد', ['electronics'], 'active', 'aljawhara.iq', 6],
  ['M005', 'فِت عراق للمكملات', 'أحمد ستار', 'trader', 'tiktok', 'بغداد', ['supplements'], 'active', 'tiktok.com/@fit.iraq', 4],
  ['M006', 'مطبخ أم حسن', 'زينب محمد', 'home', 'facebook', 'كربلاء', ['food'], 'active', 'facebook.com/um.hassan.kitchen', 3],
  ['M007', 'جمالك للعناية', 'نور الهدى عباس', 'trader', 'live', 'بابل', ['cosmetics'], 'active', 'tiktok.com/@jamalik.live', 5],
  ['M008', 'حقائب ليالي', 'ليالي فاضل', 'home', 'tiktok', 'البصرة', ['clothing'], 'active', 'tiktok.com/@layali.bags', 3],
  ['M009', 'عالم الهواتف', 'يونس ذنون', 'trader', 'facebook', 'نينوى', ['electronics'], 'active', 'facebook.com/phones.world.mosul', 4],
  ['M010', 'صيدلية الشفاء أونلاين', 'د. سجاد حسين', 'trader', 'website', 'النجف', ['medicine'], 'active', 'alshifa-pharmacy.iq', 3],
  ['M011', 'مكتبة الرافدين', 'عمر خليل', 'trader', 'website', 'بغداد', ['books'], 'active', 'rafidain-books.iq', 2],
  ['M012', 'أثاث البيت الحديث', 'قاسم مهدي', 'trader', 'facebook', 'ديالى', ['furniture'], 'active', 'facebook.com/modern.home.diyala', 2],
  ['M013', 'حلويات سما', 'سما رعد', 'home', 'instagram', 'بغداد', ['food'], 'active', 'instagram.com/sama.sweets', 3],
  ['M014', 'الذهب الأصيل', 'محمد صادق', 'trader', 'instagram', 'بغداد', ['gold'], 'active', 'instagram.com/alasil.gold', 2],
  ['M015', 'ركن الأطفال', 'حسين فلاح', 'trader', 'facebook', 'ذي قار', ['toys', 'clothing'], 'active', 'facebook.com/kids.corner.nasiriyah', 3],
  ['M016', 'تمور البصرة', 'عبد الله ناصر', 'trader', 'website', 'البصرة', ['food'], 'active', 'basra-dates.iq', 2],
  ['M017', 'عدّة المهندس', 'كرار طالب', 'trader', 'facebook', 'واسط', ['tools'], 'active', 'facebook.com/engineer.tools', 2],
  ['M018', 'إكسسوارات ميس', 'ميس علي', 'home', 'tiktok', 'ميسان', ['clothing'], 'active', 'tiktok.com/@mais.acc', 2],
  ['M019', 'ساعات كربلاء', 'رضا حمزة', 'trader', 'live', 'كربلاء', ['watches'], 'active', 'tiktok.com/@karbala.watches', 2],
  ['M020', 'جسر للطلب من الخارج', 'شركة جسر للتجارة الإلكترونية', 'platform', 'website', 'بغداد', ['imports'], 'active', 'jisr.iq', 0],
  ['M021', 'طلبيتك', 'شركة طلبيتك المحدودة', 'platform', 'website', 'البصرة', ['imports'], 'active', 'talabitak.iq', 0],
  ['M022', 'متجر الأناقة', 'سارة يوسف', 'trader', 'instagram', 'الأنبار', ['clothing'], 'pending', 'instagram.com/anaqa.store', 0],
  ['M023', 'نور ستايل', 'نور عادل', 'home', 'live', 'صلاح الدين', ['clothing'], 'pending', 'tiktok.com/@noor.style.live', 0],
  ['M024', 'عطور الأمل', 'أمل كاظم', 'home', 'tiktok', 'المثنى', ['perfume'], 'pending', 'tiktok.com/@amal.perfumes', 0],
  ['M025', 'هواتف الصفوة', 'باسم عدنان', 'trader', 'facebook', 'القادسية', ['electronics'], 'pending', 'facebook.com/safwa.phones', 0],
];

const COURIERS = [
  ['C01', 'برق للتوصيل', 'CR-2026-0014'], ['C02', 'سريع الرافدين', 'CR-2026-0027'], ['C03', 'أمانة إكسبرس', 'CR-2026-0031'], ['C04', 'نجمة بغداد للشحن', 'CR-2026-0045'],
];

const FIRST = ['محمد', 'علي', 'حسين', 'زهراء', 'فاطمة', 'مريم', 'أحمد', 'مصطفى', 'نور', 'سارة', 'حيدر', 'عباس', 'رقية', 'زينب', 'يوسف', 'عمر', 'هدى', 'آية', 'كرار', 'سجاد', 'دعاء', 'بنين', 'أمير', 'ياسر', 'رسل'];
const LAST = ['الربيعي', 'الجبوري', 'العبيدي', 'الساعدي', 'التميمي', 'الخفاجي', 'الموسوي', 'الحسيني', 'الدليمي', 'الزبيدي', 'الكعبي', 'العامري', 'الشمري', 'المالكي', 'البياتي'];
const AREAS = ['حي الجامعة', 'حي العدل', 'المنصور', 'الكرادة', 'حي الحسين', 'حي الأمير', 'الجزائر', 'العشار', 'حي الضباط', 'حي الزهراء', 'حي السلام', 'المركز'];
const GOV_WEIGHTS = [['بغداد', 30], ['البصرة', 12], ['نينوى', 9], ['النجف', 7], ['كربلاء', 6], ['بابل', 6], ['ذي قار', 6], ['الأنبار', 4], ['ديالى', 4], ['كركوك', 4], ['صلاح الدين', 3], ['واسط', 3], ['ميسان', 2], ['القادسية', 2], ['المثنى', 2]];

// مولّد أرقام عشوائية ثابت البذرة: البيانات نفسها في كل مرة
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

function seed() {
  const L = require('./logic');
  const R = rng(20261110);
  const pick = a => a[Math.floor(R() * a.length)];
  const wpick = pairs => { const tot = pairs.reduce((s, p) => s + p[1], 0); let r = R() * tot; for (const p of pairs) { r -= p[1]; if (r < 0) return p[0]; } return pairs[0][0]; };
  const phone = () => '07' + pick(['7', '8', '5']) + String(Math.floor(R() * 1e8)).padStart(8, '0');

  const db = {
    settings: { phase: 'fee', phaseReason: 'نسخة العرض — تجربة المرحلة الأولى ببيانات افتراضية', minFee: 250, homeCap: 5000000, courierCommissionPct: 5 },
    categories: JSON.parse(JSON.stringify(CATEGORIES)),
    merchants: [], couriers: COURIERS.map(([id, name, license]) => ({ id, name, license })), users: [],
    shipments: [], remittances: [], complaints: [], reports: [], samples: [], recalls: [], declarations: [], violations: [], circulars: [], notes: [],
    ledger: [], audit: [], seq: { license: 1180 },
    foreignPlatforms: [
      { name: 'بازار الأناضول (منصة تجريبية)', country: 'تركيا', status: 'مسجّلة', since: '2026-03' },
      { name: 'سوق الخليج أونلاين (منصة تجريبية)', country: 'الإمارات', status: 'مسجّلة', since: '2026-05' },
      { name: 'عالم الشرق للتسوق (منصة تجريبية)', country: 'الصين', status: 'قيد التسجيل', since: '' },
      { name: 'مول أوروبا (منصة تجريبية)', country: 'ألمانيا', status: 'غير مسجّلة — تُخدم عبر وسطاء محليين مُجازين', since: '' },
    ],
    payProviders: [
      { name: 'محفظة رافد (تجريبي)', share: 46 }, { name: 'بوابة دجلة للدفع (تجريبي)', share: 33 }, { name: 'بطاقة النخيل (تجريبي)', share: 21 },
    ],
  };
  S._set(db);

  const now = Date.now(), DAY = 864e5;
  const t0 = now - 30 * DAY;
  const iso = ms => new Date(ms).toISOString();

  // الحسابات
  const U = (username, pw, name, role, extra = {}) => db.users.push({ username, pass: S.hashPassword(pw), name, role, ...extra });
  U('digital1', 'Dmn@2026dg', 'مدير منصة ضمان', 'digital');
  U('trade1', 'Dmn@2026tr', 'قسم التجارة الإلكترونية', 'trade');
  U('tax1', 'Dmn@2026tx', 'قسم جباية التجارة الإلكترونية', 'tax');
  U('customs1', 'Dmn@2026cu', 'قسم الطرود والبيان المسبق', 'customs');
  U('quality1', 'Dmn@2026qc', 'قسم الرقابة على الأسواق الإلكترونية', 'quality');
  U('consumer1', 'Dmn@2026cp', 'لجنة شكاوى التجارة الإلكترونية', 'consumer');
  U('cmc1', 'Dmn@2026cm', 'قسم المنصات الرقمية', 'cmc');
  U('cbi1', 'Dmn@2026cb', 'دائرة المدفوعات', 'cbi');
  U('audit1', 'Dmn@2026au', 'مراقب — اطلاع وتصدير', 'audit');
  U('inspector1', 'Dmn@2026in', 'مفتش ميداني — بغداد', 'inspector', { place: 'فريق التفتيش المشترك — بغداد' });
  U('checkpoint1', 'Dmn@2026ck', 'سيطرة مدخل كركوك', 'checkpoint', { place: 'سيطرة مدخل كركوك' });
  COURIERS.forEach(([id, name], i) => U('courier' + (i + 1), 'Dmn@2026c' + (i + 1), name, 'courier', { courierId: id }));

  // التجار
  for (const [id, name, owner, tier, channel, gov, kinds, status, page] of MERCHANTS) {
    db.merchants.push({ id, name, owner, tier, channel, gov, page, phone: phone(), nidLast4: String(1000 + Math.floor(R() * 8999)), cr: tier === 'home' ? '' : 'CR-' + gov.length + String(Math.floor(R() * 90000) + 10000), taxId: tier === 'home' ? '' : 'TX-' + String(Math.floor(R() * 9e6) + 1e6), category: CATALOG[kinds[0]][0][1], kinds, status: status === 'active' ? 'pending' : status, license: null, at: iso(t0 - (10 + Math.floor(R() * 40)) * DAY), decisions: [] });
  }
  U('merchant1', 'Dmn@2026m1', 'حيدر عبد الأمير', 'merchant', { merchantId: 'M001' });
  U('merchant2', 'Dmn@2026m2', 'رزان سعد', 'merchant', { merchantId: 'M002' });
  U('merchant3', 'Dmn@2026m3', 'سارة يوسف', 'merchant', { merchantId: 'M022' });
  U('broker1', 'Dmn@2026b1', 'شركة جسر للتجارة الإلكترونية', 'merchant', { merchantId: 'M020' });

  const user = n => db.users.find(u => u.username === n);
  const shopUser = mid => db.users.find(u => u.merchantId === mid) || { username: 'shop.' + mid.toLowerCase(), role: 'merchant', merchantId: mid };
  const courierUser = cid => db.users.find(u => u.courierId === cid);

  // ── جدول زمني للأحداث يُنفّذ بالترتيب ──
  const Q = [];
  const at = (ms, fn) => Q.push({ ms, fn });

  // إصدار الإجازات قبل بداية الفترة
  MERCHANTS.forEach(([id, , , , , , , status], i) => { if (status === 'active') at(t0 - (40 - i) * 3600e3, () => L.tradeAct(user('trade1'), id, 'approve', '')); });
  at(t0 + 2 * DAY, () => L.tradeAct(user('trade1'), 'M024', 'reject', 'صورة البطاقة الموحدة غير مقروءة ورابط الصفحة لا يعمل — يمكن إعادة التقديم'));

  // الشحنات
  const sellers = MERCHANTS.filter(m => m[9] > 0);
  const plan = [];
  for (let d = 0; d < 30; d++) {
    const n = 11 + Math.floor(R() * 7);
    for (let k = 0; k < n; k++) {
      const ms = t0 + d * DAY + (8 + R() * 13) * 3600e3;
      if (ms > now - 600e3) continue;
      const mm = wpick(sellers.map(m => [m, m[9]]));
      if (mm[0] === 'M019' && d >= 24) continue; // ساعات كربلاء علّقت إجازتها
      plan.push({ ms, m: mm });
    }
  }
  for (const p of plan) {
    at(p.ms, () => {
      const kinds = p.m[6], cnt = 1 + (R() < 0.35 ? 1 : 0) + (R() < 0.1 ? 1 : 0), items = [];
      for (let i = 0; i < cnt; i++) { const [nm, cat, price] = pick(CATALOG[pick(kinds)]); const ex = items.find(x => x.name === nm); if (ex) ex.qty++; else items.push({ name: nm, category: cat, qty: 1, price }); }
      const g = wpick(GOV_WEIGHTS);
      const cid = wpick([['C01', 4], ['C02', 3], ['C03', 2], ['C04', 2]]);
      let s;
      try {
        s = L.createShipment(shopUser(p.m[0]), { merchantId: p.m[0], courierId: cid, pay: R() < 0.2 ? 'epay' : 'cod', buyer: { name: pick(FIRST) + ' ' + pick(LAST), phone: phone(), gov: g, address: pick(AREAS) + '، زقاق ' + (1 + Math.floor(R() * 40)) } , items }, iso(p.ms));
      } catch { return; }
      const age = (now - p.ms) / DAY, cu = courierUser(cid);
      const tp = p.ms + (2 + R() * 6) * 3600e3, tt = tp + (1 + R() * 10) * 3600e3, td = tt + (3 + R() * 30) * 3600e3;
      if (tp < now && age > 0.3) at(tp, () => { if (s.status === 'created') L.pickup(cu, s.id, iso(tp)); });
      if (tt < now && age > 0.6) at(tt, () => { if (s.status === 'picked') L.dispatch(cu, s.id, iso(tt)); });
      if (td < now - 3600e3 && age > 1.6) at(td, () => { if (s.status === 'transit') { if (R() < 0.05) L.returnShipment(cu, s.id, 'المشتري لم يرد على الهاتف', iso(td)); else L.deliver(cu, s.id, iso(td)); } });
      // مرور السيطرة على الشحنات الذاهبة إلى كركوك أو القادمة عبرها
      if ((g === 'كركوك' || p.m[5] === 'كركوك' || (g !== p.m[5] && R() < 0.12)) && tt < now) at(tt + 2 * 3600e3, () => { if (['transit', 'delivered'].includes(s.status) || s.status === 'picked') try { L.scan(user('checkpoint1'), s.code, 'pass', {}, iso(tt + 2 * 3600e3)); } catch { } });
    });
  }

  // التحويل اليومي من كل شركة توصيل الساعة التاسعة مساءً، والمطابقة صباح اليوم التالي
  for (let d = 0; d < 30; d++) {
    const dayEnd = t0 + d * DAY + 21 * 3600e3;
    if (dayEnd > now - 3600e3) continue;
    for (const [cid] of COURIERS) {
      at(dayEnd + Number(cid.slice(1)) * 60e3, () => {
        let r;
        const late = d >= 17 && cid === 'C02' && !db._lateDone;
        try {
          r = L.remit(courierUser(cid), iso(dayEnd + Number(cid.slice(1)) * 60e3));
        } catch { return; }
        if (late && r.expected >= 4000) { db._lateDone = true; const cut = Math.round(r.expected * 0.3 / 250) * 250; r.amount -= cut; const e = db.ledger[db.ledger.length - 1]; e.amount = r.amount; const { hash, ...body } = e; void hash; e.hash = S.sha(JSON.stringify(body)); }
        const rec = dayEnd + 13 * 3600e3;
        if (rec < now - 1800e3) at(rec + Number(cid.slice(1)) * 60e3, () => L.reconcile(user('tax1'), r.id, iso(rec + Number(cid.slice(1)) * 60e3)));
      });
    }
  }

  // تعليق إجازة ساعات كربلاء بعد شكاوى متكررة (اليوم 24)، مع طلب معلّق يُرفض استلامه
  at(t0 + 23.9 * DAY, () => {
    const s = L.createShipment(shopUser('M019'), { merchantId: 'M019', courierId: 'C01', pay: 'cod', buyer: { name: 'كرار الموسوي', phone: phone(), gov: 'كربلاء', address: 'حي الحسين' }, items: [{ name: 'ساعة يد رجالية', category: 'luxury', qty: 1, price: 150000 }] }, iso(t0 + 23.9 * DAY));
    at(t0 + 24.2 * DAY, () => L.pickup(courierUser('C01'), s.id, iso(t0 + 24.2 * DAY)));
  });
  at(t0 + 24 * DAY, () => L.tradeAct(user('trade1'), 'M019', 'suspend', 'إحالة حماية المستهلك: 3 شكاوى ساعات مقلّدة بيعت كأصلية في البث المباشر', iso(t0 + 24 * DAY)));

  // الشكاوى
  const COMPLAINTS = [
    [5, null, 'different', 'اللون والمقاس غير الذي في الصورة', 'refund'], [8, 'M001', 'fake', 'العطر رائحته تختفي بعد دقائق', 'refund'],
    [11, null, 'notarrived', 'دفعت للمندوب ولم يصل الطرد كاملاً، قطعة ناقصة', 'refund'], [13, 'M019', 'fake', 'الساعة مقلّدة وبيعت على أنها أصلية', 'refer'],
    [15, null, 'price', 'اتفقنا في البث على سعر أقل', 'rejected'], [19, 'M019', 'fake', 'ساعة ثانية مقلّدة من نفس البث', 'refer'],
    [22, 'M019', 'fake', 'الساعة توقفت بعد يومين ومكتوب عليها ماركة عالمية', 'refer'],
    [26, null, 'different', 'المنتج مستعمل', null], [27.5, 'M007', 'fake', 'الكريم سبّب تحسساً', null], [28.5, null, 'price', 'السعر أعلى من المعلن في الصفحة', null], [29.3, null, 'other', 'المندوب طلب مبلغاً إضافياً', null],
  ];
  COMPLAINTS.forEach(([d, mid, kind, text, decision]) => {
    const ms = t0 + d * DAY;
    at(ms, () => {
      const pool = db.shipments.filter(s => s.status === 'delivered' && !db.complaints.some(c => c.shipmentId === s.id) && (mid ? s.merchantId === mid : !['M019', 'M001'].includes(s.merchantId)));
      const s = pool[Math.floor(R() * pool.length)];
      if (!s) return;
      const c = L.publicComplaint(s.code, s.buyer.phone, kind, text);
      if (s.merchantId === 'M001') at(ms + 5 * 3600e3, () => L.merchantReply(user('merchant1'), c.id, 'نعتذر، تواصلنا مع المشتري وسنستبدل العطر مجاناً'));
      if (decision) at(ms + 1.2 * DAY, () => L.consumerDecide(user('consumer1'), c.id, decision, decision === 'refer' ? 'تكرار بيع بضاعة مقلّدة على أنها أصلية' : ''));
    });
  });

  // العينات وأمر السحب على المكملات
  const SAMPLES = [[20, 'M005', 'fail', 'نسبة البروتين الفعلية 52% بدل 80% المعلنة على العبوة'], [12, 'M003', 'pass', ''], [15, 'M007', 'pass', ''], [18, 'M004', 'pass', ''], [27, 'M007', null, ''], [28.5, 'M009', null, '']];
  for (const [d, mid, result, note] of SAMPLES) {
    at(t0 + d * DAY, () => {
      const s = db.shipments.filter(x => x.merchantId === mid && ['picked', 'transit'].includes(x.status)).pop();
      if (!s) return;
      const smp = L.takeSample(user('quality1'), s.id, iso(t0 + d * DAY));
      if (result) at(t0 + (d + 0.3) * DAY, () => L.sampleResult(user('quality1'), smp.id, result, note));
    });
  }

  // فحوص المفتش الميداني
  for (let i = 0; i < 9; i++) {
    const ms = t0 + (4 + i * 2.8) * DAY;
    at(ms, () => {
      const pool = db.shipments.filter(s => ['picked', 'transit'].includes(s.status) && s.buyer.gov === 'بغداد');
      const s = pool[Math.floor(R() * pool.length)];
      if (!s) return;
      if (i === 5) L.scan(user('inspector1'), s.code, 'undervalue', { actual: Math.round(s.value * 2.4 / 1000) * 1000 }, iso(ms));
      else if (i === 7) L.scan(user('inspector1'), s.code, 'undeclared', { note: 'علبتا سجائر إلكترونية غير مذكورتين في البيان' }, iso(ms));
      else L.scan(user('inspector1'), s.code, 'match', {}, iso(ms));
    });
  }

  // البيان المسبق للطلبات من الخارج
  const DECL = [[3, 'M020', 'تركيا', 'clear'], [6, 'M021', 'الإمارات', 'clear'], [9, 'M020', 'تركيا', 'clear'], [13, 'M020', 'الصين', 'clear'], [17, 'M021', 'تركيا', 'clear'], [21, 'M020', 'تركيا', 'clear'], [24, 'M021', 'الصين', 'hold'], [26, 'M020', 'تركيا', 'clear'], [29.2, 'M020', 'تركيا', null], [29.5, 'M021', 'الإمارات', null]];
  const broker = { M020: user('broker1'), M021: shopUser('M021') };
  for (const [d, mid, src, act] of DECL) {
    const ms = t0 + d * DAY;
    if (ms > now) continue;
    at(ms, () => {
      const items = [], cnt = 1 + Math.floor(R() * 3);
      for (let i = 0; i < cnt; i++) { const [nm, cat, price] = pick(CATALOG.imports); if (!items.find(x => x.name === nm)) items.push({ name: nm, category: cat, qty: 1, price }); }
      const dcl = L.declare(broker[mid], { source: src, port: src === 'الصين' ? 'ميناء أم قصر' : 'مطار بغداد الدولي', courierId: pick(['C01', 'C04']), items, buyer: { name: pick(FIRST) + ' ' + pick(LAST), phone: phone(), gov: wpick(GOV_WEIGHTS), address: pick(AREAS) } }, iso(ms));
      if (act === 'clear') at(ms + 0.8 * DAY, () => {
        const d2 = L.customsAct(user('customs1'), dcl.id, 'clear', { dutyPct: 5 }, iso(ms + 0.8 * DAY));
        const s = db.shipments.find(x => x.id === d2.shipmentId), cu = courierUser(s.courierId);
        at(ms + 1.0 * DAY, () => L.pickup(cu, s.id, iso(ms + 1.0 * DAY)));
        if (ms + 2.5 * DAY < now) { at(ms + 1.3 * DAY, () => L.dispatch(cu, s.id, iso(ms + 1.3 * DAY))); at(ms + 2.2 * DAY, () => L.deliver(cu, s.id, iso(ms + 2.2 * DAY))); }
      });
      if (act === 'hold') at(ms + 0.6 * DAY, () => L.customsAct(user('customs1'), dcl.id, 'hold', { reason: 'الفاتورة التجارية غير قابلة للتحقق إلكترونياً' }, iso(ms + 0.6 * DAY)));
    });
  }

  // بلاغات الصفحات
  const REPORTS = [[8, 'facebook.com/cheap.phones.baghdad', 'facebook', '', 'يبيع هواتف بلا رقم إجازة ويطلب تحويل المبلغ مسبقاً', 'takedown'], [14, 'tiktok.com/@noor.style.live', 'live', '', 'بث مباشر يومي بلا رقم إجازة ظاهر', 'notify'], [19, 'instagram.com/bait.alotour', 'instagram', 'IQ-EC-2026-001181', 'أردت التأكد أن الصفحة مُجازة', 'resolved'], [25, 'tiktok.com/@perfume.deals.iq', 'tiktok', '', 'عطور بأسعار مشبوهة', null], [28, 'facebook.com/gold.offers.basra', 'facebook', '', 'ذهب بأقل من سعر السوق ويطلب عربوناً', null], [29.4, 'tiktok.com/@watches.live.2026', 'live', '', 'نفس بائع الساعات المعلّق بصفحة جديدة', null]];
  for (const [d, url, channel, license, note, actn] of REPORTS) {
    const ms = t0 + d * DAY;
    at(ms, () => { const r = L.publicReport({ url, channel, license, note }); if (actn) at(ms + 0.7 * DAY, () => L.cmcAct(user('cmc1'), r.id, actn, '')); });
  }

  // تعميم أول
  at(t0 + 1 * DAY, () => L.circular(user('digital1'), 'إظهار رقم الإجازة في كل بث مباشر', 'على كل تاجر يبيع عبر البث المباشر إظهار رقم إجازته من وزارة التجارة طوال البث، ووضعه في وصف الصفحة. شركات التوصيل المرخصة لا تستلم أي طلب بلا رقم إجازة فعّال.'));

  // التنفيذ بالترتيب الزمني (الأحداث المضافة أثناء التنفيذ تُرتّب معها)
  while (Q.length) {
    Q.sort((a, b) => a.ms - b.ms);
    const e = Q.shift();
    L.setClock(iso(e.ms));
    try { e.fn(); } catch (x) { if (process.env.SEED_DEBUG) console.error('[seed]', x.message); }
  }

  L.setClock(null);
  // إعادة بناء سلسلتي البصمة بعد الضبط اليدوي لتوقيت بعض القيود (السلسلة تُبنى مرة واحدة هنا قبل تشغيل النظام)
  for (const name of ['ledger', 'audit']) {
    db[name].sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : a.seq - b.seq));
    let prev = 'GENESIS';
    db[name].forEach((r, i) => { r.seq = i + 1; r.prev = prev; const { hash, ...body } = r; void hash; r.hash = S.sha(JSON.stringify(body)); prev = r.hash; });
  }
  db.notes.sort((a, b) => (a.at < b.at ? -1 : 1));
  return db;
}

module.exports = seed;
