// بوابات «ضمان»: لكل جهة شاشة واحدة بما تقرأه وما تكتبه فقط.
'use strict';
const PORTAL = location.pathname.split('/')[1];
const PNAME = {
  digital: ['🏛️', 'وزارة الاقتصاد الرقمي والحوكمة', 'المشغّل: اللوحة الوطنية، مرحلة النظام، نسب الرسم والتعاميم'],
  trade: ['📜', 'وزارة التجارة', 'إصدار إجازات التجار الإلكترونيين وتعليقها'],
  tax: ['🧾', 'الهيئة العامة للضرائب', 'تحصيل الرسوم ومطابقة تحويلات شركات التوصيل'],
  customs: ['🛃', 'الهيئة العامة للكمارك', 'البيان المسبق للطرود القادمة من الخارج'],
  quality: ['🔬', 'الجهاز المركزي للتقييس والسيطرة النوعية', 'العينات من مخازن شركات التوصيل وأوامر السحب'],
  consumer: ['🛡️', 'مجلس حماية المستهلك', 'شكاوى المشترين المربوطة بالشحنات'],
  cmc: ['📡', 'هيئة الإعلام والاتصالات', 'بلاغات الصفحات والبثوث والمنصات الأجنبية'],
  cbi: ['🏦', 'البنك المركزي العراقي', 'المدفوعات الإلكترونية وتدفقات التحصيل — اطلاع فقط'],
  audit: ['⚖️', 'الجهات الرقابية', 'هيئة النزاهة وديوان الرقابة المالية — اطلاع وتصدير فقط'],
  courier: ['🚚', 'بوابة شركة التوصيل', 'الاستلام والتسليم والتحصيل والتحويل اليومي'],
  merchant: ['🛍️', 'بوابة التاجر الإلكتروني', 'طلباتك ورسومها وإجازتك'],
  inspector: ['🔎', 'بوابة المفتش الميداني', 'فحص الطرود بمسح رمزها'],
  checkpoint: ['🚧', 'بوابة السيطرات', 'مسح الرمز يثبت أن الرسم مدفوع فلا جباية ثانية'],
};
const DEMO = {
  digital: ['digital1', 'Dmn@2026dg'], trade: ['trade1', 'Dmn@2026tr'], tax: ['tax1', 'Dmn@2026tx'], customs: ['customs1', 'Dmn@2026cu'], quality: ['quality1', 'Dmn@2026qc'],
  consumer: ['consumer1', 'Dmn@2026cp'], cmc: ['cmc1', 'Dmn@2026cm'], cbi: ['cbi1', 'Dmn@2026cb'], audit: ['audit1', 'Dmn@2026au'], courier: ['courier1', 'Dmn@2026c1'],
  merchant: ['merchant1', 'Dmn@2026m1'], inspector: ['inspector1', 'Dmn@2026in'], checkpoint: ['checkpoint1', 'Dmn@2026ck'],
};
let V = null, TAB = {};
const root = $('#root');

// ── الدخول ──
function loginScreen(msg) {
  const p = PNAME[PORTAL] || PNAME.merchant, d = DEMO[PORTAL] || DEMO.merchant;
  document.title = 'ضمان — ' + p[1];
  root.innerHTML = `<div class="login"><div class="side"><div class="side-top"><a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ضمان</b><small>تنظيم التجارة الإلكترونية</small></span></a>${GOV_TAG}</div>
    <div class="side-title">${PORTAL === 'digital' ? `<img class="side-seal" src="/img/mdeg-512.webp" alt="شعار ${GOV_NAME}">` : `<span class="side-ic">${p[0]}</span>`}<div><h1>${esc(p[1])}</h1><p>${esc(p[2])}</p></div></div><div class="rule">لا شحنة بلا رمز، ولا رمز بلا تاجر مُجاز. كل جهة تكتب في مجالها فقط، والسجل المالي لا يُعدَّل.</div></div>
    <div class="form"><form class="box" id="lf"><h2>تسجيل الدخول</h2><p class="muted" style="margin:0 0 16px">${esc(p[1])}</p>
    ${msg ? `<div class="note bad" style="margin-bottom:12px">${esc(msg)}</div>` : ''}
    <div class="stack" style="gap:12px"><label class="f">اسم الدخول<input class="inp mono" name="username" autocomplete="username" required></label><label class="f">كلمة المرور<input class="inp" type="password" name="password" autocomplete="current-password" required></label>
    <button class="btn primary lg block">دخول</button>
    <button type="button" class="btn ghost sm" id="demo">نسخة العرض: املأ حساب ${esc(d[0])}</button>
    ${PORTAL === 'merchant' ? '<a class="btn ghost sm" href="/apply">ليس لديك حساب؟ سجّل متجرك</a>' : ''}
    <a class="muted small" href="/">← كل البوابات</a></div></form></div></div>`;
  $('#demo').onclick = () => { $('#lf').username.value = d[0]; $('#lf').password.value = d[1]; };
  $('#lf').onsubmit = async e => {
    e.preventDefault();
    const f = e.target;
    try { await api('/api/login', { username: f.username.value, password: f.password.value, portal: PORTAL }); boot(); }
    catch (x) { if (x.data && x.data.portal) { toast(x.message + ' — جارِ التحويل', true); setTimeout(() => location.href = '/' + x.data.portal, 1200); } else loginScreen(x.message); }
  };
}

async function boot() {
  try { V = await api('/api/view'); }
  catch (x) { if (x.status === 401) return loginScreen(); root.innerHTML = `<div class="wrap"><div class="note bad">${esc(x.message)}</div></div>`; return; }
  if (V.me.role !== PORTAL) { location.href = '/' + V.me.role; return; }
  draw();
}
async function refresh() { try { V = await api('/api/view'); draw(); } catch (x) { if (x.status === 401) loginScreen(); } }
async function act(a, p, ok) {
  try { const r = await api('/api/act', { a, p }); if (ok) toast(typeof ok === 'function' ? ok(r.result) : ok); await refresh(); return r.result; }
  catch (x) { toast(x.message, true); return null; }
}

function shell(body) {
  const p = PNAME[V.me.role], phase = V.settings.phase;
  document.title = 'ضمان — ' + p[1];
  return `<div class="demo-strip">نسخة عرض ببيانات افتراضية · المرحلة الحالية: ${phase === 'fee' ? 'الأولى — يُجبى الرسم' : 'صفر — تسجيل بلا رسم'}</div>
  <header class="topbar"><div class="in"><a class="brand" href="/"><img src="/img/logo.svg" alt=""><span><b>ضمان</b><small>تنظيم التجارة الإلكترونية</small></span></a>${GOV_TAG}
  <span class="pill">${p[0]} ${esc(p[1])}</span><span class="sp"></span>
  <button class="iconbtn" id="bell" aria-label="الإشعارات">🔔${V.notes.length ? `<span class="dot">${V.notes.length}</span>` : ''}</button>
  <div class="who"><span class="av">${esc(V.me.name.trim()[0] || '؟')}</span><span class="meta"><b>${esc(V.me.name)}</b><div class="small" style="color:#9DBDB3">${esc(V.me.username)}${V.me.place ? ' · ' + esc(V.me.place) : ''}</div></span></div>
  <button class="iconbtn" id="out">خروج</button></div></header>
  <main class="wrap">${body}</main>`;
}
function bindShell() {
  $('#out').onclick = async () => { await api('/api/logout', {}); loginScreen(); };
  $('#bell').onclick = e => {
    e.stopPropagation();
    const old = $('.notes-pop'); if (old) return old.remove();
    const pop = document.createElement('div'); pop.className = 'notes-pop';
    pop.innerHTML = V.notes.length ? V.notes.map(n => `<div class="it"><time>${dt(n.at)} · ${ago(n.at)}</time>${esc(n.text)}</div>`).join('') : '<div class="empty">لا إشعارات</div>';
    document.body.appendChild(pop);
    setTimeout(() => document.addEventListener('click', function f() { pop.remove(); document.removeEventListener('click', f); }), 0);
  };
}
function head(title, sub, right = '') { return `<div class="page-head"><div><h1>${title}</h1>${sub ? `<p>${sub}</p>` : ''}</div><span class="sp"></span>${right}</div>`; }
function tabs(key, list) {
  const cur = TAB[key] || list[0][0];
  return { cur, html: `<div class="tabs">${list.map(([k, l, c]) => `<button class="tab${k === cur ? ' on' : ''}" data-tab="${key}:${k}">${esc(l)}${c ? `<span class="c">${c}</span>` : ''}</button>`).join('')}</div>` };
}
function bindTabs() { $$('[data-tab]').forEach(b => b.onclick = () => { const [k, v] = b.dataset.tab.split(':'); TAB[k] = v; draw(); }); }
const codeLink = c => `<a class="mono" href="/c/${esc(c)}" target="_blank" rel="noopener">${esc(c)}</a>`;
const catName = k => (V.categories[k] || {}).name || k;

function draw() {
  const R = { merchant, courier, tax, digital, trade, customs, quality, consumer, cmc, cbi, audit, inspector: scanner, checkpoint: scanner }[V.me.role];
  root.innerHTML = shell(R.html());
  bindShell(); bindTabs(); labelTables(root);
  R.bind && R.bind();
}

// ══════════ التاجر ══════════
const merchant = {
  html() {
    const m = V.merchant;
    if (m.status !== 'active') {
      const box = {
        pending: `<div class="note warn"><span>⏳</span><span><b>طلبك قيد المراجعة لدى وزارة التجارة</b>حين يصدر رقم إجازتك يظهر هنا وتستطيع إنشاء الشحنات.</span></div>`,
        rejected: `<div class="note bad"><span>✖</span><span><b>رُفض طلبك</b>${esc((m.decisions.slice(-1)[0] || {}).reason || '')}</span></div><div class="row" style="margin-top:12px"><a class="btn primary" href="/apply">أعد التقديم</a></div>`,
        suspended: `<div class="note bad"><span>⛔</span><span><b>إجازتك ${esc(m.license)} معلّقة</b>${esc((m.decisions.slice(-1)[0] || {}).reason || '')}. شركات التوصيل لن تستلم طلباتك حتى تُعاد.</span></div>`,
      }[m.status];
      return head(esc(m.name), `${esc(m.tierText)} · ${esc(m.channelText)} · ${esc(m.gov)}`) + `<div class="card">${box}</div>` + (V.notes.length ? `<div class="card" style="margin-top:16px"><h3>الإشعارات</h3>${V.notes.map(n => `<div class="small" style="padding:6px 0;border-bottom:1px solid var(--line)">${dt(n.at)} — ${esc(n.text)}</div>`).join('')}</div>` : '');
    }
    const home = m.tier === 'home', cap = V.settings.homeCap, pct = Math.min(100, V.monthSales / cap * 100);
    const open = V.complaints.filter(c => c.status === 'open').length;
    const lic = `<div class="card hero"><div class="row"><div><div class="muted small">رقم إجازتك من وزارة التجارة</div><div class="mono" style="font-size:26px;font-weight:800;color:#F2D894">${esc(m.license)}</div><div class="muted small">اكتبه في وصف صفحتك وأظهره طوال كل بث مباشر</div></div><span class="sp"></span><button class="btn sm" id="copyLic">نسخ</button></div></div>`;
    const kpis = `<div class="grid g4">${kpi('شحنات هذا الشهر', fmt(V.agg.count))}${kpi('مبيعات هذا الشهر', iqd(V.agg.value))}${kpi('الرسوم المستحقة', iqd(V.agg.due), home ? 'بائع منزلي: معفى تحت السقف' : 'يقبضها المندوب مع الثمن', true)}${kpi('شكاوى مفتوحة', fmt(open), open ? 'ردّ عليها من الأسفل' : 'لا شكاوى')}</div>`;
    const capBox = home ? `<div class="card"><h3>🏠 سقف الإعفاء الشهري للبائع المنزلي</h3><div class="progress${pct > 80 ? ' warn' : ''}"><i style="width:${pct.toFixed(1)}%"></i></div><p class="small muted" style="margin:6px 0 0">${iqd(V.monthSales)} من ${iqd(cap)} — بعد السقف يُحتسب الرسم على الشحنات التالية هذا الشهر.</p></div>` : '';
    const alerts = [...V.recalls.filter(r => r.active).map(r => `<div class="note bad"><span>⛔</span><span><b>أمر سحب على فئة «${esc(catName(r.category))}»</b>${esc(r.reason)} — أُوقفت ${r.held} شحنة ولا يمكن إرسال هذه الفئة حتى يُرفع الأمر.</span></div>`),
      ...V.violations.filter(v => v.status === 'open').map(v => `<div class="note warn"><span>⚠️</span><span><b>مخالفة على شحنة</b>${v.kind === 'undervalue' ? `قيمة حقيقية ${fmt(v.actual)} د.ع بدل ${fmt(v.declared)} — فرق الرسم ${fmt(v.feeGap)} د.ع مستحق` : esc(v.note)}</span></div>`)].join('');
    const big = `<div class="card" style="text-align:center"><p class="muted" style="margin:0 0 10px">كل طلب تبيعه يحتاج رمزاً واحداً على الطرد</p><button class="btn primary lg" id="newShip">➕ شحنة جديدة</button>${m.tier === 'platform' ? ' <button class="btn gold lg" id="newDecl">🌍 بيان مسبق لطلب من الخارج</button>' : ''}</div>`;
    const t = tabs('m', [['ships', 'الشحنات', V.shipments.length], ['comp', 'الشكاوى', open], ...(m.tier === 'platform' ? [['decl', 'البيانات المسبقة', V.declarations.filter(d => d.status === 'submitted').length]] : [])]);
    let body = '';
    if (t.cur === 'ships') body = table(['الرمز', 'التاريخ', 'المشتري', 'القيمة', 'الرسم', 'الحالة', ''], V.shipments.slice(0, TAB.mAll ? 999 : 20).map(s => `<tr><td>${codeLink(s.code)}</td><td class="n">${dt(s.at)}</td><td>${esc(s.buyer)} <span class="muted small">${esc(s.gov)}</span></td><td class="n">${iqd(s.value)}</td><td class="n">${s.feeDue ? iqd(s.feeDue) : `<span class="muted small">${esc(s.exempt || '0')}</span>`}</td><td>${statusBadge(s.status, s.statusText)}</td><td><button class="btn sm" data-wb="${esc(s.code)}">ورقة الشحن</button></td></tr>`), 'لا شحنات بعد — ابدأ بـ«شحنة جديدة»') + (!TAB.mAll && V.shipments.length > 20 ? `<div class="row" style="justify-content:center;margin-top:10px"><button class="btn sm" id="mAll">عرض كل الشحنات (${V.shipments.length})</button></div>` : '');
    if (t.cur === 'comp') body = table(['الشكوى', 'الشحنة', 'المشكلة', 'ما كتبه المشتري', 'ردّك', 'الحالة'], V.complaints.map(c => `<tr class="${c.status === 'open' ? 'hl' : ''}"><td class="mono">${esc(c.id)}</td><td>${codeLink(c.code)}</td><td>${esc(c.kindText)}</td><td class="small">${esc(c.text)}</td><td class="small">${c.reply ? esc(c.reply) : (c.status === 'open' ? `<button class="btn sm primary" data-reply="${esc(c.id)}">ردّ</button>` : '')}</td><td>${statusBadge(c.status, c.status === 'open' ? 'قيد النظر' : (c.decisionText || 'أُغلقت'))}</td></tr>`), 'لا شكاوى — هذا ما نريده');
    if (t.cur === 'decl') body = table(['البيان', 'التاريخ', 'من', 'المنفذ', 'القيمة', 'الرسم الكمركي', 'الحالة', 'رمز الشحنة'], V.declarations.map(d => `<tr><td class="mono">${esc(d.id)}</td><td class="n">${dt(d.at)}</td><td>${esc(d.source)}</td><td class="small">${esc(d.port)}</td><td class="n">${iqd(d.value)}</td><td class="n">${d.duty ? iqd(d.duty) : '—'}</td><td>${statusBadge(d.status, { submitted: 'بانتظار الكمارك', cleared: 'خُلّص', held: 'محجوز' }[d.status])}${d.reason ? `<div class="small muted">${esc(d.reason)}</div>` : ''}</td><td>${d.code ? codeLink(d.code) : '—'}</td></tr>`));
    return head(esc(m.name), `${esc(m.tierText)} · ${esc(m.channelText)} · ${esc(m.gov)}`) + `<div class="stack">${lic}${alerts}${big}${kpis}${capBox}<div class="card">${t.html}${body}</div></div>`;
  },
  bind() {
    const c = $('#copyLic'); if (c) c.onclick = () => copy(V.merchant.license);
    const ma = $('#mAll'); if (ma) ma.onclick = () => { TAB.mAll = true; draw(); };
    const n = $('#newShip'); if (n) n.onclick = shipForm;
    const d = $('#newDecl'); if (d) d.onclick = declForm;
    $$('[data-wb]').forEach(b => b.onclick = () => showWaybill(b.dataset.wb));
    $$('[data-reply]').forEach(b => b.onclick = async () => { const v = await ask('ردّك على الشكوى ' + b.dataset.reply, [{ name: 'reply', label: 'يصل ردّك إلى المشتري ومجلس حماية المستهلك', type: 'textarea' }], { okText: 'أرسل الرد' }); if (v) act('complaint.reply', { id: b.dataset.reply, reply: v.reply }, 'أُرسل الرد'); });
  },
};

function itemRow(i, opts) {
  return `<div class="itrow it"><label class="f">القطعة<input class="inp" name="name" placeholder="مثلاً: عطر عود 100 مل"></label><label class="f">الفئة<select class="inp" name="category">${opts}</select></label><label class="f">العدد<input class="inp" name="qty" type="number" value="1" min="1"></label><label class="f">سعر القطعة (د.ع)<input class="inp" name="price" type="number" min="0" inputmode="numeric"></label><button type="button" class="btn sm ghost" data-del title="حذف">✕</button></div>`;
}
function shipForm() {
  const cats = Object.entries(V.categories), mcat = V.merchant.category;
  const opts = cats.map(([k, c]) => `<option value="${k}"${k === mcat ? ' selected' : ''}>${esc(c.name)} — ${c.rate}%</option>`).join('');
  const html = `<div class="body"><form id="sf" class="stack" style="gap:14px">
    <div class="fgrid"><label class="f">اسم المشتري<input class="inp" name="bname" required></label><label class="f">هاتف المشتري<input class="inp mono" name="bphone" placeholder="07xxxxxxxxx" inputmode="tel" required></label>
    <label class="f">المحافظة<select class="inp" name="bgov">${V.govs.map(g => `<option>${g}</option>`).join('')}</select></label><label class="f">العنوان<input class="inp" name="baddr" placeholder="الحي، الزقاق، أقرب نقطة دالة"></label>
    <label class="f">شركة التوصيل المرخصة<select class="inp" name="courierId">${V.couriers.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><label class="f">الدفع<select class="inp" name="pay"><option value="cod">عند الاستلام (يقبض المندوب)</option><option value="epay">إلكتروني مسبق</option></select></label></div>
    <div><b>القطع</b><div id="items" style="margin-top:8px">${itemRow(0, opts)}</div><button type="button" class="btn sm" id="addIt">➕ قطعة أخرى</button></div>
    <div class="note info" id="feePrev">اكتب سعر القطعة ليظهر الرسم.</div></form></div>
    <footer><button class="btn primary" id="sendShip">أنشئ الشحنة واطبع الرمز</button><button class="btn ghost" data-cancel>إلغاء</button></footer>`;
  const md = modal('شحنة جديدة', html, { wide: true });
  const f = $('#sf', md.el);
  const items = () => $$('.it', md.el).map(r => ({ name: $('[name=name]', r).value.trim(), category: $('[name=category]', r).value, qty: +$('[name=qty]', r).value || 1, price: +$('[name=price]', r).value || 0 }));
  let tm;
  const preview = () => { clearTimeout(tm); tm = setTimeout(async () => {
    const its = items().filter(i => i.price > 0);
    if (!its.length) return ($('#feePrev', md.el).textContent = 'اكتب سعر القطعة ليظهر الرسم.');
    try { const r = await api('/api/act', { a: 'fee.preview', p: { items: its } }); const x = r.result;
      $('#feePrev', md.el).innerHTML = `<span>🧾</span><span>قيمة البضاعة ${iqd(x.value)} · الرسم ${x.due ? iqd(x.due) : '0'}${x.exempt ? ` <span class="small">— ${esc(x.exempt)}${x.computed ? ` (المحتسب ${fmt(x.computed)} د.ع)` : ''}</span>` : ''}${f.pay.value === 'cod' ? `<br><b>يقبض المندوب من المشتري ${iqd(x.value + x.due)}</b>` : ''}</span>`;
    } catch { }
  }, 250); };
  md.el.addEventListener('input', preview); md.el.addEventListener('change', preview);
  $('#addIt', md.el).onclick = () => { $('#items', md.el).insertAdjacentHTML('beforeend', itemRow(0, opts)); };
  md.el.addEventListener('click', e => { if (e.target.matches('[data-del]') && $$('.it', md.el).length > 1) { e.target.closest('.it').remove(); preview(); } });
  $('[data-cancel]', md.el).onclick = md.close;
  $('#sendShip', md.el).onclick = async () => {
    const p = { buyer: { name: f.bname.value.trim(), phone: f.bphone.value.trim(), gov: f.bgov.value, address: f.baddr.value.trim() }, courierId: f.courierId.value, pay: f.pay.value, items: items() };
    try { const r = await api('/api/act', { a: 'shipment.create', p }); md.close(); await refresh(); waybillModal(r.result); }
    catch (x) { toast(x.message, true); }
  };
}
function waybillHtml(s) {
  return `<div class="waybill"><img src="/qr/${encodeURIComponent(s.code)}.svg" alt="رمز الشحنة"><div><div class="wb-top">${GOV_SEAL}<span><b>ضمان · ورقة شحن</b><small>بإشراف ${GOV_NAME}</small></span></div><div class="code mono">${esc(s.code)}</div><div><b>${esc(s.merchant.name)}</b> — <span class="mono">${esc(s.merchant.license || '')}</span></div><div>${esc(s.buyer.name)} · ${esc(s.buyer.gov)}</div><div>${esc(s.courier.name)}</div><div>${s.items.reduce((a, i) => a + i.qty, 0)} قطعة · ${iqd(s.value)} · الرسم ${iqd(s.feeDue)}</div><div class="small"><b>${s.pay === 'cod' ? `يقبض المندوب ${fmt(s.value + s.feeDue)} د.ع` : 'مدفوعة إلكترونياً'}</b></div></div></div>`;
}
function waybillModal(s) {
  const md = modal('ورقة الشحن', `<div class="body print-area"><div class="note ok" style="margin-bottom:12px"><span>✅</span><span><b>صدر رمز الشحنة</b>ألصق الورقة على الطرد. شركة التوصيل تستلمه بعد التحقق من إجازتك.</span></div>${waybillHtml(s)}</div><footer><button class="btn primary" onclick="window.print()">طباعة</button><a class="btn" href="/c/${esc(s.code)}" target="_blank" rel="noopener">صفحة الشحنة</a></footer>`);
  return md;
}
async function showWaybill(code) { try { const r = await api('/api/c/' + encodeURIComponent(code)); if (r.ok) waybillModal(r.s); } catch (x) { toast(x.message, true); } }

function declForm() {
  const cats = Object.entries(V.categories);
  const opts = cats.map(([k, c]) => `<option value="${k}">${esc(c.name)}</option>`).join('');
  const html = `<div class="body"><form id="df" class="stack" style="gap:14px"><div class="note info">يصل البيان إلى الهيئة العامة للكمارك قبل وصول الطرد. بعد التخليص يصدر رمز الشحنة تلقائياً.</div>
    <div class="fgrid"><label class="f">بلد الشراء<select class="inp" name="source"><option>تركيا</option><option>الإمارات</option><option>الصين</option><option>ألمانيا</option></select></label><label class="f">منفذ الدخول<select class="inp" name="port"><option>مطار بغداد الدولي</option><option>ميناء أم قصر</option><option>مطار البصرة الدولي</option></select></label>
    <label class="f">اسم المشتري<input class="inp" name="bname"></label><label class="f">هاتف المشتري<input class="inp mono" name="bphone" placeholder="07xxxxxxxxx"></label><label class="f">المحافظة<select class="inp" name="bgov">${V.govs.map(g => `<option>${g}</option>`).join('')}</select></label>
    <label class="f">شركة التوصيل<select class="inp" name="courierId">${V.couriers.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label></div>
    <div id="items">${itemRow(0, opts)}</div><button type="button" class="btn sm" id="addIt">➕ قطعة أخرى</button></form></div>
    <footer><button class="btn primary" id="sendD">أرسل البيان للكمارك</button><button class="btn ghost" data-cancel>إلغاء</button></footer>`;
  const md = modal('بيان مسبق لطلب من الخارج', html, { wide: true }), f = $('#df', md.el);
  $('#addIt', md.el).onclick = () => $('#items', md.el).insertAdjacentHTML('beforeend', itemRow(0, opts));
  md.el.addEventListener('click', e => { if (e.target.matches('[data-del]') && $$('.it', md.el).length > 1) e.target.closest('.it').remove(); });
  $('[data-cancel]', md.el).onclick = md.close;
  $('#sendD', md.el).onclick = async () => {
    const items = $$('.it', md.el).map(r => ({ name: $('[name=name]', r).value, category: $('[name=category]', r).value, qty: $('[name=qty]', r).value, price: $('[name=price]', r).value }));
    const r = await act('customs.declare', { source: f.source.value, port: f.port.value, courierId: f.courierId.value, buyer: { name: f.bname.value, phone: f.bphone.value, gov: f.bgov.value }, items }, x => 'وصل البيان ' + x.id + ' إلى الكمارك');
    if (r) { md.close(); TAB.m = 'decl'; draw(); }
  };
}

// ══════════ شركة التوصيل ══════════
const courier = {
  html() {
    const b = V.balance, A = V.active;
    const by = st => A.filter(s => s.status === st);
    const mism = V.remittances.filter(r => r.status === 'mismatch');
    const remitCard = `<div class="card hero"><div class="row"><div><div class="muted small">رسوم قبضها مندوبوك ولم تُحوَّل بعد (${fmt(b.count)} شحنة)</div><div style="font-size:28px;font-weight:800;color:#7FE3C8">${iqd(b.net)}</div><div class="muted small">المقبوض ${fmt(b.collected)} د.ع − عمولة الجباية ${V.settings.courierCommissionPct}% لشركتك ${fmt(b.commission)} د.ع</div></div><span class="sp"></span><button class="btn gold lg" id="remit"${b.count ? '' : ' disabled'}>حوّل رسوم اليوم للضرائب</button></div></div>`;
    const kp = `<div class="grid g4">${kpi('بانتظار الاستلام', fmt(by('created').length), 'تحقّق من الإجازة ثم استلم')}${kpi('في المخزن', fmt(by('picked').length))}${kpi('مع المندوبين', fmt(by('transit').length))}${kpi('عمولة الجباية لشركتك', iqd(V.row.commission), 'مجموع كل التحويلات', true)}</div>`;
    const warn = mism.map(r => `<div class="note bad"><span>⚠️</span><span><b>التحويل ${esc(r.id)} غير مطابق</b>الفرق ${fmt(-r.diff)} د.ع لصالح الهيئة العامة للضرائب.</span><span class="sp"></span><button class="btn sm danger" data-settle="${esc(r.id)}">سدّد الفرق</button></div>`).join('');
    const btn = s => s.status === 'created' ? `<button class="btn sm primary" data-a="shipment.pickup" data-id="${s.id}">استلام</button>` : s.status === 'picked' ? `<button class="btn sm" data-a="shipment.dispatch" data-id="${s.id}">خروج للتسليم</button>` : `<button class="btn sm primary" data-a="shipment.deliver" data-id="${s.id}">تسليم وقبض</button> <button class="btn sm ghost" data-ret="${s.id}">إرجاع</button>`;
    const t = tabs('c', [['now', 'الشحنات الجارية', A.length], ['rem', 'التحويلات', V.remittances.filter(r => r.status !== 'reconciled').length], ['done', 'المنتهية']]);
    let body = '';
    if (t.cur === 'now') body = table(['الرمز', 'التاجر', 'إلى', 'يقبض المندوب', 'الحالة', ''], A.map(s => `<tr><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td>${esc(s.buyer)} <span class="muted small">${esc(s.gov)}</span></td><td class="n">${s.pay === 'cod' ? `${iqd(s.value + s.feeDue)}<div class="small muted">منها رسم ${fmt(s.feeDue)}</div>` : '<span class="muted small">مدفوعة مسبقاً</span>'}</td><td>${statusBadge(s.status, s.statusText)}</td><td style="white-space:nowrap">${btn(s)}</td></tr>`), 'لا شحنات جارية');
    if (t.cur === 'rem') body = table(['التحويل', 'التاريخ', 'الشحنات', 'المقبوض', 'العمولة', 'المحوّل', 'المطابقة'], V.remittances.map(r => `<tr class="${r.status === 'mismatch' ? 'hl' : ''}"><td class="mono">${esc(r.id)}</td><td class="n">${dt(r.at)}</td><td class="n">${r.shipments}</td><td class="n">${iqd(r.collected)}</td><td class="n">${iqd(r.commission)}</td><td class="n">${iqd(r.amount)}</td><td>${statusBadge(r.status, { sent: 'بانتظار الضرائب', reconciled: 'مطابق', mismatch: 'فرق ' + fmt(-r.diff) }[r.status])}${r.note ? `<div class="small muted">${esc(r.note)}</div>` : ''}</td></tr>`));
    if (t.cur === 'done') body = table(['الرمز', 'التاجر', 'إلى', 'الرسم', 'الحالة'], V.done.map(s => `<tr><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td>${esc(s.gov)}</td><td class="n">${iqd(s.feeDue)}</td><td>${statusBadge(s.status, s.statusText)}</td></tr>`));
    return head(`🚚 ${esc(V.courier.name)}`, `ترخيص <span class="mono">${esc(V.courier.license)}</span> · لا تستلم أي طرد بلا رمز صالح وإجازة فعّالة`) + `<div class="stack">${warn}${remitCard}${kp}<div class="card">${t.html}${body}</div></div>`;
  },
  bind() {
    const r = $('#remit'); if (r) r.onclick = async () => { if (confirm(`تحويل ${fmt(V.balance.net)} د.ع إلى حساب الهيئة العامة للضرائب؟`)) act('courier.remit', {}, x => `حُوّل ${fmt(x.amount)} د.ع — التحويل ${x.id}`); };
    $$('[data-a]').forEach(b => b.onclick = () => act(b.dataset.a, { id: b.dataset.id }, x => x && x.refused ? '⛔ رُفض الاستلام: إجازة التاجر غير فعّالة أو أمر سحب' : 'تم'));
    $$('[data-ret]').forEach(b => b.onclick = async () => { const v = await ask('إرجاع الشحنة', [{ name: 'reason', label: 'السبب', type: 'select', options: [['رفض المشتري الاستلام', 'رفض المشتري الاستلام'], ['المشتري لم يرد على الهاتف', 'المشتري لم يرد على الهاتف'], ['العنوان غير صحيح', 'العنوان غير صحيح']] }]); if (v) act('shipment.return', { id: b.dataset.ret, reason: v.reason }, 'أُرجعت الشحنة'); });
    $$('[data-settle]').forEach(b => b.onclick = () => act('courier.settle', { id: b.dataset.settle }, 'سُدّد الفرق'));
  },
};

// ══════════ الضرائب ══════════
const tax = {
  html() {
    const T = V.totals, sent = V.remittances.filter(r => r.status === 'sent');
    const kp = `<div class="grid g4">${kpi('رسوم قبضها المندوبون', iqd(T.collected), 'عند التسليم')}${kpi('رسوم مقتطعة إلكترونياً', iqd(T.epay), 'عبر مزوّدي الدفع')}${kpi('المحوّل من شركات التوصيل', iqd(T.remitted), `بعد عمولة الجباية ${V.settings.courierCommissionPct}%`, true)}${kpi('رسوم كمركية على الطرود', iqd(T.customs))}</div>`;
    const chain = `<div class="note ${V.chain.ok ? 'ok' : 'bad'}"><span>${V.chain.ok ? '🔗' : '⛔'}</span><span><b>${V.chain.ok ? 'السجل المالي سليم' : 'انكسرت سلسلة السجل عند القيد ' + V.chain.brokenAt}</b>${fmt(V.chain.total)} قيداً مترابطاً بالبصمة — أي تعديل على قيد قديم يظهر هنا فوراً.</span><span class="sp"></span><a class="btn sm" href="/api/export/ledger.csv">تصدير السجل</a> <a class="btn sm" href="/api/export/shipments.csv">تصدير الشحنات</a></div>`;
    const P = V.projection;
    const proj = `<div class="card"><h3>📈 الإسقاط السنوي من عيّنة آخر 30 يوماً</h3><div class="grid g3">${kpi('قيمة المبيعات سنوياً', iqd(P.annualValue))}${kpi('الرسم المحتسب سنوياً', iqd(P.annualComputed))}${kpi('الرسم المستحق سنوياً', iqd(P.annualDue), 'بعد الإعفاءات')}</div><p class="small muted" style="margin:8px 0 0">الفرق بين المحتسب والمستحق = إعفاءات البائعين المنزليين والسلع الأساسية.</p></div>`;
    const t = tabs('t', [['rec', 'المطابقة اليومية', sent.length], ['cour', 'حسب شركة التوصيل'], ['viol', 'مخالفات القيمة', V.violations.length], ['led', 'السجل المالي']]);
    let body = '';
    if (t.cur === 'rec') body = table(['التحويل', 'شركة التوصيل', 'التاريخ', 'الشحنات', 'المتوقع', 'المحوّل', 'النتيجة', ''], V.remittances.map(r => `<tr class="${r.status === 'mismatch' ? 'hl' : ''}"><td class="mono">${esc(r.id)}</td><td>${esc(r.courier)}</td><td class="n">${dt(r.at)}</td><td class="n">${r.shipments}</td><td class="n">${iqd(r.expected)}</td><td class="n">${iqd(r.amount)}</td><td>${statusBadge(r.status, { sent: 'بانتظار المطابقة', reconciled: 'مطابق', mismatch: 'فرق ' + fmt(-r.diff) }[r.status])}${r.note ? `<div class="small muted">${esc(r.note)}</div>` : ''}</td><td>${r.status === 'sent' ? `<button class="btn sm primary" data-rec="${esc(r.id)}">طابق</button>` : ''}</td></tr>`));
    if (t.cur === 'cour') body = table(['شركة التوصيل', 'الترخيص', 'الشحنات', 'المقبوض', 'العمولة', 'المحوّل', 'لم يُحوَّل بعد', 'فروقات'], V.couriers.map(c => `<tr class="${c.mismatch ? 'hl' : ''}"><td><b>${esc(c.name)}</b></td><td class="mono small">${esc(c.license)}</td><td class="n">${fmt(c.shipments)}</td><td class="n">${iqd(c.collected)}</td><td class="n">${iqd(c.commission)}</td><td class="n">${iqd(c.remitted)}</td><td class="n">${iqd(c.outstanding)}</td><td class="n">${c.mismatch ? `<span class="badge bad">${fmt(c.mismatch)} د.ع</span>` : '—'}</td></tr>`));
    if (t.cur === 'viol') body = table(['المخالفة', 'التاريخ', 'الشحنة', 'التاجر', 'المصرّح', 'الحقيقي', 'فرق الرسم'], V.violations.map(v => `<tr><td class="mono">${esc(v.id)}</td><td class="n">${dt(v.at)}</td><td>${codeLink(v.code)}</td><td>${esc(v.merchant)}</td><td class="n">${iqd(v.declared)}</td><td class="n">${iqd(v.actual)}</td><td class="n"><b>${iqd(v.feeGap)}</b></td></tr>`), 'لا مخالفات قيمة');
    if (t.cur === 'led') body = table(['#', 'الوقت', 'النوع', 'المبلغ', 'ملاحظة', 'البصمة'], V.ledger.map(e => `<tr><td class="n">${e.seq}</td><td class="n">${dt(e.at)}</td><td>${esc({ fee_collected: 'رسم مقبوض', fee_epay: 'رسم إلكتروني', remittance: 'تحويل', reconcile: 'مطابقة', customs_duty: 'رسم كمركي' }[e.type] || e.type)}</td><td class="n">${iqd(e.amount)}</td><td class="small">${esc(e.note || '')}</td><td class="mono small muted">${esc(e.hash.slice(0, 12))}</td></tr>`));
    return head('🧾 الهيئة العامة للضرائب', 'كل رسم مقبوض له شحنة، وكل تحويل يُطابق مع ما قبضه المندوبون') + `<div class="stack">${chain}${kp}<div class="card">${t.html}${body}</div>${proj}</div>`;
  },
  bind() { $$('[data-rec]').forEach(b => b.onclick = () => act('tax.reconcile', { id: b.dataset.rec }, x => x.status === 'reconciled' ? 'مطابق ✓' : `غير مطابق: فرق ${fmt(-x.diff)} د.ع — أُبلغت الشركة`)); },
};

// ══════════ وزارة الاقتصاد الرقمي ══════════
const digital = {
  html() {
    const A = V.agg, P = V.projection, M = V.merchants, st = V.settings;
    const phase = `<div class="card hero"><div class="row"><div><div class="muted small">مرحلة النظام</div><div style="font-size:22px;font-weight:800;color:${st.phase === 'fee' ? '#F2D894' : '#7FE3C8'}">${st.phase === 'fee' ? 'المرحلة الأولى — يُجبى الرسم' : 'المرحلة صفر — تسجيل بلا رسم'}</div><div class="muted small">السند: ${esc(st.phaseReason || '')}</div></div><span class="sp"></span><button class="btn gold" id="phase">${st.phase === 'fee' ? 'العودة إلى المرحلة صفر' : 'بدء جباية الرسم'}</button></div></div>`;
    const kp = `<div class="grid g4">${kpi('قيمة التجارة المسجّلة', iqd(A.value), `${fmt(A.count)} شحنة`, true)}${kpi('التجار المُجازون', fmt(M.active), `${M.pending} طلب قيد المراجعة · ${M.suspended} معلّق`)}${kpi('الرسم المحتسب / المستحق', `<span class="num">${fmt(A.computed)}</span> / <span class="num">${fmt(A.due)}</span>`, 'د.ع — الفرق إعفاءات')}${kpi('جباية مزدوجة مُنعت', fmt(V.scans.checkpoint), 'مرة مسح في السيطرات')}</div>`;
    const kp2 = `<div class="grid g4">${kpi('شكاوى مفتوحة', fmt(V.complaints.open), `من ${fmt(V.complaints.total)}`)}${kpi('أوامر سحب فعّالة', fmt(V.recalls))}${kpi('بلاغات صفحات مفتوحة', fmt(V.reports))}${kpi('مخالفات المفتشين', fmt(V.violations), `${fmt(V.scans.inspector)} فحص ميداني`)}</div>`;
    const sim = `<div class="card"><h3>🧮 سيناريو وطني للحصيلة السنوية</h3><div class="fgrid sim"><label class="f">حجم السوق (مليار دولار)<input class="inp" id="sMk" type="number" value="4" step="0.5"></label><label class="f">نسبة التغطية %<input class="inp" id="sCov" type="number" value="40"></label><label class="f">متوسط الرسم %<input class="inp" id="sRate" type="number" value="2" step="0.5"></label><label class="f">سعر الصرف (دينار/دولار)<input class="inp" id="sFx" type="number" value="1320"></label></div><div class="grid g3" style="margin-top:12px" id="simOut"></div><p class="small muted" style="margin:8px 0 0">تقدير وزير الاقتصاد الرقمي لحجم السوق نحو 4 مليارات دولار. النتيجة سيناريو لا توقّع.</p></div>`;
    const govs = Object.entries(A.byGov).sort((a, b) => b[1].value - a[1].value).map(([g, x]) => [g, x.value]);
    const catsE = Object.entries(A.byCat).sort((a, b) => b[1].value - a[1].value).map(([k, x]) => [k, x.value]);
    const chE = Object.entries(A.byChannel).sort((a, b) => b[1].value - a[1].value).map(([k, x]) => [k, x.value]);
    const chName = k => k === 'import' ? 'طلبات من الخارج' : (V.channels[k] || k);
    const charts = `<div class="grid g2"><div class="card"><h3>قيمة المبيعات يومياً — آخر 30 يوماً</h3>${columns(A.byDay)}</div><div class="card"><h3>حسب محافظة المشتري</h3>${bars(govs.slice(0, 10), { valueFmt: v => fmt(v) })}</div><div class="card"><h3>حسب الفئة</h3>${bars(catsE, { label: catName, valueFmt: v => fmt(v) })}</div><div class="card"><h3>حسب مكان البيع</h3>${bars(chE, { label: chName, valueFmt: v => fmt(v) })}<p class="small muted" style="margin:10px 0 0">الدفع الإلكتروني ${(A.byPay.epay / Math.max(1, A.value) * 100).toFixed(0)}% من القيمة · عند الاستلام ${(A.byPay.cod / Math.max(1, A.value) * 100).toFixed(0)}%</p></div></div>`;
    const rates = `<div class="card"><h3>نسب الرسم حسب الفئة <span class="muted small">تُطبّق على الشحنات الجديدة فقط</span></h3>${table(['الفئة', 'النسبة', 'خاضعة للفحص', ''], Object.entries(V.categories).map(([k, c]) => `<tr><td>${esc(c.name)}</td><td class="n"><b>${c.rate}%</b></td><td>${c.regulated ? '<span class="badge info">نعم</span>' : '—'}</td><td><button class="btn sm" data-rate="${k}">تعديل</button></td></tr>`))}<p class="small muted" style="margin:8px 0 0">الحد الأدنى ${fmt(st.minFee)} د.ع للشحنة · سقف إعفاء البائع المنزلي ${fmt(st.homeCap)} د.ع شهرياً · عمولة الجباية لشركات التوصيل ${st.courierCommissionPct}%</p></div>`;
    const circ = `<div class="card"><h3>📣 التعاميم<span class="sp"></span><button class="btn sm primary" id="circ">تعميم جديد</button></h3>${V.circulars.length ? V.circulars.map(c => `<div style="padding:8px 0;border-bottom:1px solid var(--line)"><b>${esc(c.title)}</b> <span class="muted small">${dt(c.at)}</span><div class="small">${esc(c.body)}</div></div>`).join('') : '<div class="empty">لا تعاميم</div>'}</div>`;
    const cour = `<div class="card"><h3>شركات التوصيل المرخصة</h3>${table(['الشركة', 'الشحنات', 'سُلّمت', 'الرسوم المقبوضة', 'فروقات'], V.couriers.map(c => `<tr><td>${esc(c.name)}</td><td class="n">${fmt(c.shipments)}</td><td class="n">${fmt(c.delivered)}</td><td class="n">${iqd(c.collected)}</td><td>${c.mismatch ? `<span class="badge bad">${fmt(c.mismatch)}</span>` : '—'}</td></tr>`))}</div>`;
    const demo = `<div class="card"><h3>نسخة العرض</h3><p class="muted small" style="margin:0 0 10px">تعيد كل البيانات إلى حالتها الأولى قبل العرض، وتُخرج كل المستخدمين.</p><button class="btn danger sm" id="reset">إعادة بيانات العرض</button> <a class="btn sm" href="/api/export/merchants.csv">تصدير سجل التجار</a></div>`;
    return head('🏛️ اللوحة الوطنية للتجارة الإلكترونية', 'أرقام مجمّعة من كل الجهات — لا بيانات مشترين أفراد') + `<div class="stack">${phase}${kp}${kp2}${sim}${charts}<div class="grid g2">${rates}${cour}</div>${circ}${demo}</div>`;
  },
  bind() {
    const calc = () => {
      const mk = +$('#sMk').value || 0, cov = +$('#sCov').value || 0, r = +$('#sRate').value || 0, fx = +$('#sFx').value || 0;
      const usd = mk * 1e9 * cov / 100 * r / 100;
      $('#simOut').innerHTML = kpi('المبيعات المغطاة سنوياً', `<span class="num">${(mk * cov / 100).toFixed(2)}</span> مليار $`) + kpi('الحصيلة السنوية', `<span class="num">${fmt(usd / 1e6)}</span> مليون $`, '', true) + kpi('بالدينار', `<span class="num">${fmt(usd * fx / 1e9)}</span> مليار د.ع`);
    };
    ['#sMk', '#sCov', '#sRate', '#sFx'].forEach(s => $(s).oninput = calc); calc();
    $('#phase').onclick = async () => {
      const to = V.settings.phase === 'fee' ? 'zero' : 'fee';
      const v = await ask(to === 'fee' ? 'بدء جباية الرسم' : 'العودة إلى المرحلة صفر', [{ name: 'reason', label: 'السند القانوني (رقم القانون أو قرار مجلس الوزراء)', placeholder: to === 'fee' ? 'مثلاً: قانون الموازنة العامة لسنة 2027، المادة …' : '' }], { intro: to === 'fee' ? 'الدستور (المادة 28) لا يسمح بفرض رسم إلا بقانون. يُطبَّق الرسم على الشحنات الجديدة فقط، ويُبلَّغ كل الجهات وشركات التوصيل.' : 'تُسجَّل الشحنات الجديدة بقيمها والرسم المحتسب، والمستحق صفر.', okText: 'تأكيد' });
      if (v) act('digital.phase', { phase: to, reason: v.reason }, 'تغيّرت المرحلة وأُبلغت الجهات');
    };
    $$('[data-rate]').forEach(b => b.onclick = async () => { const c = V.categories[b.dataset.rate]; const v = await ask('نسبة الرسم: ' + c.name, [{ name: 'rate', label: 'النسبة %', type: 'number', value: c.rate }]); if (v) act('digital.rate', { cat: b.dataset.rate, rate: v.rate }, 'عُدّلت النسبة'); });
    $('#circ').onclick = async () => { const v = await ask('تعميم جديد', [{ name: 'title', label: 'العنوان' }, { name: 'body', label: 'النص', type: 'textarea' }], { okText: 'أصدر التعميم', intro: 'يصل التعميم إشعاراً إلى كل الجهات والتجار المُجازين وشركات التوصيل.' }); if (v) act('digital.circular', v, 'صدر التعميم'); };
    $('#reset').onclick = async () => { if (!confirm('إعادة كل بيانات العرض إلى حالتها الأولى؟')) return; try { await api('/api/demo/reset', {}); toast('أُعيدت البيانات'); setTimeout(() => location.reload(), 800); } catch (x) { toast(x.message, true); } };
  },
};

// ══════════ وزارة التجارة ══════════
const trade = {
  html() {
    const M = V.merchants, pend = M.filter(m => m.status === 'pending'), act_ = M.filter(m => m.status === 'active'), sus = M.filter(m => m.status === 'suspended');
    const t = tabs('tr', [['pend', 'طلبات الإجازة', pend.length], ['act', 'المُجازون', ''], ['sus', 'المعلّقون والمرفوضون', ''], ['ref', 'إحالات حماية المستهلك', V.referrals.length]]);
    const info = m => `<b>${esc(m.name)}</b><div class="small muted">${esc(m.owner)} · ${esc(m.tierText)} · ${esc(m.channelText)} · ${esc(m.gov)}</div>${m.page ? `<div class="small mono">${esc(m.page)}</div>` : ''}`;
    let body = '';
    if (t.cur === 'pend') body = table(['المتجر', 'البطاقة الموحدة', 'السجل التجاري', 'الهوية الضريبية', 'تاريخ الطلب', ''], pend.map(m => `<tr><td>${info(m)}</td><td class="mono small">••••${esc(m.nidLast4)}</td><td class="mono small">${esc(m.cr || (m.tier === 'home' ? 'غير مطلوب' : '—'))}</td><td class="mono small">${esc(m.taxId || '—')}</td><td class="n">${dt(m.at)}</td><td style="white-space:nowrap"><button class="btn sm primary" data-t="approve" data-id="${m.id}">إصدار الإجازة</button> <button class="btn sm ghost" data-t="reject" data-id="${m.id}">رفض</button></td></tr>`), 'لا طلبات بانتظار القرار');
    if (t.cur === 'act') body = table(['المتجر', 'رقم الإجازة', 'الشحنات', 'المبيعات', 'الشكاوى', ''], act_.map(m => `<tr><td>${info(m)}</td><td class="mono">${esc(m.license)}</td><td class="n">${fmt(m.shipments)}</td><td class="n">${iqd(m.value)}</td><td class="n">${m.complaints ? `<span class="badge ${m.complaints > 2 ? 'bad' : 'warn'}">${m.complaints}</span>` : '0'}</td><td><button class="btn sm ghost" data-t="suspend" data-id="${m.id}">تعليق</button></td></tr>`));
    if (t.cur === 'sus') body = table(['المتجر', 'الحالة', 'السبب', ''], [...sus, ...M.filter(m => m.status === 'rejected')].map(m => `<tr><td>${info(m)}</td><td>${statusBadge(m.status, MSTATUS[m.status])}</td><td class="small">${esc((m.decisions.slice(-1)[0] || {}).reason || '')}</td><td>${m.status === 'suspended' ? `<button class="btn sm" data-t="reinstate" data-id="${m.id}">إعادة التفعيل</button>` : ''}</td></tr>`));
    if (t.cur === 'ref') body = table(['الشكوى', 'التاجر', 'المشكلة', 'ملاحظة المجلس', 'التاريخ'], V.referrals.map(c => `<tr><td class="mono">${esc(c.id)}</td><td>${esc(c.merchant)}</td><td>${esc(c.kindText)}</td><td class="small">${esc(c.note || '')}</td><td class="n">${dt(c.closedAt || c.at)}</td></tr>`), 'لا إحالات');
    return head('📜 وزارة التجارة — سجل التجار الإلكترونيين', 'سند الإجازة: نظام تنظيم التجارة الإلكترونية رقم 4 لسنة 2025') + `<div class="stack"><div class="grid g4">${kpi('طلبات بانتظار القرار', fmt(pend.length), '', true)}${kpi('تجار مُجازون', fmt(act_.length))}${kpi('إجازات معلّقة', fmt(sus.length))}${kpi('بائعون منزليون', fmt(act_.filter(m => m.tier === 'home').length), 'فئة مبسّطة بالبطاقة الموحدة')}</div><div class="card">${t.html}${body}</div><div class="row"><a class="btn sm" href="/api/export/merchants.csv">تصدير سجل التجار</a></div></div>`;
  },
  bind() {
    $$('[data-t]').forEach(b => b.onclick = async () => {
      const a = b.dataset.t, id = b.dataset.id;
      if (a === 'approve' || a === 'reinstate') return act('trade.act', { id, act: a }, x => a === 'approve' ? 'صدرت الإجازة ' + x.license : 'أُعيدت الإجازة');
      const v = await ask(a === 'reject' ? 'رفض الطلب' : 'تعليق الإجازة', [{ name: 'reason', label: 'السبب (يصل إلى التاجر)', type: 'textarea' }], { danger: true, okText: a === 'reject' ? 'رفض' : 'علّق الإجازة', intro: a === 'suspend' ? 'بعد التعليق ترفض شركات التوصيل استلام أي طلب لهذا التاجر.' : '' });
      if (v) act('trade.act', { id, act: a, reason: v.reason }, 'تم');
    });
  },
};

// ══════════ الكمارك ══════════
const customs = {
  html() {
    const D = V.declarations, sub = D.filter(d => d.status === 'submitted');
    const body = table(['البيان', 'التاريخ', 'الوسيط', 'من', 'المنفذ', 'القطع', 'القيمة', 'الحالة', ''], D.map(d => `<tr class="${d.status === 'submitted' ? 'hl' : ''}"><td class="mono">${esc(d.id)}</td><td class="n">${dt(d.at)}</td><td>${esc(d.merchant)}</td><td>${esc(d.source)}</td><td class="small">${esc(d.port)}</td><td class="small">${d.items.map(i => esc(i.name) + ' ×' + i.qty).join('، ')}</td><td class="n">${iqd(d.value)}</td><td>${statusBadge(d.status, { submitted: 'بانتظار القرار', cleared: 'خُلّص — رسم ' + fmt(d.duty), held: 'محجوز' }[d.status])}${d.code ? `<div>${codeLink(d.code)}</div>` : ''}${d.reason ? `<div class="small muted">${esc(d.reason)}</div>` : ''}</td><td style="white-space:nowrap">${d.status === 'submitted' ? `<button class="btn sm primary" data-c="clear" data-id="${d.id}">تخليص</button> <button class="btn sm ghost" data-c="hold" data-id="${d.id}">حجز</button>` : ''}</td></tr>`));
    return head('🛃 الهيئة العامة للكمارك — الطرود منخفضة القيمة', 'الوسيط المُجاز يقدّم البيان قبل وصول الطرد، وبعد التخليص يصدر رمز الشحنة تلقائياً') + `<div class="stack"><div class="grid g4">${kpi('بيانات بانتظار القرار', fmt(sub.length), '', true)}${kpi('طرود خُلّصت', fmt(D.filter(d => d.status === 'cleared').length))}${kpi('الرسوم الكمركية', iqd(V.totals.customs))}${kpi('قيمة الطلبات من الخارج', iqd(V.imports.value))}</div><div class="card"><h3>البيانات المسبقة</h3>${body}</div></div>`;
  },
  bind() {
    $$('[data-c]').forEach(b => b.onclick = async () => {
      if (b.dataset.c === 'clear') { const v = await ask('تخليص الطرد', [{ name: 'dutyPct', label: 'نسبة الرسم الكمركي %', type: 'number', value: 5 }], { okText: 'خلّص وأصدر الرمز' }); if (v) act('customs.act', { id: b.dataset.id, act: 'clear', dutyPct: v.dutyPct }, 'خُلّص وصدر رمز الشحنة'); }
      else { const v = await ask('حجز الطرد', [{ name: 'reason', label: 'السبب', type: 'textarea' }], { danger: true, okText: 'احجز' }); if (v) act('customs.act', { id: b.dataset.id, act: 'hold', reason: v.reason }, 'حُجز البيان'); }
    });
  },
};

// ══════════ التقييس والجودة ══════════
const quality = {
  html() {
    const pend = V.samples.filter(s => s.result === 'pending'), act_ = V.recalls.filter(r => r.active);
    const t = tabs('q', [['hub', 'في مخازن شركات التوصيل', V.hub.length], ['smp', 'العينات', pend.length], ['rc', 'أوامر السحب', act_.length], ['und', 'بضاعة غير مصرّح بها', V.undeclared.length]]);
    let body = '';
    if (t.cur === 'hub') body = table(['الرمز', 'التاجر', 'القطع الخاضعة للفحص', 'شركة التوصيل', 'الحالة', ''], V.hub.map(s => `<tr><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td class="small">${esc(s.regItems)}</td><td>${esc(s.courier)}</td><td>${statusBadge(s.status, s.statusText)}</td><td>${s.sampled ? '<span class="badge gray">سُحبت عينة</span>' : `<button class="btn sm primary" data-smp="${s.id}">سحب عينة</button>`}</td></tr>`), 'لا شحنات خاضعة للفحص في المخازن الآن');
    if (t.cur === 'smp') body = table(['العينة', 'التاريخ', 'الشحنة', 'التاجر', 'القطعة', 'النتيجة', ''], V.samples.map(s => `<tr class="${s.result === 'fail' ? 'hl' : ''}"><td class="mono">${esc(s.id)}</td><td class="n">${dt(s.at)}</td><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td>${esc(s.item)}</td><td>${statusBadge(s.result, { pending: 'في المختبر', pass: 'مطابقة', fail: 'غير مطابقة' }[s.result])}${s.note ? `<div class="small muted">${esc(s.note)}</div>` : ''}</td><td style="white-space:nowrap">${s.result === 'pending' ? `<button class="btn sm primary" data-res="pass" data-id="${s.id}">مطابقة</button> <button class="btn sm danger" data-res="fail" data-id="${s.id}">غير مطابقة</button>` : ''}</td></tr>`));
    if (t.cur === 'rc') body = table(['الأمر', 'التاريخ', 'التاجر', 'الفئة', 'السبب', 'شحنات أُوقفت', ''], V.recalls.map(r => `<tr><td class="mono">${esc(r.id)}</td><td class="n">${dt(r.at)}</td><td>${esc(r.merchant)}</td><td>${esc(r.catName)}</td><td class="small">${esc(r.reason)}</td><td class="n">${r.held}</td><td>${r.active ? `<button class="btn sm" data-lift="${r.id}">رفع الأمر</button>` : `<span class="badge gray">رُفع</span>`}</td></tr>`), 'لا أوامر سحب');
    if (t.cur === 'und') body = table(['المخالفة', 'التاريخ', 'الشحنة', 'التاجر', 'ما وجده المفتش'], V.undeclared.map(v => `<tr><td class="mono">${esc(v.id)}</td><td class="n">${dt(v.at)}</td><td>${codeLink(v.code)}</td><td>${esc(v.merchant)}</td><td class="small">${esc(v.note)}</td></tr>`), 'لا مخالفات');
    return head('🔬 الجهاز المركزي للتقييس والسيطرة النوعية', 'كل البضائع تمر بمخازن شركات التوصيل — هناك تُسحب العينات') + `<div class="stack"><div class="grid g4">${kpi('شحنات خاضعة للفحص في المخازن', fmt(V.hub.length), '', true)}${kpi('عينات في المختبر', fmt(pend.length))}${kpi('أوامر سحب فعّالة', fmt(act_.length))}${kpi('عينات غير مطابقة', fmt(V.samples.filter(s => s.result === 'fail').length))}</div><div class="card">${t.html}${body}</div></div>`;
  },
  bind() {
    $$('[data-smp]').forEach(b => b.onclick = () => act('quality.sample', { id: b.dataset.smp }, x => 'سُحبت العينة ' + x.id));
    $$('[data-res]').forEach(b => b.onclick = async () => {
      if (b.dataset.res === 'pass') return act('quality.result', { id: b.dataset.id, result: 'pass' }, 'سُجّلت: مطابقة');
      const v = await ask('عينة غير مطابقة', [{ name: 'note', label: 'سبب عدم المطابقة', type: 'textarea' }], { danger: true, okText: 'سجّل وأصدر أمر السحب', intro: 'يُوقف أمر السحب كل شحنات هذا التاجر من الفئة نفسها في المخازن، ويمنع إرسال الفئة حتى يُرفع.' });
      if (v) act('quality.result', { id: b.dataset.id, result: 'fail', note: v.note }, 'صدر أمر السحب');
    });
    $$('[data-lift]').forEach(b => b.onclick = async () => { const v = await ask('رفع أمر السحب', [{ name: 'note', label: 'سبب الرفع', type: 'textarea' }]); if (v) act('quality.lift', { id: b.dataset.lift, note: v.note }, 'رُفع الأمر'); });
  },
};

// ══════════ حماية المستهلك ══════════
const consumer = {
  html() {
    const C = V.complaints, open = C.filter(c => c.status === 'open');
    const t = tabs('k', [['open', 'مفتوحة', open.length], ['closed', 'مغلقة'], ['top', 'التجار الأكثر شكاوى']]);
    let body = '';
    if (t.cur === 'open') body = table(['الشكوى', 'التاريخ', 'الشحنة', 'التاجر', 'المشكلة', 'ما كتبه المشتري', 'ردّ التاجر', 'القرار'], open.map(c => `<tr><td class="mono">${esc(c.id)}</td><td class="n">${dt(c.at)}</td><td>${codeLink(c.code)}</td><td>${esc(c.merchant)}<div class="mono small muted">${esc(c.license || '')}</div></td><td>${esc(c.kindText)}</td><td class="small">${esc(c.text)}</td><td class="small">${esc(c.reply || '—')}</td><td style="white-space:nowrap"><button class="btn sm primary" data-d="refund" data-id="${c.id}">إلزام بالاسترجاع</button> <button class="btn sm" data-d="refer" data-id="${c.id}">إحالة للتجارة</button> <button class="btn sm ghost" data-d="rejected" data-id="${c.id}">ردّ</button></td></tr>`), 'لا شكاوى مفتوحة');
    if (t.cur === 'closed') body = table(['الشكوى', 'الشحنة', 'التاجر', 'المشكلة', 'القرار'], C.filter(c => c.status === 'closed').map(c => `<tr><td class="mono">${esc(c.id)}</td><td>${codeLink(c.code)}</td><td>${esc(c.merchant)}</td><td>${esc(c.kindText)}</td><td>${statusBadge(c.decision === 'rejected' ? 'rejected' : 'closed', c.decisionText)}</td></tr>`));
    if (t.cur === 'top') body = table(['التاجر', 'الإجازة', 'الشكاوى', 'المفتوحة', 'الحالة'], V.topMerchants.map(m => `<tr><td>${esc(m.name)}</td><td class="mono small">${esc(m.license || '')}</td><td class="n">${m.complaints}</td><td class="n">${m.openComplaints}</td><td>${statusBadge(m.status, MSTATUS[m.status])}</td></tr>`));
    const rc = V.recalls.length ? `<div class="card"><h3>⛔ أوامر سحب فعّالة</h3>${V.recalls.map(r => `<div class="small">${esc(r.merchant)} — ${esc(r.catName)}: ${esc(r.reason)}</div>`).join('')}</div>` : '';
    return head('🛡️ مجلس حماية المستهلك', 'كل شكوى مربوطة بشحنة حقيقية — المشتري يتحقق بآخر 4 أرقام من هاتفه') + `<div class="stack"><div class="grid g4">${kpi('شكاوى مفتوحة', fmt(open.length), '', true)}${kpi('مجموع الشكاوى', fmt(C.length))}${kpi('إلزام بالاسترجاع', fmt(C.filter(c => c.decision === 'refund').length))}${kpi('إحالات لتعليق الإجازة', fmt(C.filter(c => c.decision === 'refer').length))}</div>${rc}<div class="card">${t.html}${body}</div></div>`;
  },
  bind() {
    $$('[data-d]').forEach(b => b.onclick = async () => {
      const d = b.dataset.d;
      const v = await ask({ refund: 'إلزام التاجر بالاسترجاع أو الاستبدال', refer: 'إحالة إلى وزارة التجارة', rejected: 'ردّ الشكوى' }[d], [{ name: 'note', label: 'ملاحظة (اختيارية)', type: 'textarea' }], { okText: 'أصدر القرار' });
      if (v) act('complaint.decide', { id: b.dataset.id, decision: d, note: v.note }, 'صدر القرار');
    });
  },
};

// ══════════ هيئة الإعلام والاتصالات ══════════
const cmc = {
  html() {
    const R = V.reports, open = R.filter(r => r.status === 'open');
    const t = tabs('cm', [['rep', 'البلاغات', open.length], ['live', 'البائعون عبر البث والتيك توك'], ['plat', 'المنصات الأجنبية']]);
    let body = '';
    if (t.cur === 'rep') body = table(['البلاغ', 'التاريخ', 'الصفحة', 'المنصة', 'رقم إجازة ظاهر', 'الملاحظة', 'الإجراء'], R.map(r => `<tr class="${r.status === 'open' ? 'hl' : ''}"><td class="mono">${esc(r.id)}</td><td class="n">${dt(r.at)}</td><td class="mono small">${esc(r.url)}</td><td>${esc(r.channelText)}</td><td>${r.license ? (r.merchant ? `<span class="badge ok">${esc(r.license)}</span><div class="small">${esc(r.merchant)}</div>` : `<span class="badge bad">${esc(r.license)} غير موجود</span>`) : '<span class="badge bad">لا يظهر</span>'}</td><td class="small">${esc(r.note)}</td><td style="white-space:nowrap">${r.status === 'open' ? `<button class="btn sm primary" data-r="notify" data-id="${r.id}">إنذار</button> <button class="btn sm danger" data-r="takedown" data-id="${r.id}">طلب حجب</button> <button class="btn sm ghost" data-r="resolved" data-id="${r.id}">حُلّ</button>` : statusBadge('closed', r.actionText)}</td></tr>`));
    if (t.cur === 'live') body = table(['البائع', 'المنصة', 'الصفحة', 'رقم الإجازة', 'الحالة', 'الشكاوى'], V.liveSellers.map(m => `<tr><td>${esc(m.name)}</td><td>${esc(m.channelText)}</td><td class="mono small">${esc(m.page)}</td><td class="mono small">${esc(m.license || '—')}</td><td>${statusBadge(m.status, MSTATUS[m.status])}</td><td class="n">${m.complaints}</td></tr>`));
    if (t.cur === 'plat') body = table(['المنصة', 'البلد', 'حالة التسجيل', 'منذ'], V.platforms.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.country)}</td><td>${statusBadge(p.status === 'مسجّلة' ? 'active' : p.status === 'قيد التسجيل' ? 'pending' : 'suspended', p.status)}</td><td class="n">${esc(p.since || '—')}</td></tr>`));
    return head('📡 هيئة الإعلام والاتصالات', 'رقم الإجازة إلزامي في كل صفحة وبث — والتطبيق يحدث عند التسليم لا عند العرض') + `<div class="stack"><div class="grid g4">${kpi('بلاغات مفتوحة', fmt(open.length), '', true)}${kpi('مجموع البلاغات', fmt(R.length))}${kpi('طلبات حجب', fmt(R.filter(r => r.action === 'takedown').length))}${kpi('بائعون عبر البث', fmt(V.liveSellers.length))}</div><div class="card">${t.html}${body}</div></div>`;
  },
  bind() { $$('[data-r]').forEach(b => b.onclick = () => act('cmc.act', { id: b.dataset.id, act: b.dataset.r }, 'سُجّل الإجراء')); },
};

// ══════════ البنك المركزي ══════════
const cbi = {
  html() {
    const A = V.agg, T = V.totals, ep = A.byPay.epay / Math.max(1, A.value) * 100;
    return head('🏦 البنك المركزي العراقي — المدفوعات', 'اطلاع فقط: حصة الدفع الإلكتروني وتدفقات التحصيل') + `<div class="stack"><div class="grid g4">${kpi('حصة الدفع الإلكتروني', `<span class="num">${ep.toFixed(1)}%</span>`, 'من قيمة المبيعات', true)}${kpi('مدفوع إلكترونياً', iqd(A.byPay.epay))}${kpi('عند الاستلام نقداً', iqd(A.byPay.cod))}${kpi('رسوم اقتُطعت عبر مزوّدي الدفع', iqd(T.epay))}</div>
      <div class="grid g2"><div class="card"><h3>حصص مزوّدي الدفع</h3>${bars(V.providers.map(p => [p.name, p.share]), { max: 100, valueFmt: v => v + '%' })}</div><div class="card"><h3>تحويلات شركات التوصيل</h3>${table(['الشركة', 'المقبوض', 'المحوّل', 'لم يُحوَّل'], V.couriers.map(c => `<tr><td>${esc(c.name)}</td><td class="n">${iqd(c.collected)}</td><td class="n">${iqd(c.remitted)}</td><td class="n">${iqd(c.outstanding)}</td></tr>`))}</div></div>
      <div class="card"><h3>قيمة المبيعات يومياً</h3>${columns(A.byDay)}</div></div>`;
  },
};

// ══════════ الرقابة ══════════
const audit = {
  html() {
    const C = V.chains, ch = (n, c) => `<div class="note ${c.ok ? 'ok' : 'bad'}"><span>${c.ok ? '🔗' : '⛔'}</span><span><b>${n}: ${c.ok ? 'سليم' : 'مكسور عند القيد ' + c.brokenAt}</b>${fmt(c.total)} قيداً مترابطاً بالبصمة${c.last ? ` · آخر بصمة <span class="mono">${esc(c.last)}</span>` : ''}</span></div>`;
    const t = tabs('a', [['log', 'سجل الأفعال'], ['led', 'السجل المالي'], ['cour', 'شركات التوصيل']]);
    let body = '';
    if (t.cur === 'log') body = table(['#', 'الوقت', 'المستخدم', 'الجهة', 'الفعل', 'المرجع', 'التفاصيل'], V.auditLog.map(e => `<tr><td class="n">${e.seq}</td><td class="n">${dt(e.at)}</td><td class="mono small">${esc(e.who)}</td><td class="small">${esc(e.role)}</td><td>${esc(e.action)}</td><td class="mono small">${esc(e.ref)}</td><td class="small">${esc(e.detail)}</td></tr>`));
    if (t.cur === 'led') body = table(['#', 'الوقت', 'النوع', 'المبلغ', 'ملاحظة', 'البصمة'], V.ledger.map(e => `<tr><td class="n">${e.seq}</td><td class="n">${dt(e.at)}</td><td>${esc(e.type)}</td><td class="n">${iqd(e.amount)}</td><td class="small">${esc(e.note || '')}</td><td class="mono small muted">${esc(e.hash.slice(0, 12))}</td></tr>`));
    if (t.cur === 'cour') body = table(['الشركة', 'المقبوض', 'العمولة', 'المحوّل', 'لم يُحوَّل', 'فروقات'], V.couriers.map(c => `<tr class="${c.mismatch ? 'hl' : ''}"><td>${esc(c.name)}</td><td class="n">${iqd(c.collected)}</td><td class="n">${iqd(c.commission)}</td><td class="n">${iqd(c.remitted)}</td><td class="n">${iqd(c.outstanding)}</td><td class="n">${c.mismatch ? `<span class="badge bad">${fmt(c.mismatch)}</span>` : '—'}</td></tr>`));
    const K = V.counts;
    return head('⚖️ الجهات الرقابية', 'هيئة النزاهة وديوان الرقابة المالية الاتحادي — اطلاع وتصدير فقط، لا كتابة', `<div class="row"><a class="btn sm" href="/api/export/audit.csv">تصدير سجل الأفعال</a><a class="btn sm" href="/api/export/ledger.csv">تصدير السجل المالي</a><a class="btn sm" href="/api/export/shipments.csv">تصدير الشحنات</a><a class="btn sm" href="/api/export/merchants.csv">تصدير التجار</a></div>`) +
      `<div class="stack"><div class="grid g2">${ch('السجل المالي', C.ledger)}${ch('سجل الأفعال', C.audit)}</div><div class="grid g4">${kpi('قيمة المبيعات المسجّلة', iqd(V.agg.value), `${fmt(K.shipments)} شحنة`, true)}${kpi('المحوّل للضرائب', iqd(V.totals.remitted))}${kpi('الشكاوى / أوامر السحب', `<span class="num">${K.complaints} / ${K.recalls}</span>`)}${kpi('مخالفات المفتشين', fmt(K.violations))}</div><div class="card">${t.html}${body}</div></div>`;
  },
};

// ══════════ المفتش والسيطرة ══════════
const scanner = {
  html() {
    const cp = V.me.role === 'checkpoint';
    const box = `<div class="card hero" style="text-align:center"><div style="font-size:44px">📷</div><h2 style="font-size:22px;margin:6px 0">امسح رمز الطرد بكاميرا الهاتف</h2><p class="muted" style="margin:0 0 14px">تفتح صفحة الشحنة تلقائياً وفيها ${cp ? 'زر «تسجيل المرور»' : 'أزرار نتيجة الفحص'}. أو اكتب الرمز:</p><form id="sf" class="row" style="justify-content:center"><input class="inp mono" id="sc" placeholder="DM…" style="max-width:280px" autocomplete="off"><button class="btn gold">افتح</button></form></div>`;
    const kp = cp ? `<div class="grid g3">${kpi('مرات المسح', fmt(V.scans.length), V.me.place, true)}${kpi('جباية مزدوجة مُنعت', fmt(V.saved), 'طرود مرّت والرسم مثبت')}${kpi('أُبلغ عنها', fmt(V.scans.filter(s => s.result === 'flag').length))}</div>` : `<div class="grid g3">${kpi('فحوصي', fmt(V.scans.length), V.me.place, true)}${kpi('مطابقة', fmt(V.scans.filter(s => s.result === 'match').length))}${kpi('مخالفات', fmt(V.scans.filter(s => s.result !== 'match').length))}</div>`;
    const near = `<div class="card"><h3>طرود في الطريق الآن <span class="muted small">للعرض: افتح أياً منها كأنك مسحته</span></h3>${table(['الرمز', 'التاجر', 'إلى', 'القيمة'], V.nearby.map(s => `<tr><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td>${esc(s.gov)}</td><td class="n">${iqd(s.value)}</td></tr>`), 'لا طرود في الطريق')}</div>`;
    const mine = `<div class="card"><h3>آخر ما مسحته</h3>${table(['الوقت', 'الرمز', 'التاجر', 'النتيجة'], V.scans.map(s => `<tr><td class="n">${dt(s.at)}</td><td>${codeLink(s.code)}</td><td>${esc(s.merchant)}</td><td>${statusBadge(s.result, s.text)}</td></tr>`), 'لم تمسح شيئاً بعد')}</div>`;
    return head(cp ? '🚧 ' + esc(V.me.place) : '🔎 ' + esc(V.me.place), cp ? 'الرمز يثبت أن الرسم مدفوع — لا تُجبى أي رسوم إضافية على طرد رمزه سليم' : 'افتح الطرد، قارن المحتوى بالبيان، وسجّل النتيجة بضغطة') + `<div class="stack">${box}${kp}<div class="grid g2">${near}${mine}</div></div>`;
  },
  bind() { $('#sf').onsubmit = e => { e.preventDefault(); const v = $('#sc').value.trim().replace(/\s/g, ''); if (v) location.href = '/c/' + encodeURIComponent(v); }; },
};

if (!PNAME[PORTAL]) location.href = '/'; else boot();
