// أدوات مشتركة لواجهات «ضمان»
'use strict';
const GOV_NAME = 'وزارة الاقتصاد الرقمي والحوكمة';
const GOV_SEAL = `<img class="seal" src="/img/mdeg-192.webp" alt="شعار ${GOV_NAME}">`;
const GOV_TAG = `<span class="gov"><img src="/img/mdeg-192.webp" alt="شعار ${GOV_NAME}"><span><small>بإشراف</small><b>${GOV_NAME}</b></span></span>`;
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => (Math.round(+n || 0)).toLocaleString('en-US');
const iqd = n => `<span class="num">${fmt(n)}</span> د.ع`;
const pad = n => String(n).padStart(2, '0');
function dt(iso, withTime = true) { if (!iso) return ''; const d = new Date(iso); return `<span class="num">${pad(d.getDate())}/${pad(d.getMonth() + 1)}${withTime ? ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) : '/' + d.getFullYear()}</span>`; }
function ago(iso) { const m = (Date.now() - new Date(iso)) / 60e3; if (m < 1) return 'الآن'; if (m < 60) return `قبل ${Math.round(m)} دقيقة`; if (m < 1440) return `قبل ${Math.round(m / 60)} ساعة`; return `قبل ${Math.round(m / 1440)} يوم`; }

async function api(path, body) {
  const opt = body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
  const r = await fetch(path, { credentials: 'same-origin', ...opt });
  let j = {};
  try { j = await r.json(); } catch { }
  if (!r.ok) { const e = new Error(j.error || 'تعذّر الاتصال بالخادم'); e.status = r.status; e.data = j; throw e; }
  return j;
}

function toast(msg, bad) {
  const t = document.createElement('div');
  t.className = 'toast' + (bad ? ' bad' : '');
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), bad ? 5200 : 3200);
}

// نافذة عامة: تعيد عنصر الجسم ودالة الإغلاق
function modal(title, html, { wide = false, onClose } = {}) {
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal${wide ? ' wide' : ''}" role="dialog" aria-modal="true"><header><h3>${esc(title)}</h3><button class="x" aria-label="إغلاق">×</button></header>${html}</div>`;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); onClose && onClose(); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  bg.addEventListener('click', e => { if (e.target === bg) close(); });
  $('.x', bg).onclick = close;
  document.addEventListener('keydown', onKey);
  document.body.appendChild(bg);
  return { el: bg, close };
}

// سؤال بحقول: يعيد القيم أو null
function ask(title, fields, { okText = 'تأكيد', danger = false, intro = '' } = {}) {
  return new Promise(resolve => {
    let done = false;
    const html = `<div class="body"><form class="stack" style="gap:12px">${intro ? `<div class="note info">${intro}</div>` : ''}${fields.map(f => {
      const id = 'f_' + f.name;
      if (f.type === 'select') return `<label class="f">${esc(f.label)}<select class="inp" id="${id}" name="${f.name}">${f.options.map(o => `<option value="${esc(o[0])}"${o[0] === f.value ? ' selected' : ''}>${esc(o[1])}</option>`).join('')}</select></label>`;
      if (f.type === 'textarea') return `<label class="f">${esc(f.label)}<textarea class="inp" id="${id}" name="${f.name}" placeholder="${esc(f.placeholder || '')}">${esc(f.value || '')}</textarea></label>`;
      return `<label class="f">${esc(f.label)}<input class="inp" id="${id}" name="${f.name}" type="${f.type || 'text'}" value="${esc(f.value == null ? '' : f.value)}" placeholder="${esc(f.placeholder || '')}" ${f.type === 'number' ? 'inputmode="decimal" step="any"' : ''}></label>`;
    }).join('')}<button type="submit" class="hide"></button></form></div><footer><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(okText)}</button><button class="btn ghost" data-cancel>إلغاء</button></footer>`;
    const m = modal(title, html, { onClose: () => { if (!done) resolve(null); } });
    const submit = () => { const o = {}; for (const f of fields) o[f.name] = $('#f_' + f.name, m.el).value.trim(); done = true; m.close(); resolve(o); };
    $('[data-ok]', m.el).onclick = submit;
    $('form', m.el).onsubmit = e => { e.preventDefault(); submit(); };
    $('[data-cancel]', m.el).onclick = () => m.close();
    const first = $('input,select,textarea', m.el); first && first.focus();
  });
}

const statusBadge = (s, text) => {
  const c = { created: 'info', picked: 'gold', transit: 'gold', delivered: 'ok', returned: 'gray', refused: 'bad', held: 'bad', active: 'ok', pending: 'warn', suspended: 'bad', rejected: 'gray', open: 'warn', closed: 'ok', sent: 'info', reconciled: 'ok', mismatch: 'bad', submitted: 'warn', cleared: 'ok', pass: 'ok', fail: 'bad', match: 'ok', undervalue: 'bad', undeclared: 'bad', flag: 'bad' }[s] || 'gray';
  return `<span class="badge ${c}">${esc(text || s)}</span>`;
};
const MSTATUS = { active: 'مُجاز', pending: 'قيد المراجعة', suspended: 'إجازة معلّقة', rejected: 'مرفوض' };

function bars(entries, { max, valueFmt = v => fmt(v), label = k => k } = {}) {
  const m = max || Math.max(1, ...entries.map(e => e[1]));
  return `<div class="bars">${entries.map(([k, v, extra]) => `<div class="bar"><span>${esc(label(k))}</span><span class="t"><i style="width:${Math.max(1, v / m * 100).toFixed(1)}%"></i></span><span class="v">${valueFmt(v, extra)}</span></div>`).join('')}</div>`;
}
function columns(days) {
  const keys = Object.keys(days).sort(), m = Math.max(1, ...keys.map(k => days[k].value));
  return `<div class="cols">${keys.map(k => `<i style="height:${(days[k].value / m * 100).toFixed(1)}%" title="${esc(k)}: ${fmt(days[k].value)} د.ع — ${days[k].n} شحنة"></i>`).join('')}</div><div class="cols-x"><span>${esc(keys[0] || '')}</span><span>${esc(keys[keys.length - 1] || '')}</span></div>`;
}
function table(cols, rows, empty = 'لا يوجد شيء هنا بعد') {
  if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<div class="tbl-wrap"><table class="tbl"><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
}
function kpi(label, value, sub = '', accent = false) { return `<div class="card kpi${accent ? ' accent' : ''}"><span class="l">${esc(label)}</span><span class="v">${value}</span>${sub ? `<span class="s">${sub}</span>` : ''}</div>`; }
function copy(text) { (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(() => toast('نُسخ'), () => toast('انسخه يدوياً: ' + text)); }
// على الهاتف: كل صف جدول يصبح بطاقة، وكل خلية تحمل اسم عمودها
function labelTables(el = document) {
  for (const t of $$('table.tbl', el)) {
    const heads = $$('thead th', t).map(th => th.textContent.trim());
    for (const tr of $$('tbody tr', t)) [...tr.children].forEach((td, i) => { if (heads[i]) td.setAttribute('data-l', heads[i]); });
  }
}
