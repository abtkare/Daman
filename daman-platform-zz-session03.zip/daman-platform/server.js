// خادم «ضمان» — منصة تنظيم التجارة الإلكترونية وجباية رسومها. بلا حزم خارجية.
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const S = require('./store');
const L = require('./logic');
const QR = require('./qr');
const seed = require('./seed');
const E = require('./entities');

const PORT = process.env.PORT || 3000;
const PUB = path.join(__dirname, 'public');
const PORTALS = Object.keys(L.ROLES);

S.load(seed);
E.ensure(S.db); // ترقية الجلسة 3: الجهات وشعاراتها وحساب مشغّل النظام، دون مسح البيانات المحفوظة

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json' };
const SECURITY = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' };

// ── الجلسات ──
const SESS = new Map();
const SESSION_HOURS = 12;
function cookies(req) { const o = {}; for (const p of String(req.headers.cookie || '').split(';')) { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } return o; }
function currentUser(req) {
  const t = cookies(req).dmn;
  const s = t && SESS.get(t);
  if (!s || s.exp < Date.now()) { if (t) SESS.delete(t); return null; }
  return S.db.users.find(u => u.username === s.username) || null;
}
function isHttps(req) { return req.headers['x-forwarded-proto'] === 'https'; }
function publicUrl(req) { return process.env.PUBLIC_URL || `${isHttps(req) ? 'https' : 'http'}://${req.headers.host}`; }

// حد بسيط لمحاولات الدخول
const TRIES = new Map();
function tooMany(ip) { const now = Date.now(), t = (TRIES.get(ip) || []).filter(x => now - x < 10 * 60e3); TRIES.set(ip, t); return t.length >= 12; }

function send(res, code, body, type, extra = {}) { res.writeHead(code, { 'Content-Type': type, ...SECURITY, ...extra }); res.end(body); }
function json(res, code, obj, extra) { send(res, code, JSON.stringify(obj), 'application/json; charset=utf-8', { 'Cache-Control': 'no-store', ...extra }); }
function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > limit) { reject(Object.assign(new Error('الطلب أكبر من المسموح'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(Object.assign(new Error('صيغة الطلب غير صحيحة'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function serveFile(res, file) {
  fs.readFile(file, (e, buf) => {
    if (e) return serve404(res);
    const ext = path.extname(file).toLowerCase();
    send(res, 200, buf, TYPES[ext] || 'application/octet-stream', { 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' });
  });
}
function serve404(res) { fs.readFile(path.join(PUB, '404.html'), (e, b) => send(res, 404, e ? 'غير موجود' : b, 'text/html; charset=utf-8')); }

async function api(req, res, url) {
  const p = url.pathname, method = req.method;
  const user = currentUser(req);
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

  if (p === '/api/login' && method === 'POST') {
    if (tooMany(ip)) return json(res, 429, { error: 'محاولات كثيرة، انتظر 10 دقائق' });
    const b = await readBody(req);
    const u = S.db.users.find(x => x.username === String(b.username || '').trim().toLowerCase());
    if (!u || !S.checkPassword(b.password, u.pass)) { TRIES.get(ip).push(Date.now()); return json(res, 401, { error: 'اسم الدخول أو كلمة المرور غير صحيحة' }); }
    const ent = u.entityId && (S.db.entities || []).find(e => e.id === u.entityId);
    if (ent && ent.active === false) return json(res, 403, { error: `حساب «${ent.name}» موقوف من مشغّل النظام` });
    if (b.portal && PORTALS.includes(b.portal) && b.portal !== u.role) return json(res, 403, { error: `هذا الحساب لبوابة «${L.ROLES[u.role].short}»`, portal: u.role });
    const tok = crypto.randomBytes(24).toString('hex');
    SESS.set(tok, { username: u.username, exp: Date.now() + SESSION_HOURS * 3600e3 });
    L.log(u, 'تسجيل دخول', u.role, '');
    return json(res, 200, { ok: true, role: u.role, name: u.name }, { 'Set-Cookie': `dmn=${tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_HOURS * 3600}${isHttps(req) ? '; Secure' : ''}` });
  }
  if (p === '/api/logout' && method === 'POST') {
    const t = cookies(req).dmn; if (t) SESS.delete(t);
    return json(res, 200, { ok: true }, { 'Set-Cookie': 'dmn=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0' });
  }
  if (p === '/api/me') return json(res, 200, user ? { role: user.role, name: user.name, username: user.username, roleName: L.ROLES[user.role].name, entity: E.forUser(S.db, user) } : { role: null });
  if (p === '/api/public/entities') return json(res, 200, { entities: E.list(S.db), groups: E.GROUPS, roleGroups: Object.fromEntries(Object.entries(E.ROLE_MAP).map(([k, v]) => [k, v.group])), sectors: E.SECTORS });

  // ── العامة: بلا دخول ──
  if (p === '/api/public/stats') return json(res, 200, L.publicStats());
  if (p === '/api/public/license') return json(res, 200, L.verifyLicense(url.searchParams.get('q')));
  if (p === '/api/public/complaint' && method === 'POST') { const b = await readBody(req); return json(res, 200, L.publicComplaint(b.code, b.phone, b.kind, b.text)); }
  if (p === '/api/public/report' && method === 'POST') { const b = await readBody(req); const r = L.publicReport(b); return json(res, 200, { id: r.id }); }
  if (p === '/api/public/apply' && method === 'POST') { const b = await readBody(req); const m = L.applyMerchant(b); return json(res, 200, { id: m.id, name: m.name }); }
  if (p.startsWith('/api/c/')) {
    const code = decodeURIComponent(p.slice(7));
    const r = L.shipmentByCode(code);
    if (!r.ok) return json(res, 200, { ok: false, reason: r.reason });
    const role = user ? user.role : 'public';
    const own = user && ((user.role === 'merchant' && user.merchantId === r.s.merchantId) || (user.role === 'courier' && user.courierId === r.s.courierId));
    const viewRole = ['merchant', 'courier'].includes(role) && !own ? 'public' : role;
    return json(res, 200, { ok: true, role, own: !!own, place: user && user.place || '', s: L.shipmentPublic(r.s, viewRole) });
  }

  // ── ما يلي يتطلب الدخول ──
  if (!user) return json(res, 401, { error: 'انتهت الجلسة، سجّل الدخول من جديد' });
  if (p === '/api/view') return json(res, 200, L.view(user));
  if (p === '/api/act' && method === 'POST') { const b = await readBody(req, user.role === 'admin' ? 1024 * 1024 : 64 * 1024); return json(res, 200, { ok: true, result: L.act(user, b.a, b.p || {}) }); }
  if (p.startsWith('/api/export/')) {
    const what = p.slice(12).replace(/\.csv$/, '');
    const body = L.exportCsv(user, what);
    return send(res, 200, body, 'text/csv; charset=utf-8', { 'Content-Disposition': `attachment; filename="daman-${what}-${new Date().toISOString().slice(0, 10)}.csv"`, 'Cache-Control': 'no-store' });
  }
  if (p === '/api/demo/reset' && method === 'POST') {
    if (!['digital', 'admin'].includes(user.role)) return json(res, 403, { error: 'إعادة بيانات العرض لمشغّل النظام ووزارة الاقتصاد الرقمي فقط' });
    // تبقى الجهات وشعاراتها والحسابات التي أنشأها المشغّل؛ تعود المعاملات وحدها إلى حالتها الأولى
    const keepE = S.db.entities, keepU = S.db.users.filter(u => u.created);
    S.reset(seed); S.db.entities = keepE; S.db.partnersSeeded = true; E.ensure(S.db);
    for (const u of keepU) if (!S.db.users.some(x => x.username === u.username)) S.db.users.push(u);
    S.scheduleSave(); SESS.clear();
    return json(res, 200, { ok: true }, { 'Set-Cookie': 'dmn=; Path=/; Max-Age=0' });
  }
  return json(res, 404, { error: 'غير موجود' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = decodeURIComponent(url.pathname);
  try {
    if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
    if (p.startsWith('/api/')) return await api(req, res, url);
    if (p.startsWith('/qr/') && p.endsWith('.svg')) {
      const code = p.slice(4, -4), r = L.shipmentByCode(code);
      if (!r.ok) return serve404(res);
      return send(res, 200, QR.svg(`${publicUrl(req)}/c/${r.s.code}`, 240), 'image/svg+xml', { 'Cache-Control': 'public, max-age=86400' });
    }
    if (p.startsWith('/logo/')) {
      const e = (S.db.entities || []).find(x => x.id === p.slice(6));
      if (!e) return serve404(res);
      if (!e.logo) return e.builtin ? send(res, 302, '', 'text/plain', { Location: e.builtin }) : serve404(res);
      const m = /^data:(image\/(?:png|jpeg|webp));base64,(.+)$/.exec(e.logo);
      if (!m) return serve404(res);
      return send(res, 200, Buffer.from(m[2], 'base64'), m[1], { 'Cache-Control': 'public, max-age=86400', 'Content-Security-Policy': "default-src 'none'" });
    }
    if (p === '/' || p === '/index.html') return serveFile(res, path.join(PUB, 'index.html'));
    if (p === '/apply') return serveFile(res, path.join(PUB, 'apply.html'));
    if (p.startsWith('/c/') || p === '/check') return serveFile(res, path.join(PUB, 'card.html'));
    const seg = p.split('/')[1];
    if (PORTALS.includes(seg)) return serveFile(res, path.join(PUB, 'app.html'));
    const file = path.normalize(path.join(PUB, p));
    if (!file.startsWith(PUB)) return serve404(res);
    return serveFile(res, file);
  } catch (e) {
    const code = e.status || 500;
    if (code === 500) console.error(e);
    return json(res, code, { error: code === 500 ? 'خطأ غير متوقع في الخادم' : e.message });
  }
});
server.listen(PORT, () => console.log(`ضمان يعمل على المنفذ ${PORT}`));
