// الجلسة 3: سجل الجهات المشاركة في «ضمان» وشعاراتها، ودور مشغّل النظام.
// كل جهة (حكومية أو قطاعية شبه حكومية أو غير حكومية) لها سجل وشعار، وترتبط ببوابة.
// الجهات التي يضيفها مشغّل النظام لاحقاً تدخل «بوابة الجهات المشاركة» (اطلاع على المؤشرات المجمّعة فقط).
'use strict';
const crypto = require('crypto');
const S = require('./store');

const SECTORS = {
  gov: 'جهة حكومية',
  semi: 'جهة قطاعية شبه حكومية',
  ngo: 'جهة غير حكومية / قطاع خاص',
};

// مجموعات الأدوار — بالترتيب الذي تظهر به في الصفحة الرئيسية وفي شاشة المشغّل
const GROUPS = [
  ['lead', 'الجهة المشرفة'],
  ['gov', 'الوزارات والهيئات الحكومية'],
  ['oversight', 'الجهات الرقابية والمالية'],
  ['field', 'الميدان'],
  ['private', 'القطاع الخاص'],
  ['partner', 'جهات مشاركة أخرى'],
  ['ops', 'تشغيل النظام'],
];

// ما تقرأه كل بوابة وما تكتبه — يظهر لمشغّل النظام في «الأدوار والصلاحيات»
const ROLE_MAP = {
  digital: { group: 'lead', reads: 'المؤشرات الوطنية المجمّعة، أداء شركات التوصيل', writes: 'مرحلة النظام، نسب الرسم، التعاميم' },
  trade: { group: 'gov', reads: 'سجل التجار وطلباتهم، إحالات حماية المستهلك', writes: 'إصدار الإجازة ورفضها وتعليقها وإعادتها' },
  tax: { group: 'gov', reads: 'السجل المالي، تحويلات شركات التوصيل، مخالفات التقييم', writes: 'مطابقة التحويلات' },
  customs: { group: 'gov', reads: 'البيانات المسبقة للطرود القادمة من الخارج', writes: 'التخليص والتعديل والرفض' },
  quality: { group: 'gov', reads: 'الطرود الخاضعة للفحص في مخازن التوصيل', writes: 'سحب العينات ونتائجها وأوامر السحب' },
  consumer: { group: 'gov', reads: 'شكاوى المشترين المربوطة بالشحنات', writes: 'قرار الشكوى والإحالة' },
  cmc: { group: 'gov', reads: 'بلاغات الصفحات والبثوث، المنصات الأجنبية', writes: 'قرار البلاغ' },
  cbi: { group: 'oversight', reads: 'المدفوعات وتدفقات التحصيل', writes: 'لا شيء — اطلاع فقط' },
  audit: { group: 'oversight', reads: 'السجل المالي وسجل الأفعال وسلامة السلسلتين', writes: 'لا شيء — اطلاع وتصدير فقط' },
  inspector: { group: 'field', reads: 'الشحنة الممسوحة فقط', writes: 'نتيجة الفحص الميداني' },
  checkpoint: { group: 'field', reads: 'الشحنة الممسوحة فقط', writes: 'تثبيت المرور (يمنع الجباية المزدوجة)' },
  courier: { group: 'private', reads: 'شحنات الشركة ورصيدها', writes: 'الاستلام والتسليم والإرجاع والتحويل اليومي' },
  merchant: { group: 'private', reads: 'طلبات المتجر ورسومها وشكاواه', writes: 'إنشاء الشحنات والبيان المسبق والرد على الشكاوى' },
  partner: { group: 'partner', reads: 'المؤشرات الوطنية المجمّعة والتعاميم', writes: 'لا شيء — اطلاع فقط' },
  admin: { group: 'ops', reads: 'الجهات والحسابات وسجل الأفعال', writes: 'الجهات وشعاراتها والحسابات — لا يمسّ أي معاملة أو رسم' },
};

// الجهات الأساسية — كل بوابة لها جهة. builtin: شعار مرفق مع النظام (يمكن للمشغّل استبداله)
const CORE = [
  ['E-DIGITAL', 'digital', 'وزارة الاقتصاد الرقمي والحوكمة', 'الاقتصاد الرقمي', 'gov', '🏛️', '/img/mdeg-512.webp', 'الجهة المشرفة: اللوحة الوطنية، مرحلة النظام، نسب الرسم والتعاميم'],
  ['E-TRADE', 'trade', 'وزارة التجارة', 'التجارة', 'gov', '📜', '/img/mot-512.webp', 'إصدار إجازات التجار الإلكترونيين وتعليقها'],
  ['E-TAX', 'tax', 'الهيئة العامة للضرائب', 'الضرائب', 'gov', '🧾', null, 'تحصيل الرسوم ومطابقة تحويلات شركات التوصيل'],
  ['E-CUSTOMS', 'customs', 'الهيئة العامة للكمارك', 'الكمارك', 'gov', '🛃', null, 'البيان المسبق للطرود القادمة من الخارج'],
  ['E-QUALITY', 'quality', 'الجهاز المركزي للتقييس والسيطرة النوعية', 'التقييس والجودة', 'gov', '🔬', null, 'العينات من مخازن شركات التوصيل وأوامر السحب'],
  ['E-CONSUMER', 'consumer', 'مجلس حماية المستهلك', 'حماية المستهلك', 'gov', '🛡️', null, 'شكاوى المشترين المربوطة بالشحنات'],
  ['E-CMC', 'cmc', 'هيئة الإعلام والاتصالات', 'الإعلام والاتصالات', 'semi', '📡', null, 'بلاغات الصفحات والبثوث والمنصات الأجنبية'],
  ['E-CBI', 'cbi', 'البنك المركزي العراقي', 'البنك المركزي', 'semi', '🏦', null, 'المدفوعات الإلكترونية وتدفقات التحصيل — اطلاع فقط'],
  ['E-AUDIT', 'audit', 'الجهات الرقابية — النزاهة والرقابة المالية', 'الرقابة', 'gov', '⚖️', null, 'هيئة النزاهة وديوان الرقابة المالية — اطلاع وتصدير فقط'],
  ['E-INSPECT', 'inspector', 'فريق التفتيش الميداني المشترك', 'المفتش الميداني', 'gov', '🔎', null, 'فحص الطرود بمسح رمزها'],
  ['E-CHECKPT', 'checkpoint', 'السيطرات الأمنية', 'السيطرات', 'gov', '🚧', null, 'مسح الرمز يثبت أن الرسم مدفوع فلا جباية ثانية'],
  ['E-COURIER', 'courier', 'شركات التوصيل المرخّصة', 'شركات التوصيل', 'ngo', '🚚', null, 'الاستلام والتسليم والتحصيل والتحويل اليومي'],
  ['E-MERCHANT', 'merchant', 'التجار الإلكترونيون', 'التجار', 'ngo', '🛍️', null, 'الطلبات ورسومها والإجازة'],
  ['E-OPS', 'admin', 'مشغّل النظام', 'مشغّل النظام', 'ngo', '⚙️', null, 'الجهة الفنية المنفّذة: الجهات وشعاراتها والحسابات'],
];
// جهة مشاركة تجريبية تُظهر كيف تُضاف الجهات الجديدة
const SAMPLE_PARTNERS = [
  ['E-CHAMBER', 'اتحاد الغرف التجارية العراقية', 'الغرف التجارية', 'semi', '🏢', 'اطلاع على المؤشرات المجمّعة لدعم أعضائه من التجار'],
];

const now = () => new Date().toISOString();
const newId = () => 'E-' + crypto.randomBytes(4).toString('hex').toUpperCase();

// يضمن وجود الجهات وحسابَي المشغّل والجهة المشاركة — يعمل على البيانات المحفوظة دون مسحها (ترقية الجلسة 3)
function ensure(db) {
  if (!Array.isArray(db.entities)) db.entities = [];
  const has = id => db.entities.some(e => e.id === id);
  for (const [id, portal, name, short, sector, icon, builtin, desc] of CORE) {
    if (!has(id)) db.entities.push({ id, portal, name, short, sector, icon, builtin, desc, core: true, active: true, logo: null, logoV: 0, at: now() });
  }
  for (const c of db.couriers || []) {
    const id = 'E-C-' + c.id;
    if (!has(id)) db.entities.push({ id, portal: 'courier', courierId: c.id, name: c.name, short: c.name, sector: 'ngo', icon: '🚚', builtin: null, desc: 'شركة توصيل مرخّصة — رقم الترخيص ' + (c.license || ''), core: true, active: true, logo: null, logoV: 0, at: now() });
  }
  for (const [id, name, short, sector, icon, desc] of SAMPLE_PARTNERS) {
    if (!has(id) && !db.partnersSeeded) db.entities.push({ id, portal: 'partner', name, short, sector, icon, builtin: null, desc, core: false, active: true, logo: null, logoV: 0, at: now() });
  }
  db.partnersSeeded = true;
  const U = (username, pw, name, role, extra = {}) => { if (!db.users.some(u => u.username === username)) db.users.push({ username, pass: S.hashPassword(pw), name, role, ...extra }); };
  U('admin1', 'Dmn@2026ad', 'مشغّل النظام', 'admin');
  if (db.entities.some(e => e.id === 'E-CHAMBER')) U('chamber1', 'Dmn@2026ch', 'مكتب التجارة الإلكترونية', 'partner', { entityId: 'E-CHAMBER' });
  S.scheduleSave();
  return db;
}

const logoUrl = e => e.logo ? `/logo/${e.id}?v=${e.logoV}` : (e.builtin || null);
function pub(e) { return { id: e.id, portal: e.portal, courierId: e.courierId || null, name: e.name, short: e.short, sector: e.sector, sectorText: SECTORS[e.sector], icon: e.icon, desc: e.desc, logo: logoUrl(e), core: !!e.core, active: e.active !== false }; }
const list = db => db.entities.filter(e => e.active !== false).map(pub);

// جهة المستخدم: شركة التوصيل باسمها، والجهة المشاركة بسجلها، وغيرها جهة بوابتها
function forUser(db, u) {
  let e = null;
  if (u.entityId) e = db.entities.find(x => x.id === u.entityId);
  if (!e && u.courierId) e = db.entities.find(x => x.courierId === u.courierId);
  if (!e) e = db.entities.find(x => x.portal === u.role && !x.courierId && x.core);
  return e ? pub(e) : null;
}

// ── أفعال مشغّل النظام ──
const err = (m, c = 400) => { const e = new Error(m); e.status = c; throw e; };
const clean = (v, n = 120) => String(v == null ? '' : v).replace(/[<>]/g, '').trim().slice(0, n);
function checkLogo(img) {
  if (img == null) return null;
  const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(img));
  if (!m) err('صيغة الشعار غير مقبولة — PNG أو JPG أو WEBP');
  if (m[2].length > 700 * 1024) err('الشعار كبير — الحد 500 كيلوبايت تقريباً');
  return String(img);
}
function addEntity(db, p) {
  const name = clean(p.name), short = clean(p.short || p.name, 40);
  if (name.length < 3) err('اكتب اسم الجهة');
  if (!SECTORS[p.sector]) err('اختر صفة الجهة');
  if (db.entities.some(e => e.name === name)) err('الجهة مسجّلة سابقاً');
  const e = { id: newId(), portal: 'partner', name, short, sector: p.sector, icon: '🏢', builtin: null, desc: clean(p.desc, 240), core: false, active: true, logo: checkLogo(p.logo || null), logoV: p.logo ? 1 : 0, at: now() };
  db.entities.push(e); S.scheduleSave();
  return pub(e);
}
function editEntity(db, p) {
  const e = db.entities.find(x => x.id === p.id) || err('الجهة غير موجودة', 404);
  if (p.name !== undefined) { const n = clean(p.name); if (n.length < 3) err('اكتب اسم الجهة'); e.name = n; }
  if (p.short !== undefined) e.short = clean(p.short, 40) || e.name;
  if (p.desc !== undefined) e.desc = clean(p.desc, 240);
  if (p.sector !== undefined) { if (!SECTORS[p.sector]) err('صفة غير صحيحة'); e.sector = p.sector; }
  S.scheduleSave(); return pub(e);
}
function setLogo(db, id, img) {
  const e = db.entities.find(x => x.id === id) || err('الجهة غير موجودة', 404);
  e.logo = checkLogo(img); e.logoV = (e.logoV || 0) + 1; S.scheduleSave();
  return pub(e);
}
function toggle(db, id) {
  const e = db.entities.find(x => x.id === id) || err('الجهة غير موجودة', 404);
  if (e.core) err('الجهات الأساسية لا تُوقف — لكل منها بوابة يعمل عليها النظام');
  e.active = e.active === false; S.scheduleSave();
  return pub(e);
}
const genPw = () => { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'; let s = ''; for (let i = 0; i < 6; i++) s += c[crypto.randomInt(c.length)]; return 'Dmn@' + s; };
function addUser(db, p) {
  const e = db.entities.find(x => x.id === p.entityId) || err('اختر الجهة');
  if (e.active === false) err('الجهة موقوفة');
  if (e.portal === 'merchant') err('حسابات التجار تُنشأ من تسجيل المتجر ثم إجازة وزارة التجارة');
  const username = String(p.username || '').trim().toLowerCase();
  if (!/^[a-z][a-z0-9._-]{3,30}$/.test(username)) err('اسم الدخول: أحرف إنكليزية صغيرة وأرقام، 4 أحرف على الأقل، ويبدأ بحرف');
  if (db.users.some(u => u.username === username)) err('اسم الدخول مستخدم سابقاً');
  const name = clean(p.name, 80); if (name.length < 3) err('اكتب اسم صاحب الحساب أو القسم');
  const pw = genPw(), extra = { created: true, place: clean(p.place, 80) || undefined };
  if (e.portal === 'partner') extra.entityId = e.id;
  if (e.courierId) extra.courierId = e.courierId;
  db.users.push({ username, pass: S.hashPassword(pw), name, role: e.portal, ...extra });
  S.scheduleSave();
  return { username, password: pw, portal: e.portal, entity: e.name };
}
function resetPassword(db, username) {
  const u = db.users.find(x => x.username === username) || err('الحساب غير موجود', 404);
  if (!u.created) err('حسابات نسخة العرض الجاهزة لا يُعاد تعيينها — كلماتها في ملف الجلسة');
  const pw = genPw(); u.pass = S.hashPassword(pw); S.scheduleSave();
  return { username, password: pw, portal: u.role };
}
function usersView(db) {
  return db.users.map(u => {
    const e = forUser(db, u);
    return { username: u.username, name: u.name, role: u.role, place: u.place || '', entity: e ? e.name : '', entityId: e ? e.id : '', created: !!u.created };
  });
}

module.exports = { SECTORS, GROUPS, ROLE_MAP, ensure, list, pub, forUser, addEntity, editEntity, setLogo, toggle, addUser, resetPassword, usersView, logoUrl };
